/* //////////////// dmCreateV1 ////////////////////

#Passing Parameters:( token: number, uIds: Array<uId> )

# Return type if no error: { dmId: number }

# Cases to be considered:
    -Error Scenarios
        // empty input is given
        // invalid token is given
        // invalid uId in given array of uIds
        // Duplicate uId in given array of uIds
        // id of token owner is in  given array of uIds
    -Return Correct Type (x2)
        - passing valid token and empty array
        - passing valid token and array of uIds

// /////////////////////////////////////////////////// */

// import functions
import {
  authRegisterV2,
  dmCreateV1,
  clearV2
} from './testHelpers';

// import interface
import {
  AuthUserId,
} from './interface';

const ERROR = { error: expect.any(String) };

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV2('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV2('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV2('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
});

describe('Error Casses', () => {
  test('empty input 1', () => {
    const testVar = dmCreateV1('', [user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('invalid token', () => {
    const testVar = dmCreateV1(mainUser.token + 'ABG', [user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('invalid uId in given array of uIds', () => {
    const testVar = dmCreateV1(mainUser.token, [user1.authUserId + 999, user2.authUserId]);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('duplicate uId in given array of uIds', () => {
    const testVar = dmCreateV1(mainUser.token, [user2.authUserId, user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('id of token owner is in  given array of uIds', () => {
    const testVar = dmCreateV1(mainUser.token, [user2.authUserId, user1.authUserId, mainUser.authUserId]);
    expect(testVar).toStrictEqual(ERROR);
  });
});

describe('Returns Correct Type', () => {
  test('passing valid token and empty array', () => {
    const testVar = dmCreateV1(mainUser.token, []);
    expect(testVar).toStrictEqual({ dmId: expect.any(Number) });
  });

  test('passing valid token and array of uIds', () => {
    const testVar = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual({ dmId: expect.any(Number) });
  });
});
