import { authRegisterV2, clearV2 } from './testHelpers';
import type { AuthUserId, DmID } from './interface';

const ERROR = { error: expect.any(String) };

import { messageSenddmV1, dmCreateV1 } from './testHelpers';

let user1: AuthUserId; // token
let user2: AuthUserId; // uId
let dm1: DmID; // dmId
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
  dm1 = dmCreateV1(user1.token, [user1.authUserId, user2.authUserId]) as DmID;
});
describe('messageSenddmV1 Tests', () => {
  test('Error: empty token', () => {
    expect(messageSenddmV1('', dm1.dmId + 1, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: invalid dmId', () => {
    expect(messageSenddmV1(user1.token, dm1.dmId + 1, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: invalid token', () => {
    expect(messageSenddmV1(user1.token + 1, dm1.dmId, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: authId does not exist in dm, but dmId valid', () => {
    const user3 = authRegisterV2('test3@gmail.com', '1234256', 'Hayd3en', 'Sm1ith') as AuthUserId;
    const dm2 = dmCreateV1(user2.token, [user1.authUserId, user2.authUserId]) as DmID;
    expect(messageSenddmV1(user3.token, dm2.dmId, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: Message length < 1', () => {
    expect(messageSenddmV1(user1.token, dm1.dmId, '')).toStrictEqual(ERROR);
  });
  // Cannot test for valid cases yet because dmMessages hasnt been implemented
  // test('Valid: New channel, empty message', () => {
  //   expect(channelMessagesV2(user1.token, dm1.dmId, 0)).toStrictEqual(
  //     expect.objectContaining(
  //       {
  //         messages: [],
  //         start: 0,
  //         end: -1,
  //       }
  //     ));
  // });
  // test('Valid: New channel, Send Message', () => {
  //   expect(messageSenddmV1(user1.token, dm1.dmId, 'Hello World')).toStrictEqual(
  //     expect.objectContaining({
  //       messageId: expect.any(Number),
  //     })
  //   );
  //   expect(channelMessagesV2(user1.token, dm1.dmId, 0)).toStrictEqual(
  //     expect.objectContaining({
  //       messages: expect.arrayContaining([
  //         expect.objectContaining({
  //           messageId: expect.any(Number),
  //           uId: user1.authUserId,
  //           message: 'Hello World',
  //           timeSent: expect.any(Number),
  //         })
  //       ]),
  //       start: 0,
  //       end: 50,
  //     })
  //   );
  // });
  // test('Valid: Send 2 Message', () => {
  //   expect(messageSenddmV1(user1.token, dm1.dmId, 'Hello World')).toStrictEqual(
  //     expect.objectContaining({
  //       messageId: expect.any(Number),
  //     })
  //   );
  //   expect(messageSenddmV1(user1.token, dm1.dmId, 'Good Mythical Morning')).toStrictEqual(
  //     expect.objectContaining({
  //       messageId: expect.any(Number),
  //     })
  //   );
  //   expect(channelMessagesV2(user1.token, dm1.dmId, 0)).toStrictEqual(
  //     expect.objectContaining({
  //       messages: expect.arrayContaining([
  //         expect.objectContaining({
  //           messageId: expect.any(Number),
  //           uId: user1.authUserId,
  //           message: 'Good Mythical Morning',
  //           timeSent: expect.any(Number),
  //         }),
  //         expect.objectContaining({
  //           messageId: expect.any(Number),
  //           uId: user1.authUserId,
  //           message: 'Hello World',
  //           timeSent: expect.any(Number),
  //         })
  //       ]),
  //       start: 0,
  //       end: 50,
  //     })
  //   );
  // });
});

// Test message added using messagesCreateV2
// If message is exactly 50
// If message is below 50
// if Message is between 50 and 100
// If message is above 100
// if message is above 200
