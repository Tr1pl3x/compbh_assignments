import { channelsListAllV2, channelsCreateV2 } from './testHelpers';
import { authRegisterV2 } from './testHelpers';
import { clearV2 } from './testHelpers';
import type { AuthUserId, Channels } from './interface';

beforeEach(() => {
  clearV2();
});

describe('channelsListAllV1', () => {
  test('returns an array of channel  for valid authUserId', () => {
    // const authUserId = 'validUserId';
    const input = authRegisterV2('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes') as AuthUserId;
    const channelCreating = channelsCreateV2(input.token, 'Valid channel name', false) as Channels;
    expect(channelsListAllV2(input.token)).toStrictEqual(
      {
        channels: [{
          channelId: channelCreating.channelId,
          name: 'Valid channel name'
        }]
      });
  });

  // test('Valid Parameters, one channel', () => {
  //   expect(4).toStrictEqual(4);
  // });

  describe('Return value for variosu function ', () => {
    test('channelsListAllV1 testing', () => {
      const inputfirst = authRegisterV2('evan.dang@unsw.edu.au', '123456aA', 'Johnny', 'Yes') as AuthUserId;
      const firsttest = channelsCreateV2(inputfirst.token, 'channelname_A', true) as Channels;
      const secondtest = channelsCreateV2(inputfirst.token, 'channelname_B', false) as Channels;
      const thirdtests = channelsCreateV2(inputfirst.token, 'channelname_C', true) as Channels;
      expect(channelsListAllV2(inputfirst.token)).toStrictEqual({
        channels: [
          {
            channelId: firsttest.channelId,
            name: 'channelname_A',
          },
          {
            channelId: secondtest.channelId,
            name: 'channelname_B',
          },
          {
            channelId: thirdtests.channelId,
            name: 'channelname_C',
          },
        ]
      });
    });
    clearV2();
  });
});
