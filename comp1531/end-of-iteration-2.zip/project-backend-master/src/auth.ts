import { getData, setData } from './dataStore';
import validator from 'validator';
import type { AuthUserId, ErrorMessage, Handle } from './interface';

export function authRegisterV1 (email: string, password: string, nameFirst: string, nameLast: string): AuthUserId | ErrorMessage {
  // getting our data from dataStore.js
  const data = getData();
  // if email is already in data store return error (being used by another user)
  if (data.users.some(user => user.email === email)) {
    return { error: 'Email already in use' };
  }

  // if email is not valid return error (invalid email)
  if (validator.isEmail(email) === false) {
    return { error: 'Email invalid' };
  }
  // Checking for invalid first and last name
  const firstNameError = validateName(nameFirst);
  if (firstNameError) {
    return { error: 'firstName Error' };
  }

  const lastNameError = validateName(nameLast);
  if (lastNameError) {
    return { error: 'lastName Error' };
  }

  // If password length is less than 6 characters return error
  if (password.length < 6) {
    return { error: 'Password error' };
  }

  // If the arguments are valid, format the handle and return the userId

  // creating a unique user Id
  const authUserId = Math.floor(Math.random() * 1000000000);

  // creating a token that will be associated with this user then convert to string length 16
  const randomNumber = (Math.random() * 100000);
  const token = randomNumber.toString(16);

  // convert both first and last name to lowercase and remove all alphanumeric characters

  let handle: Handle = (nameFirst + nameLast).toLowerCase().replace(/[^a-z]/g, '').split('');

  // if the length is greater than 20, reduce to 20
  handle = handle.length > 20 ? handle.slice(0, 20) : handle;

  // check if the handle already exists
  // by using the Array.find() method to check if a handle already exists in the
  // data.users array
  const userExists = data.users.find(user => user.handle === handle);
  if (userExists) {
    // handle already exists, increment the number on the end of the handle string
    const lastElement: number = handle.length - 1;
    if (typeof handle[lastElement] === 'number') {
      handle[lastElement]++;
    } else {
      handle.push(0);
    }
  }

  const handleString = handle.join('');
  // Push our new client object onto data.users and set it on the datastore
  data.users.push({
    uId: authUserId,
    tokens: [{ tokenId: token }],
    nameFirst: nameFirst,
    nameLast: nameLast,
    email: email,
    password: password,
    handleStr: handleString,
    channelsJoined: [],
  });
  setData(data);
  return {
    token,
    authUserId
  };
}

// function to validate a name (first or last)
// Used in authRegisterV1
function validateName(name: string): ErrorMessage {
  if (name.length > 50 || name.length < 1) {
    return { error: 'error' };
  }
}

/**
  *Given a registered user's email and password,
 returns their authUserId value.

  * @param { email }  - emaail of the student/admin
  * @param { password }  - password of the student/admin
  *
  * @return { token, authUserId } - token and uId of user

*/

export function authLoginV1(email: string, password: string): AuthUserId | ErrorMessage {
  const data = getData();
  const user = data.users.find(user => user.email === email);

  // creating a token that will be associated with this user when they login to their session
  const randomNumber = (Math.random() * 100000);
  const token = randomNumber.toString(16);

  if (!user) {
    return { error: 'email error' };
  } else if (user.password !== password) {
    return { error: 'password error' };
  } else {
    return {
      token: token,
      authUserId: user.email
    };
  }
}

/**
  *Given an active token,
  invalidates the token to log the user out.

  * @param { token }  - token of the student/admin
  *
  * @return { } - empty array from removed token

*/

export function authLogOutV1(token: string) {
  const data = getData();

  const user = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  // validate the token
  if (!user) return { error: 'Invalid Token' };

  const shuffleUser = data.users.findIndex(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  const numberUser = data.users[shuffleUser];

  if (numberUser.tokens.length === 1) {
    data.users.splice(shuffleUser, 1);
  } else {
    numberUser.token = numberUser.token.filter((t: { tokenId: string }) => t.tokenId !== token);
  }

  setData(data);
  return {};
}
