import { authRegisterV2, channelsCreateV2, clearV2 } from './testHelpers';
import type { AuthUserId, ChannelId } from './interface';
// import { channelDetailsV1 } from './testHelpers';

// channelInviteV2 testing
import { channelInviteV2 } from './testHelpers';

let user1: AuthUserId;
let user2: AuthUserId;
let user3: AuthUserId;
let channel1: ChannelId;
let channel2: ChannelId;
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
  user3 = authRegisterV2('test3@gmail.com', '1231231234', 'Dean', 'Wunder') as AuthUserId;
  channel1 = channelsCreateV2(user1.token, 'New Channel', true) as ChannelId;
  channel2 = channelsCreateV2(user2.token, 'New channel2lId', true) as ChannelId;
});

describe('channelInviteV2 Tests', () => {
  test('Error: empty token', () => {
    expect(channelInviteV2('', channel1.channelId + 3, user2.authUserId)).toEqual({ error: 'Invalid empty token' });
  });
  test('Error: invalid channelId ', () => {
    expect(channelInviteV2(user1.token, channel1.channelId + 3, user2.authUserId)).toEqual({ error: 'Invalid channelId' });
  });
  test('Error: invalid uId ', () => {
    expect(channelInviteV2(user1.token, channel1.channelId, user2.authUserId + 3)).toEqual({ error: 'Invalid uId' });
  });
  test('Error: invalid token ', () => {
    expect(channelInviteV2(user1.token + 3, channel1.channelId, user2.authUserId)).toEqual({ error: 'Invalid token: user not found' });
  });
  test('Error: authId and uId identical', () => {
    expect(channelInviteV2(user1.token, channel1.channelId, user1.authUserId)).toStrictEqual({ error: 'Enter another user uId' });
  });
  test('Error: uId exists in the channel', () => {
    channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
    expect(channelInviteV2(user1.token, channel1.channelId, user2.authUserId)).toStrictEqual({ error: 'uId already exists in the channel' });
  });
  test('Error: authId does not exist in channel, but channelId valid', () => {
    expect(channelInviteV2(user1.token, channel2.channelId, user3.authUserId)).toStrictEqual({ error: 'authId is not member of channel' });
  });
  test('Valid: Valid return value', () => {
    expect(channelInviteV2(user1.token, channel1.channelId, user2.authUserId)).toStrictEqual({});
  });
  // test('Valid: User invited then exists in the channel', () => {
  //   channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
  //   const channelDetails = channelDetailsV1(user1.token, channel1.channelId);
  //   expect(channelDetails.channel.allMembers).toEqual(
  //     expect.arrayContaining([
  //       expect.objectContaining(
  //         {
  //           uId: user2.authUserId
  //         }
  //       )
  //     ])
  //   );
  // });
  // test('Two users invited then exists in the channel', () => {
  //   channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
  //   channelInviteV2(user1.token, channel1.channelId, user3.authUserId);
  //   const channelDetails = channelDetailsV1(user1.token, channel1.channelId);
  //   expect(channelDetails.channel.allMembers).toEqual(
  //     expect.arrayContaining([
  //       expect.objectContaining(
  //         {
  //           uId: user2.authUserId
  //         }
  //       ),
  //       expect.objectContaining(
  //         {
  //           uId: user3.authUserId
  //         }
  //       )
  //     ])
  //   );
  // });
  // test('Two users invited, the second user invites a third user', () => {
  //   channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
  //   channelInviteV2(user2.token, channel1.channelId, user3.authUserId);
  //   const channelDetails = channelDetailsV1(user1.token, channel1.channelId);
  //   expect(channelDetails.channel.allMembers).toEqual(
  //     expect.arrayContaining([
  //       expect.objectContaining(
  //         {
  //           uId: user2.authUserId
  //         }
  //       ),
  //       expect.objectContaining(
  //         {
  //           uId: user3.authUserId
  //         }
  //       )
  //     ])
  //   );
  // }); test('Valid return value', () => {
  //   expect(channelInviteV2(user1.token, channel1.channelId, user2.authUserId)).toStrictEqual({});
  // });
  // test('User invited then exists in the channel', () => {
  //   channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
  //   const channelDetails = channelDetailsV1(user1.token, channel1.channelId);
  //   expect(channelDetails.channel.allMembers).toEqual(
  //     expect.arrayContaining([
  //       expect.objectContaining(
  //         {
  //           uId: user2.token
  //         }
  //       )
  //     ])
  //   );
  // });
  // test('Two users invited then exists in the channel', () => {
  //   channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
  //   channelInviteV2(user1.token, channel1.channelId, user3.authUserId);
  //   const channelDetails = channelDetailsV1(user1.token, channel1.channelId);
  //   expect(channelDetails.channel.allMembers).toEqual(
  //     expect.arrayContaining([
  //       expect.objectContaining(
  //         {
  //           uId: user2.authUserId
  //         }
  //       ),
  //       expect.objectContaining(
  //         {
  //           uId: user3.authUserId
  //         }
  //       )
  //     ])
  //   );
  // });
  // test('Two users invited, the second user invites a third user', () => {
  //   channelInviteV2(user1.token, channel1.channelId, user2.authUserId);
  //   channelInviteV2(user2.token, channel1.channelId, user3.authUserId);
  //   const channelDetails = channelDetailsV1(user1.token, channel1.channelId);
  //   expect(channelDetails.channel.allMembers).toEqual(
  //     expect.arrayContaining([
  //       expect.objectContaining(
  //         {
  //           uId: user2.authUserId
  //         }
  //       ),
  //       expect.objectContaining(
  //         {
  //           uId: user3.authUserId
  //         }
  //       )
  //     ])
  //   );
  // });
});
