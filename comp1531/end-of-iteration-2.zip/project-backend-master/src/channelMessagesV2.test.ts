import type { AuthUserId, ChannelId } from './interface';
// import type { Data } from './dataStore'

const ERROR = { error: expect.any(String) };

import { authRegisterV2, channelsCreateV2, clearV2, channelMessagesV2, messageSendV1 } from './testHelpers';

// let dataStore: Data;

let user1: AuthUserId; // token
let user2: AuthUserId; // uId
let channel1: ChannelId; // channelId
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
  channel1 = channelsCreateV2(user1.token, 'New7Channel', true) as ChannelId;
});

describe('channelMessagesV2 Edge Tests', () => {
  // Return object {error: 'error'} channelId does not refer to a valid channel
  test('Error: invalid channelId', () => {
    expect(channelMessagesV2(user1.token, channel1.channelId + 1, 0)).toStrictEqual(ERROR);
  });
  // authId is invalid
  test('Error: invalid authId', () => {
    expect(channelMessagesV2(user1.token + 1, channel1.channelId, 0)).toStrictEqual(ERROR);
  });
  // channelId is valid and the authorised user is not a member of the channel
  test('Error: authId does not exist in channel, but channelId valid', () => {
    // User 2 is auth of channel2
    const channel2 = channelsCreateV2(user2.token, 'New Channel2', true) as ChannelId;
    expect(channelMessagesV2(user1.token, channel2.channelId, 0)).toStrictEqual(ERROR);
  });
  // Start is a negative value, returns error
  test('Error: Start is negative', () => {
    expect(channelMessagesV2(user1.token, channel1.channelId, -1)).toStrictEqual(ERROR);
  });
  // Start greater than end
  test('Error: Start greater than end', () => {
    expect(channelMessagesV2(user1.token, channel1.channelId, 51)).toStrictEqual(ERROR);
  });
  // Assumption start === end, returns undefined, therefore return error
  test('Error: Start equal to end', () => {
    expect(channelMessagesV2(user1.token, channel1.channelId, 50)).toStrictEqual(ERROR);
  });
  test('Valid: New channel, empty message', () => {
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining(
        {
          messages: [],
          start: 0,
          end: -1,
        }
      ));
  });
});
describe('channelMessagesV2 Messages Tests', () => {
  test('Valid: 1 message', () => {
    messageSendV1(user1.token, channel1.channelId, 'Hello World');
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: expect.any(Number),
            message: 'Hello World',
            timeSent: expect.any(Number)
          }),
        ]),
        start: 0,
        end: -1,
      }
      ));
  });
  test('Valid: 2 messages', () => {
    messageSendV1(user1.token, channel1.channelId, 'Hello World');
    messageSendV1(user1.token, channel1.channelId, 'Hello another World');
    // console.log(channelMessagesV2(user1.token, channel1.channelId, 0))
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: expect.any(Number),
            message: 'Hello World',
            timeSent: expect.any(Number)
          }),
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: expect.any(Number),
            message: 'Hello another World',
            timeSent: expect.any(Number)
          }),
        ]),
        start: 0,
        end: -1,
      }
      ));
  });
});

describe('25 Messages', () => {
  beforeEach(() => {
    for (let i = 0; i < 25; i++) {
      messageSendV1(user1.token, channel1.channelId, 'Hello World');
    }
  });
  test('Valid: 25 messages', () => {
    // console.log(channelMessagesV2(user1.token, channel1.channelId, 0))
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: expect.any(Number),
            message: expect.any(String),
            timeSent: expect.any(Number)
          }),
        ]),
        start: 0,
        end: -1,
      }
      ));
  });
  describe('50 Messages', () => {
    beforeEach(() => {
      // Add 25 more messages, total: 50 messages
      for (let i = 0; i < 25; i++) {
        messageSendV1(user1.token, channel1.channelId, 'Hello World');
      }
    });
    test('Valid: 50 messages (end = -1)', () => {
      // console.log(channelMessagesV2(user1.token, channel1.channelId, 0))
      expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
        expect.objectContaining({
          messages: expect.arrayContaining([
            expect.objectContaining({
              messageId: expect.any(Number),
              uId: expect.any(Number),
              message: expect.any(String),
              timeSent: expect.any(Number)
            }),
          ]),
          start: 0,
          end: -1,
        }
        ));
    });
    describe('75 Messages', () => {
      beforeEach(() => {
        // Add 25 more messages, total: 75 messages
        for (let i = 0; i < 25; i++) {
          messageSendV1(user1.token, channel1.channelId, 'Hello World');
        }
      });
      test('Valid: 75 messages (end = 50)', () => {
        // console.log(channelMessagesV2(user1.token, channel1.channelId, 0))
        expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
          expect.objectContaining({
            messages: expect.arrayContaining([
              expect.objectContaining({
                messageId: expect.any(Number),
                uId: expect.any(Number),
                message: expect.any(String),
                timeSent: expect.any(Number)
              }),
            ]),
            start: 0,
            end: 50,
          }
          ));
      });
      test('Valid: 75 messages (start = 50) (end = -1)', () => {
        // console.log(channelMessagesV2(user1.token, channel1.channelId, 0))
        expect(channelMessagesV2(user1.token, channel1.channelId, 50)).toStrictEqual(
          expect.objectContaining({
            messages: expect.arrayContaining([
              expect.objectContaining({
                messageId: expect.any(Number),
                uId: expect.any(Number),
                message: expect.any(String),
                timeSent: expect.any(Number)
              }),
            ]),
            start: 50,
            end: -1,
          }
          ));
      });
      describe('110 Messages', () => {
        beforeEach(() => {
          // Add 35 more messages, total: 110 messages
          for (let i = 0; i < 35; i++) {
            messageSendV1(user1.token, channel1.channelId, 'Hello World');
          }
        });
        test('Valid: 110 messages (start = 50) (end = 100)', () => {
          // console.log(channelMessagesV2(user1.token, channel1.channelId, 50))
          expect(channelMessagesV2(user1.token, channel1.channelId, 50)).toStrictEqual(
            expect.objectContaining({
              messages: expect.arrayContaining([
                expect.objectContaining({
                  messageId: expect.any(Number),
                  uId: expect.any(Number),
                  message: expect.any(String),
                  timeSent: expect.any(Number)
                }),
              ]),
              start: 50,
              end: 100,
            }
            ));
        });
      });
    });
  });
});
