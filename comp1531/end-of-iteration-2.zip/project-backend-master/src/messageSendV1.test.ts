import { authRegisterV2, channelsCreateV2, clearV2 } from './testHelpers';
import type { AuthUserId, ChannelId } from './interface';

const ERROR = { error: expect.any(String) };

import { channelMessagesV2, messageSendV1 } from './testHelpers';

let user1: AuthUserId; // token
let user2: AuthUserId; // uId
let channel1: ChannelId; // channelId
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
  channel1 = channelsCreateV2(user1.token, 'New Channel', true) as ChannelId;
});
describe('messageSendV1 Tests', () => {
  test('Error: empty token', () => {
    expect(messageSendV1('', channel1.channelId + 1, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: invalid channelId', () => {
    expect(messageSendV1(user1.token, channel1.channelId + 1, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: invalid token', () => {
    expect(messageSendV1(user1.token + 1, channel1.channelId, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: authId does not exist in channel, but channelId valid', () => {
    const channel2 = channelsCreateV2(user2.token, 'New Channel2', true) as ChannelId;
    expect(messageSendV1(user1.token, channel2.channelId, 'inputmessage')).toStrictEqual({ error: 'authId is not member of channel' });
  });
  test('Error: Message length < 1', () => {
    expect(messageSendV1(user1.token, channel1.channelId, '')).toStrictEqual(ERROR);
  });
  test('Valid: New channel, empty message', () => {
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining(
        {
          messages: [],
          start: 0,
          end: -1,
        }
      ));
  });
  test('Valid: New channel, Send Message', () => {
    expect(messageSendV1(user1.token, channel1.channelId, 'Hello World')).toStrictEqual(
      expect.objectContaining({
        messageId: expect.any(Number),
      })
    );
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: user1.authUserId,
            message: 'Hello World',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
  test('Valid: Send 2 Message', () => {
    expect(messageSendV1(user1.token, channel1.channelId, 'Hello World')).toStrictEqual(
      expect.objectContaining({
        messageId: expect.any(Number),
      })
    );
    expect(messageSendV1(user1.token, channel1.channelId, 'Good Mythical Morning')).toStrictEqual(
      expect.objectContaining({
        messageId: expect.any(Number),
      })
    );
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: user1.authUserId,
            message: 'Good Mythical Morning',
            timeSent: expect.any(Number),
          }),
          expect.objectContaining({
            messageId: expect.any(Number),
            uId: user1.authUserId,
            message: 'Hello World',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
});
