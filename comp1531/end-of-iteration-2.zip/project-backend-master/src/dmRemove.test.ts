import {
  authRegisterV2,
  dmRemoveV1,
  dmCreateV1,
  clearV2
} from './testHelpers';

// import interface
import {
  AuthUserId,
} from './interface';

const ERROR = { error: expect.any(String) };

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV2('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV2('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV2('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
});

describe('Returns Correct Type', () => {
  test('passing invalid token and empty array', () => {
    const testVar = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId]);
    const IdRemove = dmRemoveV1('', testVar.dmId);
    expect(IdRemove).toStrictEqual(ERROR);
  });

  test('correct return type ', () => {
    const testVar = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId]);
    // console.log(testVar)
    const Usertesting = dmRemoveV1(mainUser.token, testVar.dmId);
    console.log(Usertesting);
    expect(Usertesting).toStrictEqual({});
  });

  test('correct return type ', () => {
    const testVar = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId]);
    const Usertesting = dmRemoveV1(mainUser.token, testVar.dmId + 1);
    expect(Usertesting).toStrictEqual(ERROR);
  });
});
