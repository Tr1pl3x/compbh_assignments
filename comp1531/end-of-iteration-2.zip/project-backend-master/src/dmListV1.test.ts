/* //////////////// dmListV1 ////////////////////

# Passing Parameters:( token: number )

# Return type if no error: { dms: array<dm>}

# Cases to be considered:
    -Error Scenarios
        // empty token
        // invalid token

    -Return Correct Type (x2)
        - passing valid token

// /////////////////////////////////////////////////// */

// import functions
import {
  authRegisterV2,
  dmCreateV1,
  dmListV1,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  DmID,
} from './interface';

const ERROR = { error: expect.any(String) };
let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;
let dm1: DmID;
let dm2: DmID;
let dm3: DmID;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV2('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV2('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV2('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
  dm1 = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
  dm2 = dmCreateV1(user2.token, [mainUser.authUserId])as DmID;
  dm3 = dmCreateV1(mainUser.token, [])as DmID;
});

describe('Error Casses', () => {
  test('empty input', () => {
    // line 51: to pass lint for pipeline
    console.log(dm1.dmId, dm2.dmId, dm3.dmId, 'dummy for pipeline: lint');
    const testVar = dmListV1('');
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Invalid token', () => {
    const testVar = dmListV1(mainUser.token + 'abg');
    expect(testVar).toStrictEqual(ERROR);
  });
});

describe('Returns Correct Type', () => {
  test('passing valid token', () => {
    const testVar = dmListV1(mainUser.token);
    expect(testVar).toStrictEqual(
      expect.arrayContaining([
        expect.objectContaining({
          dmId: expect.any(Number),
          name: expect.any(String),
          ownerMembers: expect.arrayContaining([
            expect.objectContaining({
              uId: expect.any(Number),
              tokens: expect.arrayContaining([
                expect.objectContaining({
                  tokenId: expect.any(String)
                })
              ]),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              email: expect.any(String),
              password: expect.any(String),
              handleStr: expect.any(String),
              channelsJoined: []
            })
          ]),
          allMembers: expect.arrayContaining([
            expect.objectContaining({
              uId: expect.any(Number),
              tokens: expect.arrayContaining([
                expect.objectContaining({
                  tokenId: expect.any(String)
                })
              ]),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              email: expect.any(String),
              password: expect.any(String),
              handleStr: expect.any(String),
              channelsJoined: []
            })
          ]),
          allMessages: []
        })
      ])
    );
  });
});
