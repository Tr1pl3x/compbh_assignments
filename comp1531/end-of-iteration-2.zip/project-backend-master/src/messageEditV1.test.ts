import { authRegisterV2, channelsCreateV2, clearV2 } from './testHelpers';
import type { AuthUserId, ChannelId, Messages } from './interface';

interface SendMessageReturn {
  messageId: number;
}
const ERROR = { error: expect.any(String) };
import { channelMessagesV2, messageSendV1, messageEditV1 } from './testHelpers';

let user1: AuthUserId; // token
let user2: AuthUserId; // uId
let channel1: ChannelId; // channelId
let sendMessage1: SendMessageReturn;
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
  channel1 = channelsCreateV2(user1.token, 'New Channel', true) as ChannelId;
  sendMessage1 = messageSendV1(user1.token, channel1.channelId, 'testmessage') as SendMessageReturn;
});
describe('messageSendV1 Tests', () => {
  test('Error: empty token', () => {
    expect(messageEditV1('', sendMessage1.messageId, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: invalid token', () => {
    expect(messageEditV1(user1.token + 1, sendMessage1.messageId, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: invalid messageId', () => {
    expect(messageEditV1(user1.token, sendMessage1.messageId + 3, 'inputmessage')).toStrictEqual(ERROR);
  });
  test('Error: authId attempts to edit another user message', () => {
    expect(messageEditV1(user2.token, sendMessage1.messageId, 'changeinputmessage')).toStrictEqual(ERROR);
  });
  test('Valid: authUser edit their message', () => {
    messageEditV1(user1.token, sendMessage1.messageId, 'Hello, I updated this message');
    const newMessage = channelMessagesV2(user1.token, channel1.channelId, 0) as Messages;
    expect(newMessage).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: sendMessage1.messageId,
            uId: user1.authUserId,
            message: 'Hello, I updated this message',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
  test('Valid: authUser edit their 2nd message, 1st message remains', () => {
    const sendMessage2 = messageSendV1(user1.token, channel1.channelId, 'Hi this is a 2nd message') as SendMessageReturn;
    messageEditV1(user1.token, sendMessage2.messageId, 'Hello, I updated this message');
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: sendMessage2.messageId,
            uId: user1.authUserId,
            message: 'Hello, I updated this message',
            timeSent: expect.any(Number),
          }),
          expect.objectContaining({
            messageId: sendMessage1.messageId,
            uId: user1.authUserId,
            message: 'testmessage',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
  test('Valid: authUser creates 2nd message, edits it with empty string', () => {
    const sendMessage2 = messageSendV1(user1.token, channel1.channelId, 'Hi this is a 2nd message') as SendMessageReturn;
    messageEditV1(user1.token, sendMessage2.messageId, '');
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: sendMessage1.messageId,
            uId: user1.authUserId,
            message: 'testmessage',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
});

// Test message added using messagesCreateV2
// If message is exactly 50
// If message is below 50
// if Message is between 50 and 100
// If message is above 100
// if message is above 200
