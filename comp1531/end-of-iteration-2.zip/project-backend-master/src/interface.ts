
export type AuthUserId = { token: string, authUserId: number };
export type ErrorMessage = { error: string };
export type Handle = Array<any>;

export interface ChannelId {
  channelId: number;
}

export interface aUser {
  uId: number,
  email: string,
  nameFirst: string,
  nameLast: string,
  handleStr: string
  channelsJoined?: Array<ChannelId>
}
export interface MessageInfo {
    messageId: number;
    uId: number;
    message: string;
    timeSent: number;
}
export interface Messages {
    messages: Array<MessageInfo>,
    start: number,
    end: number
}

export interface MessageReturn {
    messageId: number;
}

export interface Member {
  uId: number,
  email: string,
  nameFirst: string,
  nameLast: string,
  handleStr: string
}

export interface ChannelDetails {
  name: string,
  isPublic: boolean,
  ownerMembers: Array<Member>,
  allMembers: Array<Member>
}

export interface Channels {
    channelId: number;
    name: string;
    isPublic: boolean;
    ownerMembers: Array<aUser>;
    allMembers: Array<aUser>;
    allMessages: Array<Messages>;
}

export interface ChannelsListReturn {
  channelId: number,
  name: string,
}

export interface ChannelsReturn {
    channels: Array<ChannelsListReturn>;
  }
export interface ChannelsListAll {
    channelId: number;
    name: string;
  }
export interface ChannelsListAllReturn {
    channels: Array<ChannelsListAll>;
  }

export interface User {
    user: {
      uId: number,
      email: string,
      nameFirst: string,
      nameLast: string,
      handleStr: string
      channelsJoined?: Array<ChannelId>
    }
}

export type Users = User[];

/// /////////////DMS//////////////////////

export type DmDetails = {
    name: string,
    members: Array<User>
}

export type DM = {
  dmId: number,
  name: string,
  ownerMembers: Array<User>
  allMembers: Array<User>
  allMessages: Array<MessageInfo>
}
export type DMs = Array<DM>;
export type UID = { uId: number};
export type UIDs = Array<UID>;
export type DmID = { dmId: number};
