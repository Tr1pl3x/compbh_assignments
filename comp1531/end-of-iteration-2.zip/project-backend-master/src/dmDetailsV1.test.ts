/* //////////////// dmDetails1 ////////////////////

#Passing Parameters:( token: string, dmId: number )

# Return type if no error: { name: string, members: array<Users> }

# Cases to be considered:
    -Error Scenarios
        // empty input is given
        // invalid dmId
        // invalid token
        // unauthorised access to valid channel

    -Return Correct Type
        - passing valid token and dmId

// /////////////////////////////////////////////////// */

// import functions
import {
  authRegisterV2,
  dmCreateV1,
  dmDetailsV1,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  DmID,
} from './interface';

const ERROR = { error: expect.any(String) };

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;
let dm: DmID;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV2('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV2('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV2('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
  dm = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
});

describe('Error Casses', () => {
  test('empty input', () => {
    const testVar = dmDetailsV1('', dm.dmId);
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Invalid token', () => {
    const testVar = dmDetailsV1(mainUser.token + 'abg', dm.dmId);
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Invalid Dm ID', () => {
    const testVar = dmDetailsV1(mainUser.token, dm.dmId + 999);
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Unauthorised access to a valid dm', () => {
    const newUser = authRegisterV2('jj@gmail.com', 'passcoed', 'eblu', 'bad') as AuthUserId;
    const testVar = dmDetailsV1(newUser.token, dm.dmId);
    expect(testVar).toStrictEqual(ERROR);
  });
});

describe('Returns Correct Type', () => {
  test('passing valid token and array of uIds', () => {
    const testVar = dmDetailsV1(user2.token, dm.dmId);

    expect(testVar).toStrictEqual({
      name: 'blueranger,pyaesone,redranger',
      members: expect.arrayContaining([
        expect.objectContaining({
          uId: expect.any(Number),
          email: expect.any(String),
          nameFirst: expect.any(String),
          nameLast: expect.any(String),
          handleStr: expect.any(String),
        }),
      ])
    });
  });
});
