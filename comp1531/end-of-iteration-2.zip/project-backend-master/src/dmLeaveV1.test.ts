/* //////////////// dmLeaveV1 ////////////////////

#Passing Parameters:{ token: string, dmIdnumber }

# Return type if no error: {}

# Cases to be considered:
    -Error Scenarios
        // empty token
        // invalid token
        // invalid dmId
        // unauthorised access to remove
    -Return Correct Type

// /////////////////////////////////////////////////// */

/// import functions
import {
  authRegisterV2,
  dmCreateV1,
  dmLeaveV1,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  DmID,
} from './interface';

const ERROR = { error: expect.any(String) };

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;
let dm: DmID;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV2('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV2('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV2('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
  dm = dmCreateV1(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
});

describe('Error Casses', () => {
  test('empty input', () => {
    const testVar = dmLeaveV1('', dm.dmId);
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Invalid token', () => {
    const testVar = dmLeaveV1(mainUser.token + 'abg', dm.dmId);
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Invalid Dm ID', () => {
    const testVar = dmLeaveV1(mainUser.token, dm.dmId + 999);
    expect(testVar).toStrictEqual(ERROR);
  });
  test('Unauthorised access to a valid dm', () => {
    const newUser = authRegisterV2('jj@gmail.com', 'passcoed', 'eblu', 'bad') as AuthUserId;
    const testVar = dmLeaveV1(newUser.token, dm.dmId);
    expect(testVar).toStrictEqual(ERROR);
  });
});

describe('Returns Correct Type', () => {
  test('successful remove', () => {
    const testVar = dmLeaveV1(user2.token, dm.dmId);
    expect(testVar).toStrictEqual({});
  });
});
