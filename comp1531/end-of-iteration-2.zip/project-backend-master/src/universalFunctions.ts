// this is a file for functions that get repeated many times throughout the project
import { getData } from './dataStore';
import type { Channels, User } from './interface';

/*
* the below function returns true if the token is valid and
* false if the token is invalid
*/
export function isValidToken (token: string): (boolean) {
  const data = getData();
  // checking if the token is valid
  for (const person of data.users) {
    // looping through tokens as there could be multiple
    for (const tokenObj of person.tokens) {
      if (tokenObj.tokenId === token) {
        return true;
      }
    }
  }
  return false;
}

/*
* the below function checks that the channel is valid
*/
export function isValidChannel(channelId: number): boolean {
  const data = getData();
  // looping through channels
  for (const channel of data.channels) {
    // finding channelId
    if (channel.channelId === channelId) {
      return true;
    }
  }
  return false;
}

export function uIdValid (uId: number): (boolean) {
  const data = getData();
  // checking if the token is valid
  for (const person of data.users) {
    if (person.uId === uId) {
      return true;
    }
  }
  return false;
}

/*
* the below function returns the channel given a channelId
* returns undefined if the channel does not exist
*/
export function returnChannel (channelId: number): (Channels) {
  const data = getData();
  // checking the channelId is valid
  for (const channels of data.channels) {
    // looping through channels
    if (channels.channelId === channelId) {
      return channels;
    }
  }
  return undefined;
}

/*
* the below function returns the uId of a user given a token
* return is undefined if the user does not exist
*/
export function getuId (token: string): (number) {
  const data = getData();
  const user = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (user !== undefined) {
    return user.uId;
  } else {
    return undefined;
  }
}

/*
* the below function returns the user given a token
* return is undefined if the user does not exist
*/
export function getUserFromToken (token: string): (User) {
  const data = getData();
  const user = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (user === undefined) {
    return undefined;
  } else {
    return user;
  }
}

/*
* the below function returns the user given a token
* return is undefined if the user does not exist
*/
export function getUserFromId (uId: number): (User) {
  const data = getData();
  for (const person of data.users) {
    if (person.uId === uId) {
      return person;
    }
  }
  return undefined;
}
