/* /////////////////////// channelJoinV2 ////////////////////////

# Parameters:( token, channelId )

# Return type if no error:{}

# Cases to be considered:
    - Error Scenarios
        // empty token
        // invalid token
        // invalid channel
        // user of the token already part of channel
        // private channel + (authUser not in channel and not owner)
    - Return Correct Type
        // empty object if successful
// *//// ///////////////////////////////////////////////////////////

// import functions
import {
  authRegisterV2,
  channelsCreateV2,
  channelJoinV2,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  ChannelId,
} from './interface';

const ERROR = { error: expect.any(String) };

let user: AuthUserId;
let newUser: AuthUserId;
let thread: ChannelId;
let Pthread: ChannelId;
let newThread: ChannelId;
beforeEach(() => {
  clearV2();
  user = authRegisterV2('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  newUser = authRegisterV2('alien@gmail.com', 'passcoed', 'alien', 'invasion') as AuthUserId;
  thread = channelsCreateV2(user.token, 'AwesomeChannel', true) as ChannelId;
  Pthread = channelsCreateV2(user.token, 'PChannel', false) as ChannelId;
});

describe('Error Casses', () => {
  test('Empty Token', () => {
    const testVar = channelJoinV2('', thread.channelId);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('invalid token', () => {
    const testVar = channelJoinV2(user.token + 'abg', thread.channelId);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('invalid channel', () => {
    const testVar = channelJoinV2(user.token, thread.channelId * 999);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('User already in channel', () => {
    const testVar = channelJoinV2(user.token, thread.channelId);
    expect(testVar).toStrictEqual(ERROR);
  });

  test('Private channel: Request Denied', () => {
    const testVar = channelJoinV2(newUser.token, Pthread.channelId);
    expect(testVar).toStrictEqual(ERROR);
  });
});

describe('Returns Correct Type', () => {
  test('empty object if successful', () => {
    newThread = channelsCreateV2(user.token, 'AlienArmy', true) as ChannelId;
    const testVar = channelJoinV2(newUser.token, newThread.channelId);
    expect(testVar).toStrictEqual({});
  });
});
