import { getData, setData } from './dataStore';
import { isValidChannel, isValidToken, returnChannel, getuId, uIdValid, getUserFromId } from './universalFunctions';
import type { Member, ChannelDetails, Messages, ErrorMessage } from './interface';

/**
 * channelInviteV1
 * Invites a user with ID uId to join a channel with ID channelId.
 * Once invited, the user is added to the channel immediately.
 * In both public and private channels, all members are able to invite users.
 *
 * @param {string} token - token of authorized user
 * @param {number} channelId - Id of channel to invite user to.git
 * @param {number} uId - Id of user to invite.
 * @returns {{error: string}} on error
 * @returns {{}} - No return value if successful.
 */

export function channelInviteV1(token: string, channelId: number, uId: number): (ErrorMessage | Record<string, never>) {
  const data = getData();

  if (token === '') {
    return { error: 'Invalid empty token' };
  }

  // Check if token is valid
  if (!(data.users).find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token))) {
    return {
      error: 'Invalid token: user not found'
    };
  }
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token
  const validUserId = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  // validUserId's uId is invalid (unlikely scenario), valid token should refer to valid uId
  if (validUserId.uId === undefined || validUserId.uId === '') {
    return { error: 'Invalid authId' };
    // channelId does not refer to a valid channel
  } else if ((!(data.channels).find(channel => channel.channelId === channelId)) || channelId === '') {
    return { error: 'Invalid channelId' };
    // uId does not refer to a valid user
  } else if ((!(data.users).find(user => user.uId === uId)) || uId === '') {
    return { error: 'Invalid uId' };
    // If validUserId is identical to uId
  } else if (validUserId.uId === uId) {
    return { error: 'Enter another user uId' };
  }
  for (const channel of data.channels) {
    if (channel.channelId === channelId) {
      // If uId refers to a user already in the channel
      if ((channel.allMembers).find((member: { uId: number }) => member.uId === uId)) {
        return {
          error: 'uId already exists in the channel'
        };
      }
      // If authId is not a member of channel
      if (!(channel.allMembers).find((member: { uId: number }) => member.uId === validUserId.uId)) {
        return {
          error: 'authId is not member of channel'
        };
      }
      // Retrieve the member to be added
      const newUser = data.users.find((user: { uId: number }) => user.uId === uId);
      // Add user details into the array allMembers of channel
      channel.allMembers.push(
        {
          uId: newUser.uId,
          email: newUser.email,
          nameFirst: newUser.nameFirst,
          nameLast: newUser.nameLast,
          handleStr: newUser.handleStr
        }
      );
      // Add channelId to the array channelsJoined of the user
      newUser.channelsJoined.push(channelId);
      setData(data);
      return {
      };
    }
  }
}

/**
 * channelDetailsV1
 * Given a channel with ID channelId that the authorised user is a member of,
 * provides basic details about the channel.
 *
 * @param {string} token - token of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @returns {{error: string}} on error
 * @returns {{
*     name: string,
*     isPublic: boolean,
*     Array{ownerMembers},
*     Array{allMembers}
* }} - Returns name of owner, status of channel, array of owner members
* and followed by an array of all members if successful.
*/
export function channelDetailsV1(token: string, channelId: number): (ChannelDetails|ErrorMessage) {
  // if empty parameter is received
  if (token === '') return { error: 'Empty Token' };

  // valid token check
  const data = getData();
  const theUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (!theUser) return { error: 'Invalid' };

  // valid channel check
  const thread = (data.channels).find(channel => channel.channelId === channelId);
  if (!thread) return { error: 'Channel does not exist' };

  // authorised access check
  const accessUser = thread.ownerMembers.find((accessUser: { uId: number }) => accessUser.uId === theUser.uId);
  if (!accessUser) return { error: 'ID does not have access to requested channel' };

  // returns data successfully

  // remapping owners and members to be shown in correct details spec
  const owners:Member = [];
  const members :Member = [];
  for (const curr of thread.ownerMembers) {
    const tempObj = {
      uId: curr.uId,
      email: curr.email,
      nameFirst: curr.nameFirst,
      nameLast: curr.nameLast,
      handleStr: curr.handleStr,
    };
    owners.push(tempObj);
  }
  for (const curr of thread.allMembers) {
    const tempObj = {
      uId: curr.uId,
      email: curr.email,
      nameFirst: curr.nameFirst,
      nameLast: curr.nameLast,
      handleStr: curr.handleStr,
    };
    members.push(tempObj);
  }
  // remap into details that follows the spec
  const theChannel = {
    name: thread.name,
    isPublic: thread.isPublic,
    ownerMembers: owners,
    allMembers: members
  };
  return theChannel;
}

/**
 * channelJoinV1
 * Given a channelId of a channel that the authorised user can join,
 * adds them to that channel.
 *
 * @param {number} validUserId - Id of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @returns {{error: string}} on error
 * @returns {{}} - No return value if successful.
 */

export function channelJoinV1(token: string, channelId: (number | string)): (ErrorMessage | Record<string, never>) {
  // if empty inputs are given
  if (token === '') return { error: 'Empty Token' };

  // valid token check
  const data = getData();
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (!validUser) return { error: 'Invalid token' };

  // invalid channel
  const thread = data.channels.find(thread => thread.channelId === channelId);
  if (!thread) return { error: 'Invalid channel' };

  // Private Channel Check
  if (thread.isPublic === false) return { error: 'Request Denied: Private Channel' };

  // if validUser is already in the requested channel
  const check = thread.allMembers.find(user => user.uId === validUser.uId);
  if (check) return { error: 'User already exists in the channel' };

  // adding new member to the requested channel and return
  const newMember = {
    uid: validUser.uId,
    tokens: validUser.tokens,
    email: validUser.email,
    nameFirst: validUser.nameFirst,
    nameLast: validUser.nameLast,
    handleStr: validUser.handleStr
  };

  // Iterates to find the requested channel,
  // then push the new member to the all members array of the found channel
  for (const curr of data.channels) {
    if (curr.channelId === channelId) {
      curr.allMembers.push(newMember);
    }
  }
  // iterates to find the user,
  // then push the new joined channel id to the users' channelJoined Arr[]
  for (const curr of data.users) {
    if (curr.uId === validUser.uId) {
      curr.channelsJoined.push(thread.channelId);
    }
  }
  setData(data);
  return {};
}
/**
 * channelMessagesV1
 * Given a channel with ID channelId that the authorised user is a member of,
 * returns up to 50 messages between index "start" and "start + 50".
 * Message with index 0 (i.e. the first element in the returned array of messages)
 * is the most recent message in the channel.
 *
 * This function returns a new index "end".
 * If there are more messages to return after this function call,
 * "end" equals "start + 50".
 * If this function has returned the least recent messages in the channel,
 * "end" equals -1 to indicate that there are no more messages to load after this return.
 *
 * @param {string} token - token of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @param {number} start - starting index of messages
 * @returns {{error: string}} on error
 * @returns {{
 *    Array<{message}>
 *    start: number,
 *    end: number
 * }} - Returns an array of message followed by start and end index,
 * end index is -1 if there are no more messages to load.
 */
export function channelMessagesV1(token: string, channelId: number, start: number): (ErrorMessage | Messages) {
  const data = getData();
  if (!(data.users).find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token))) {
    return {
      error: 'Invalid token: user not found'
    };
  }
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token
  const validUserId = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  const messages: Array<{ messageId: number, uId: number, message: string, timeSent: number}> = [];
  // if ((!(data.channels).find(channel => channel.channelId === channelId)) || channelId === '')
  //  return { error: 'Invalid channelId' };
  // uId does not refer to a valid user

  const currChannel = data.channels.find(channel => channel.channelId === channelId);
  // console.log(currChannel);
  if (!currChannel) {
    return { error: 'Invalid channelId' };
  }
  if (!(currChannel.allMembers.find(member => member.uId === validUserId.uId))) {
    return {
      error: 'authId is not member of channel'
    };
  } if (start < 0) {
    return {
      error: 'Start must be positive number'
    };
    // If start index is 0 and no message exists, return the messages array and indexes instead of error
    // Set the end index to -1 since no messages exist
  }

  data.start = start;
  let end = start + 50;
  if ((start === 0) && ((currChannel.allMessages).length === 0)) {
    data.end = -1;
    setData(data);
    end = data.end;
    return {
      messages,
      start,
      end
    };
  } if (start >= (currChannel.allMessages).length) {
    return {
      error: 'Start index exceeds the number of messages in the channel'
    };
  }
  // retrieves the value of end instead of reference to end
  const tempStart = start.valueOf();
  let messageIndex = 0;
  // const tempEnd = end.valueOf();
  // If authId is not a member of channel
  for (const channel of data.channels) {
    if (channel.channelId === channelId) {
      if (!(channel.allMembers).find((member: { uId: number }) => member.uId === validUserId.uId)) {
        return {
          error: 'authId is not member of channel'
        };
      }
      for (let i = tempStart; i < (channel.allMessages).length; i++, messageIndex++) {
        messages[messageIndex] = channel.allMessages[i];
        // Limit the number of messages to 50
        if (messageIndex === 49) break;
      }

      if (start < (channel.allMessages).length && (channel.allMessages).length <= end) {
        data.end = -1;
        end = data.end;
      }
      setData(data);
      messages.reverse();

      return {
        messages,
        start,
        end
      };
    }
  }
}

export function channelLeaveV1 (token : string, channelId: number) : (ErrorMessage | Record<string, never>) {
  const data = getData();
  // checking that the token is valid
  if (!isValidToken(token)) {
    return { error: 'invalid token' };
  }

  // check that the channel is reffering to a valid channel
  if (!isValidChannel(channelId)) {
    return { error: 'invalid channelId' };
  }

  // getting channel
  const chan = returnChannel(channelId);

  // getting uId of user
  const userId = getuId(token);

  // finding user in channel and removing them
  for (const user of chan.allMembers) {
    if (user.uId === userId) {
      chan.allMembers.splice(user);
      setData(data);
      return {};
    }
  }
  return { error: 'user is not a member!' };
}

export function channelAddOwnerV1 (token: string, channelId: number, uId: number) : (ErrorMessage | Record<string, never>) {
  const data = getData();
  // checking that the token is valid
  if (!isValidToken(token)) {
    return { error: 'invalid token' };
  }

  // check that the channel is reffering to a valid channel
  if (!isValidChannel(channelId)) {
    return { error: 'invalid channelId' };
  }

  // check if the uId is valid
  if (!uIdValid(uId)) {
    return { error: 'invalid uId' };
  }

  // check if user is in the channel
  let isMember: boolean;
  isMember = false;
  const chan = returnChannel(channelId);
  for (const member of chan.allMembers) {
    if (member.uId === uId) {
      isMember = true;
    }
  } if (!isMember) {
    return { error: 'uId refers to user who is not in the channel' };
  }

  // check if authorised user has owner permissions
  let isOwner: boolean;
  isOwner = false;
  const authId = getuId(token);
  for (const owner of chan.ownerMembers) {
    if (owner.uId === authId) {
      isOwner = true;
    }
  } if (!isOwner) {
    return { error: 'autherised user is not an owner' };
  }

  // autherised user is an owner, add user to ownerMembers
  const user = getUserFromId(uId);
  chan.ownerMembers.push(user);
  setData(data);
  return {};
}

export function channelRemoveOwnerV1 (token: string, channelId: number, uId: number) : (ErrorMessage | Record<string, never>) {
  const data = getData();
  // checking that the token is valid
  if (!isValidToken(token)) {
    return { error: 'invalid token' };
  }

  // check that the channel is reffering to a valid channel
  if (!isValidChannel(channelId)) {
    return { error: 'invalid channelId' };
  }

  // check if the uId is valid
  if (!uIdValid(uId)) {
    return { error: 'invalid uId' };
  }

  // check if user is in the channel
  let isMember: boolean;
  isMember = false;
  const chan = returnChannel(channelId);
  for (const member of chan.allMembers) {
    if (member.uId === uId) {
      isMember = true;
    }
  } if (!isMember) {
    return { error: 'user is not in channel' };
  }

  // check if  user/autherised user has owner permissions
  let isOwner: boolean;
  let isAuthOwner: boolean;
  const authuId = getuId(token);
  isAuthOwner = false;
  isOwner = false;

  // looping through
  for (const owner of chan.ownerMembers) {
    if (owner.uId === uId) {
      isOwner = true;
    }
    if (owner.uId === authuId) {
      isAuthOwner = true;
    }
  } if (!isOwner) {
    return { error: 'user is not an owner' };
  } else if (!isAuthOwner) {
    return { error: 'authorised user not an owner' };
  }

  // check if user is the only owner
  if (chan.ownerMembers.length === 1) {
    return { error: 'user is the only owner' };
  }

  // remove the owner
  for (const owner of chan.ownerMembers) {
    if (owner.uId === uId) {
      chan.ownerMembers.splice(owner);
    }
  }
  setData(data);
  return {};
}
