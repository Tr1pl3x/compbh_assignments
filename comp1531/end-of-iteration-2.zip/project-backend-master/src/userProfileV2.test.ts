import { authRegisterV2, userProfileV2, clearV2 } from './testHelpers';
import type { AuthUserId, User } from './interface';

const ERROR = { error: expect.any(String) };

let user1: AuthUserId; // authUserId
let user2: AuthUserId; // uId
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
});

describe('userProfileV2 error scenario', () => {
  test('invalid token', () => {
    expect(userProfileV2(user1.token + 3, user2.authUserId)).toStrictEqual(ERROR);
  });
  test('invalid uId', () => {
    expect(userProfileV2(user1.token, user2.authUserId + 3)).toStrictEqual(ERROR);
  });
  test('invalid token and uId', () => {
    expect(userProfileV2(user1.token + 3, user2.authUserId + 3)).toStrictEqual(ERROR);
  });
  test('empty token', () => {
    expect(userProfileV2('', user2.authUserId)).toStrictEqual(ERROR);
  });
});

describe('userProfileV2 display valid user data', () => {
  test('check uId data', () => {
    const userprofile = userProfileV2(user1.token, user2.authUserId) as User;
    expect(userprofile).toStrictEqual({
      user: {
        uId: userprofile.user.uId,
        nameFirst: userprofile.user.nameFirst,
        nameLast: userprofile.user.nameLast,
        email: userprofile.user.email,
        handleStr: userprofile.user.handleStr,
      }
    });
  });
  test('check authId data', () => {
    const userprofile = userProfileV2(user1.token, user1.authUserId) as User;
    expect(userprofile).toStrictEqual({
      user: {
        uId: userprofile.user.uId,
        nameFirst: userprofile.user.nameFirst,
        nameLast: userprofile.user.nameLast,
        email: userprofile.user.email,
        handleStr: userprofile.user.handleStr,
      }
    });
  });
});
