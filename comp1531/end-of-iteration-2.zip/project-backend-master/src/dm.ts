// import data types
import type {
  UID,
  UIDs,
  DM,
  DMs,
  DmID,
  DmDetails,
  Member,
  User,
  Users,
  ErrorMessage
} from './interface';

// import functions
import { getData, setData } from './dataStore';

/**
 * /dm/create/v1
 * uIds contains the user(s) that this DM is directed to,
 * and will not include the creator. The creator is the
 * owner of the DM. name should be automatically generated
 * based on the users that are in this DM. The name should
 * be an alphabetically-sorted, comma-and-space-separated
 * list of user handles, e.g. 'ahandle1, bhandle2, chandle3'.
 * An empty uIds list indicates the creator is the only
 * member of the DM.
 *
 * @param {string} token - token of a user who requests to create
 * @param {number} uId - obtains ids of users, to be added in the new dm.
 * @returns {{error: string}} on error
 * @returns {{dmId}} - returns the dmId if successful.
*/
export function dmCreateV1(token: string, uId:UIDs): (DmID | ErrorMessage) {
  // empty case for the token
  if (token === '') return { error: 'Empty Token' };

  const data = getData();
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token
  const creator = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  // validate the token
  if (!creator) return { error: 'Invalid Token' };
  const names = [];
  names.push(creator.handleStr);

  // updates the all member array of the new dm
  const tempArr : Users = [];
  tempArr.push(creator);

  // Validation for uId parameter
  // if empty, the function will proceed to create a new dm
  // if not, the users in the array will be validated.
  if (uId.length > 0) {
    // checks for duplicate ids in the given array
    const uniqueIds: Set<UID> = new Set(uId);
    if (uniqueIds.size !== uId.length) return { error: 'Duplicate Ids were given!' };

    for (const curr of uId) {
      const find = data.users.find(users => users.uId === curr);
      if (find) {
        // checks for creator's id is in the given uIds array.
        if (find.uId === creator.uId) return { error: 'creator id must not be given' };
        tempArr.push(find);
        names.push(find.handleStr);
        // checks if given id from the array is not valid
      } else {
        return { error: 'given invalid uId' };
      }
    }
  }

  // generates an id for the new dm
  const newId:number = Math.floor(Math.random() * 1000000000);
  // generates the new name of the dm
  const newName: string = names.sort().join(',');
  // updates the owner array of the new dm
  const owner : User = [];
  owner.push(creator);
  // creates a new DM object to be updated into data store
  const newDm : DM = {
    dmId: newId,
    name: newName,
    ownerMembers: owner,
    allMembers: tempArr,
    allMessages: []
  };
  data.dms.push(newDm);
  setData(data);
  return { dmId: newId };
}

/**
* /dm/details/v1
* Given a DM with ID dmId that the authorised user is a
* member of, provide basic details about the DM.
*
* @param {string} token - token of a user who requests to create
* @param {number} dmId - obtains id of the dm that is to be viewd.
* @returns {{error: string}} on error
* @returns {{DmDetails}} - returns the detail of the requested dm if successful.
 */
export function dmDetailsV1(token: string, dmId: number): (ErrorMessage|DmDetails) {
  // empty check
  if (token === '') return { error: 'Empty Token' };

  const data = getData();
  // valid token check
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (!validUser) return { error: 'Invalid token' };

  // valid dmId check
  const validDM = data.dms.find(dm => dm.dmId === dmId);
  if (!validDM) return { error: 'Invalid Dm' };

  // authorised access check
  if (!(validDM.allMembers.find(access => access.uId === validUser.uId))) {
    return { error: 'Unauthorised access in a valid dm' };
  }

  // proceeds to get details
  // remaps into details that follows the spec.
  const tempArr: Member = [];
  for (const curr of validDM.allMembers) {
    const tempObj = {
      uId: curr.uId,
      email: curr.email,
      nameFirst: curr.nameFirst,
      nameLast: curr.nameLast,
      handleStr: curr.handleStr,
    };
    tempArr.push(tempObj);
  }
  const theDetails: DmDetails = {
    name: validDM.name,
    members: tempArr,
  };
  return theDetails;
}

/**
* /dm/leave/v1
* Given a DM ID, the user is removed as a member of this DM.
* The creator is allowed to leave and the DM will still exist
* if this happens. This does not update the name of the DM.
*
* @param {string} token - token of a user who requests to create
* @param {number} dmId - obtains id of the dm that is to be viewd.
* @returns {{error: string}} on error
* @returns {} - returns empty object if successful.
 */
export function dmLeaveV1(token: string, dmId: number): (ErrorMessage | Record<string, never>) {
  // empty check
  if (token === '') return { error: 'Empty Token' };

  // valid token check
  const data = getData();
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (!validUser) return { error: 'Invalid token' };

  // valid dmId check
  const validDM = data.dms.find(dm => dm.dmId === dmId);
  if (!validDM) return { error: 'Invalid Dm' };

  // authorised access check
  const access = validDM.allMembers.find(user => user.uId === validUser.uId);
  if (!access) {
    return { error: 'Unauthorised access in a valid dm' };
  }

  // clears the owner and members of the requested dm
  for (const curr of data.dms) {
    if (curr.dmId === dmId) {
      curr.ownerMembers = [];
      curr.allMembers = [];
      break;
    }
  }
  setData(data);
  return {};
}

/**
 * /dm/list/v1
 * Returns the list of DMs that the user is a member of.
 *
 * @param {string} token - token of a user
 * @returns {{error: string}} on error
 * @returns {DMs} - returns the detail of the requested dm if successful.
 */
export function dmListV1(token:string):(DMs|ErrorMessage) {
  // empty check
  if (token === '') return { error: 'Empty Token' };

  // valid token check
  const data = getData();
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  if (!validUser) return { error: 'Invalid token' };

  // check if user is in any of the dms in dataStore
  // if user is a member, the dm is saved into temp array.
  const returnArr: DMs = [];
  for (const curr of data.dms) {
    if (curr.allMembers.find(user => user.uId === validUser.uId)) {
      returnArr.push(curr);
    }
  }

  return returnArr;
}

export function dmRemoveV1(token: string, dmId: number): (ErrorMessage | Record<string, never>) {
  // empty case for the token
  if (token === '') return { error: 'Empty Token' };
  const data = getData();
  // console.log(data.dms)

  // valid dmId check
  const validDM = data.dms.find(dm => dm.dmId === dmId);
  if (!validDM) return { error: 'Invalid Dm' };

  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  if (!validUser) return { error: 'Invalid token' };

  // // authorised access check
  // const access = validDM.allMembers.find(a => a.uId === validUser.uId);
  const access = validDM.allMembers.find(user => user.uId === validUser.uId);
  if (!access) return { error: 'U aint my member' };

  // const access = validDM.allMembers.find(a => a.uId === validUser.uId);
  const ownerSearch = validDM.ownerMembers.find(user => user.uId === validUser.uId);
  if (!ownerSearch) return { error: 'U aint my owner' };

  // remove all the dm
  for (let i = 0; i < data.dms.length; i++) {
    if (data.dms[i].dmId === dmId) {
      data.dms.splice(i, 1);
      setData(data);
    }
  }
  return {};
}
