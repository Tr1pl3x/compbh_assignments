import express, { json, Request, Response } from 'express';
import { echo } from './echo';
import morgan from 'morgan';
import config from './config.json';
import cors from 'cors';

import { authRegisterV1, authLogOutV1 } from './auth';
import { channelsCreateV1, channelsListV1, channelsListAllV1 } from './channels';
import {
  channelDetailsV1,
  channelInviteV1,
  channelMessagesV1,
  channelLeaveV1,
  channelAddOwnerV1,
  channelRemoveOwnerV1,
  channelJoinV1,
} from './channel';
import { userProfileV1 } from './users';
import { messageSendV1, messageRemoveV1, messageEditV1, messageSenddmV1 } from './message';
import { clearV1 } from './other';
// import { usersAllV1 } from './usersAll';
import { dmCreateV1, dmDetailsV1, dmLeaveV1, dmListV1 } from './dm';
import { dmRemoveV1 } from './dm';
import { userProfileSethandleV1, userProfileSetemailV1 } from './user';

// Set up web app
const app = express();
// Use middleware that allows us to access the JSON body of requests
app.use(json());
// Use middleware that allows for access from other domains
app.use(cors());
// for logging errors (print to terminal)
app.use(morgan('dev'));

const PORT: number = parseInt(process.env.PORT || config.port);
const HOST: string = process.env.IP || 'localhost';

const server = app.listen(PORT, HOST, () => {
  // DO NOT CHANGE THIS LINE
  console.log(`⚡️ Server started on port ${PORT} at ${HOST}`);
});

// For coverage, handle Ctrl+C gracefully
process.on('SIGINT', () => {
  server.close(() => console.log('Shutting down server gracefully.'));
});

// Example get request
app.get('/echo', (req: Request, res: Response, next) => {
  const data = req.query.echo as string;
  return res.json(echo(data));
});
// app.post('/auth/register/v2', (req: Request, res: Response, next) => {
//   const { email, password, nameFirst, nameLast } = req.body;
//   return res.json(authRegisterV1(email, password, nameFirst, nameLast));
// });

// // get route for retrieving users
// app.get('/users/all/v1', (req, res) => {
//   const token = req.query.token as string;
app.delete('/clear/v2', (req, res) => {
  res.json(clearV1());
});

// // 1st one: server connecting for /auth/login/v2
// app.post('/auth/login/v2', (req: Request, res: Response, next) => {
//   const { email, password } = req.body;
//   const ret = authLoginV1(email, password);

//   res.json({
//     token: ret.token,
//     authUserId: ret.authUserId,
//   });
//   // return res.(jsonauthLoginV1(email, password));
// });

// get route for retrieving users
// app.get('/users/all/v1', (req, res) => {
//   const token = req.query.token as string;
// })

//   if (typeof token === 'string') {
//     const result = usersAllV1(token);
//     // if there is an error in { users } return 401 error
//     // otherwise return { users }
//     if ('error' in result) {
//       res.status(401).send(result);
//     } else {
//       res.send(result);
//     }
//   } else {
//     // if token is invalid, return error message
//     res.status(400).send({ error: 'Invalid token' });
//   }
// });

// start server

// route for ClearV1
app.delete('/clear/v1', (req, res) => {
  res.json(clearV1());
});

// route for channelsCreateV2
app.post('/channels/create/V2', (req, res) => {
  const { token, name, isPublic } = req.body;
  res.json(channelsCreateV1(token, name, isPublic));
});

// route for authRegisterV1
app.post('/auth/register/v2', (req, res) => {
  const { email, password, nameFirst, nameLast } = req.body;
  res.json(authRegisterV1(email, password, nameFirst, nameLast));
});

// route for channelsList
app.get('/channels/list/v2', (req, res) => {
  const token = req.query.token as string;
  res.json(channelsListV1(token));
});

// route for channelsLeaveV1
app.post('/channel/leave/v1', (req, res) => {
  const { token, channelId } = req.body;
  res.json(channelLeaveV1(token, channelId));
});

// route for dmCreateV1
app.post('/dm/create/v1', (req, res) => {
  const { token, uId } = req.body;
  res.json(dmCreateV1(token, uId));
});

// route for channelDetailsV2
app.get('/channel/details/v2', (req, res) => {
  const token = req.query.token as string;
  const channelId = req.query.channelId as number;
  const returnVar = channelDetailsV1(token, parseInt(channelId));
  res.json(returnVar);
});

// route for /channelsListAllV2
app.get('/channels/listall/v2', (req, res) => {
  const token = req.query.token as string;
  res.json(channelsListAllV1(token));
});

// route for authLogoutV1
app.post('/auth/logout/v1', (req, res) => {
  const token = req.query.token as string;
  res.json(authLogOutV1(token));
});

// route for channelInviteV2
app.post('/channel/invite/v2', (req: Request, res: Response, next) => {
  const token = req.body.token as string;
  const channelId = req.body.channelId as number;
  const uId = req.body.uId as number;
  res.json(channelInviteV1(token, channelId, uId));
});

// route for channelJoinV2
app.post('/channel/join/v2', (req: Request, res: Response, next) => {
  const token = req.body.token as string;
  const channelId = req.body.channelId as number;
  res.json(channelJoinV1(token, parseInt(channelId)));
});

// route for channelMessagesV2
app.get('/channel/messages/v2', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  const channelId = req.query.channelId as number;
  const start = req.query.start as number;
  res.json(channelMessagesV1(token, parseInt(channelId), parseInt(start)));
});

// route for messageSendV1
app.post('/message/send/v1', (req: Request, res: Response, next) => {
  const token = req.body.token as string;
  const channelId = req.body.channelId as number;
  const message = req.body.message as string;
  res.json(messageSendV1(token, channelId, message));
});

app.put('/message/edit/v1', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  const messageId = req.query.messageId as number;
  const message = req.query.message as string;
  res.json(messageEditV1(token, parseInt(messageId), message));
});

app.delete('/message/remove/v1', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  const messageId = req.query.messageId as number;
  res.json(messageRemoveV1(token, parseInt(messageId)));
});

app.post('/message/senddm/v1', (req: Request, res: Response, next) => {
  const token = req.body.token as string;
  const dmId = req.body.dmId as number;
  const message = req.body.message as string;
  res.json(messageSenddmV1(token, dmId, message));
});

// route for channelAddOwnerV1
app.post('/channel/addowner/v1', (req, res) => {
  const { token, channelId, uId } = req.body;
  res.json(channelAddOwnerV1(token, channelId, uId));
});

// route for dmDetailsv1
app.get('/dm/details/v1', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  const dmId = req.query.dmId as number;
  res.json(dmDetailsV1(token, parseInt(dmId)));
});

// route for dmLeaveV1
app.post('/dm/leave/v1', (req: Request, res: Response, next) => {
  const token = req.body.token as string;
  const dmId = req.body.dmId as number;
  res.json(dmLeaveV1(token, parseInt(dmId)));
});

// route for dmListV1
app.get('/dm/list/v1', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  res.json(dmListV1(token));
});

app.post('/channel/removeowner/v1', (req, res) => {
  const { token, channelId, uId } = req.body;
  res.json(channelRemoveOwnerV1(token, channelId, uId));
});

app.get('/user/profile/v2', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  const uId = req.query.uId as number;
  res.json(userProfileV1(token, parseInt(uId)));
});

app.delete('/dm/remove/v1', (req, res, next) => {
  const token = req.query.token as string;
  const dmId = req.query.dmId as number;
  res.json(dmRemoveV1(token, parseInt(dmId)));
});

app.put('/user/profile/sethandle/v1', (req, res, next) => {
  const token = req.query.token as string;
  const handleStr = req.query.handleStr as string;
  res.json(userProfileSethandleV1(token, handleStr));
});

app.put('/user/profile/setemail/v1', (req, res, next) => {
  const token = req.query.token as string;
  const email = req.query.email as string;
  res.json(userProfileSetemailV1(token, email));
});
