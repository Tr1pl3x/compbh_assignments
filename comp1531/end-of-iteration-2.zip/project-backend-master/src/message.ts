import { getData, setData } from './dataStore';

import type { MessageReturn, ErrorMessage } from './interface';

/**
 * messageSendV1
 * Send a message from the authorised user to the channel specified by channelId.
 * Note: Each message should have its own unique ID, i.e.
 * no messages should share an ID with another message,
 * even if that other message is in a different channel.
 * @param {string} token - token of authorized user
 * @param {number} channelId - Id of channel to send message to.
 * @param {string} message - New message to be sent
 * @returns {{error: string}} on error
 * @returns {{messageId: number}} - Returns corresponding messageId of the message just sent
 */

export function messageSendV1(token: string, channelId: number, message: string): (ErrorMessage | MessageReturn) {
  const data = getData();

  if (token === '') {
    return { error: 'Invalid token' };
  }
  // Check if token is valid

  if (!(data.users).find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token))) {
    return { error: 'Invalid token: user not found' };
  }
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token

  const authUserId = data.users.find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  // channelId does not refer to a valid channel
  const currChannel = (data.channels).find((channel: { channelId: number }) => channel.channelId === channelId);
  if ((!(currChannel))) {
    return { error: 'Invalid channelId' };
  }
  if (authUserId.uId === undefined) {
    return { error: 'Invalid authId' };
  }
  if (message.length > 1000) {
    return { error: 'Message cannot be more than 1000 characters' };
  }
  if (message.length < 1) {
    return { error: 'Message cannot be empty' };
  }

  const messageId = Math.floor(Math.random() * 1000000000);
  const timeSent = Math.floor(Date.now() / 1000);

  for (const channel of data.channels) {
    if (channel.channelId === channelId) {
      // If authId is not a member of channel

      const channelMember = (channel.allMembers).find((member: { uId: number }) => member.uId === authUserId.uId);
      if ((channelMember) === undefined) {
        return {
          error: 'authId is not member of channel'
        };
      }
      // Add user details into the array allMembers of channel
      channel.allMessages.push(
        {
          messageId: messageId,
          uId: authUserId.uId,
          message: message,
          timeSent: timeSent
        }
      );
      setData(data);
      return { messageId };
    }
  }
}

/**
 * messageSenddmV1
 * Send a message from authorised user to the DM specified by dmId. Note: Each message should have it's own unique ID,
 * i.e. no messages should share an ID with another message, even if that other message is in a different channel or
 * DM.s -1 to indicate that there are no more messages to load after this return.
 * @param {string} token - token of authorized user
 * @param {number} dmId - Id of DM to send message to.
 * @param {string} message - message to be sent to DM
 * @returns {{error: string}} on error
 * @returns {{
*   messageId: number
* }} - Returns the corresponding messageId that just created
*/

export function messageSenddmV1(token: string, dmId: number, message: string): (ErrorMessage | MessageReturn) {
  const data = getData();

  if (token === '') {
    return { error: 'Invalid token' };
  }
  // Check if token is valid

  if (!(data.users).find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token))) {
    return { error: 'Invalid token: user not found' };
  }
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token

  const authUserId = data.users.find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  // channelId does not refer to a valid channel
  const currDm = (data.dms).find((dm: { dmId: number }) => dm.dmId === dmId);
  if ((!(currDm))) {
    return { error: 'Invalid dmId' };
  }
  if (authUserId.uId === undefined) {
    return { error: 'Invalid authId' };
  }
  if (message.length > 1000) {
    return { error: 'Message cannot be more than 1000 characters' };
  }
  if (message.length < 1) {
    return { error: 'Message cannot be empty' };
  }

  const messageId = Math.floor(Math.random() * 1000000000);
  const timeSent = Math.floor(Date.now() / 1000);

  for (const dm of data.dms) {
    if (dm.dmId === dmId) {
      // If authId is not a member of channel

      const dmMember = (dm.allMembers).find((member: { uId: number }) => member.uId === authUserId.uId);
      if (dmMember === undefined) {
        return {
          error: 'authId is not member of channel'
        };
      }
      // Add user details into the array allMembers of channel
      dm.allMessages.push(
        {
          messageId: messageId,
          uId: authUserId.uId,
          message: message,
          timeSent: timeSent
        }
      );
      setData(data);
      return { messageId };
    }
  }
}

/**
 * messageEditV1
 * Given a message, update its text with new text. If the new message is an empty string, the message is deleted.
 * @param {string} token - token of authorized user
 * @param {number} messageId - Id of mesage to be edited
 * @param {string} message - new message to be replaced
 * @returns {{error: string}} on error
 * @returns {{}} - empty object if successful
*/

export function messageEditV1(token: string, messageId: number, message: string): (ErrorMessage | Record<string, never>) {
  const data = getData();

  if (token === '') {
    return { error: 'Invalid token' };
  }
  // Check if token is valid
  if (!(data.users).find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token))) {
    return { error: 'Invalid token: user not found' };
  }
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token

  const authUserId = data.users.find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  // const messageOwner = data.channels.find((channel: { allMessages: { messageId: number, uId: number }[] }) =>
  //   channel.allMessages.find((message: { messageId: number, uId: number }) => message.messageId === messageId && message.uId === authUserId.uId));

  if (!(data.channels.find((channel: { allMessages: { messageId: number }[] }) => channel.allMessages.find((message: { messageId: number }) => message.messageId === messageId)))) {
    return { error: 'Message does not exist' };
  }
  if (authUserId.uId === undefined) {
    return { error: 'Invalid authId' };
  }
  if (message.length > 1000) {
    return { error: 'Message cannot be more than 1000 characters' };
  }
  if (message.length < 1) {
    return { error: 'Message cannot be empty' };
  }

  const channel = data.channels.find((c) => c.allMessages.find((m: { messageId: number }) => m.messageId === messageId));

  if (!channel) {
    const dm = data.dms.find((d) => d.allMessages.find((m: { messageId: number }) => m.messageId === messageId));
    if (!dm) {
      return { error: 'Message with ID messageId does not exist' };
    }
    if (dm.allMessages.find((m: { messageId: number }) => m.messageId === messageId).uId !== authUserId.uId) {
      return { error: 'Message with ID: messageId was not sent by the authorised user' };
    }
    if (!(dm.ownerMembers.find((member: { uId: number }) => member.uId === authUserId.uId))) {
      return { error: 'User is not owner of DM' };
    }
    const dmMessage = dm.allMessages.find((m: { messageId: number }) => m.messageId === messageId);
    if (message === '') {
      dm.allMessages.splice(dm.allMessages.indexOf(dmMessage), 1);
      setData(data);
      return {};
    }
    dmMessage.message = message;
    setData(data);
    return {};
  }

  if (channel.allMessages.find((m: { messageId: number }) => m.messageId === messageId).uId !== authUserId.uId) {
    return { error: 'Message with ID: messageId was not sent by the authorised user' };
  }
  if (!(channel.ownerMembers.find((member: { uId: number }) => member.uId === authUserId.uId))) {
    return { error: 'User is not owner of channel' };
  }
  const channelMessage = channel.allMessages.find((m: { messageId: number }) => m.messageId === messageId);
  if (message === '') {
    channel.allMessages.splice(channel.allMessages.indexOf(channelMessage), 1);
    setData(data);
    return {};
  }
  channelMessage.message = message;
  setData(data);
  return {};
}

/**
 * messageRemoveV1
 * Given a messageId for a message, this message is removed from the channel/DM
 * @param {string} token - token of authorized user
 * @param {number} messageId - Id of mesage to be removed
 * @returns {{error: string}} on error
 * @returns {{}} - empty object if successful
*/

export function messageRemoveV1(token: string, messageId: number): (ErrorMessage | Record<string, never>) {
  const data = getData();

  if (token === '') {
    return { error: 'Invalid token' };
  }
  // Check if token is valid
  if (!(data.users).find((user: {uId: number}) => user.tokens.find((t: {token: string}) => t.tokenId === token))) {
    return { error: 'Invalid token: user not found' };
  }
  // If token is indeed valid, and corresponds to a user,
  // return user object with corresponding uId of given token
  const authUserId = data.users.find((user: {uId: number}) => user.tokens.find((t: {token: string}) => t.tokenId === token));
  // const messageOwner = data.channels.find((channel: { allMessages: { messageId: number, uId: number }[] }) =>
  //   channel.allMessages.find((message: { messageId: number, uId: number }) => message.messageId === messageId && message.uId === authUserId.uId));

  if (!(data.channels.find((channel: { allMessages: { messageId: number }[] }) => channel.allMessages.find((message: { messageId: number }) => message.messageId === messageId)))) {
    return { error: 'Message with ID messageId does not exist' };
  }
  if (authUserId.uId === undefined) {
    return { error: 'Invalid authId' };
  }

  const channel = data.channels.find((channel) => channel.allMessages.find((message: {messageId: number}) => message.messageId === messageId));

  if (!channel) {
    const dm = data.dms.find((dm: {dmId: number}) => dm.allMessages.find((message: {messageId: number}) => message.messageId === messageId));
    if (!dm) {
      return { error: 'Message with ID messageId does not exist' };
    }
    if (dm.allMessages.find((m: {messageId: number}) => m.messageId === messageId).uId !== authUserId.uId) {
      return { error: 'Message with ID: messageId was not sent by the authorised user' };
    }
    if (!(dm.ownerMembers.find((member: { uId: number }) => member.uId === authUserId.uId))) {
      return { error: 'User is not owner of DM' };
    }
    const dmMessage = dm.allMessages.find((m: { messageId: number }) => m.messageId === messageId);
    dm.allMessages.splice(dm.allMessages.indexOf(dmMessage), 1);
    setData(data);
    return {};
  }
  if (channel.allMessages.find((m: { messageId: number }) => m.messageId === messageId).uId !== authUserId.uId) {
    return { error: 'Message with ID: messageId was not sent by the authorised user' };
  }
  if (!(channel.ownerMembers.find((member: { uId: number }) => member.uId === authUserId.uId))) {
    return { error: 'User is not owner of channel' };
  }
  const channelMessage = channel.allMessages.find((m: { messageId: number }) => m.messageId === messageId);
  channel.allMessages.splice(channel.allMessages.indexOf(channelMessage), 1);
  setData(data);
  return {};
}
