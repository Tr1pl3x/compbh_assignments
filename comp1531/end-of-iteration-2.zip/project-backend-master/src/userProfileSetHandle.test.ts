import { userProfileSethandleV1 } from './testHelpers';
import { clearV2 } from './testHelpers';
import { authRegisterV2 } from './testHelpers';

import type { AuthUserId } from './interface';

// const ERROR = { error: expect.any(String) };

let user1: AuthUserId; // authUserId

beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  // user2 = authRegisterV1('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
  // console.log(user1)
});

describe('changer user display name', () => {
  test('profile handle', () => {
    const changeUser = userProfileSethandleV1(user1.token, 'Babuu');
    console.log(changeUser);
    expect(changeUser).toStrictEqual({});
  });

  test('profile handle', () => {
    const changeUser = userProfileSethandleV1(user1.token, 'BO');
    console.log(changeUser);
    expect(changeUser).toStrictEqual({ error: 'handle length issue' });
  });
});
