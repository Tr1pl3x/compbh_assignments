import { authRegisterV2, channelsCreateV2, clearV2 } from './testHelpers';
import type { AuthUserId, ChannelId } from './interface';

interface SendMessageReturn {
  messageId: number;
}

const ERROR = { error: expect.any(String) };

import { channelMessagesV2, messageSendV1, messageRemoveV1 } from './testHelpers';
let user1: AuthUserId; // token
let user2: AuthUserId; // uId
let channel1: ChannelId; // channelId
// let dm1: DmID; // dmId
let sendMessage1: SendMessageReturn;
beforeEach(() => {
  clearV2();
  user1 = authRegisterV2('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV2('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
  channel1 = channelsCreateV2(user1.token, 'New Channel', true) as ChannelId;
  // dm1 = dmCreateV1(user1.token, [user1.authUserId, user2.authUserId]) as DmID;
  sendMessage1 = messageSendV1(user1.token, channel1.channelId, 'testmessage') as SendMessageReturn;
});
describe('messageSendV1 Tests', () => {
  test('Error: empty token', () => {
    expect(messageRemoveV1('', sendMessage1.messageId)).toStrictEqual(ERROR);
  });
  test('Error: invalid token', () => {
    expect(messageRemoveV1(user1.token + 1, sendMessage1.messageId)).toStrictEqual(ERROR);
  });
  test('Error: invalid messageId', () => {
    expect(messageRemoveV1(user1.token, sendMessage1.messageId + 3)).toStrictEqual(ERROR);
  });
  test('Error: authId attempts to remove another user message', () => {
    expect(messageRemoveV1(user2.token, sendMessage1.messageId)).toStrictEqual(ERROR);
  });
  test('Valid: authUser remove their message', () => {
    messageRemoveV1(user1.token, sendMessage1.messageId);
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: [],
        start: 0,
        end: -1,
      })
    );
  });
  test('Valid: authUser remove 2nd message, 1st message remains', () => {
    const sendMessage2 = messageSendV1(user1.token, channel1.channelId, 'Hi this is a 2nd message') as SendMessageReturn;
    messageRemoveV1(user1.token, sendMessage2.messageId);
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: sendMessage1.messageId,
            uId: user1.authUserId,
            message: 'testmessage',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
  test('Valid: authUser creates 2nd message, removes it', () => {
    const sendMessage2 = messageSendV1(user1.token, channel1.channelId, 'Hi this is a 2nd message') as SendMessageReturn;
    messageRemoveV1(user1.token, sendMessage2.messageId);
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: sendMessage1.messageId,
            uId: user1.authUserId,
            message: 'testmessage',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
  test('Valid: authUser creates 2nd message, removes the first one', () => {
    const sendMessage2 = messageSendV1(user1.token, channel1.channelId, 'Hi this is a 2nd message') as SendMessageReturn;
    messageRemoveV1(user1.token, sendMessage1.messageId);
    expect(channelMessagesV2(user1.token, channel1.channelId, 0)).toStrictEqual(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            messageId: sendMessage2.messageId,
            uId: user1.authUserId,
            message: 'Hi this is a 2nd message',
            timeSent: expect.any(Number),
          })
        ]),
        start: 0,
        end: -1,
      })
    );
  });
});

// Test message added using messagesCreateV1
// If message is exactly 50
// If message is below 50
// if Message is between 50 and 100
// If message is above 100
// if message is above 200
