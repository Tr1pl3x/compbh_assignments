import request from 'sync-request';
import config from './config.json';
// import stringify from 'json-stringify-safe';
// import flatted from 'flatted';
// import CircularJSON from 'circular-json';
export const URL = `${config.url}:${config.port}`;

export function authRegisterV2(email: string, password: string, nameFirst: string, nameLast: string) {
  const json = {
    email,
    password,
    nameFirst,
    nameLast,
  };
  const res = request(
    'POST',
        `${URL}/auth/register/v2`,
        {
          json,
        }
  );
  return JSON.parse(res.getBody() as string);
}

export function channelsCreateV2 (token : string, name : string, isPublic?: boolean) {
  const res = request(
    'POST',
    URL + '/channels/create/v2',
    {
      json: {
        token: token,
        name: name,
        isPublic: isPublic
      }
    }
  );
  return JSON.parse(res.getBody() as string);
}

export function clearV2() {
  const res = request(
    'DELETE',
    `${URL}/clear/v2`
  );
  return JSON.parse(res.getBody() as string);
}

export function channelsListV2 (token : string) {
  const res = request(
    'GET',
    URL + '/channels/list/v2',
    {
      qs: {
        token: token,
      }
    }
  );
  return JSON.parse(res.getBody() as string);
}

export function clearData() {
  request(
    'DELETE',
    URL + '/clear/v1'
  );
}

export function channelsListAllV2(token: string) {
  const res = request(
    'GET',
    URL + '/channels/listall/v2',
    {
      qs: {
        token: token,
      },
    }
  );
  return JSON.parse(res.getBody() as string);
}

export function authLogOutV1(token: string) {
  const res = request(
    'POST',
    URL + '/auth/logout/v1',
    {
      qs: {
        token,
      },
    }
  );
  return JSON.parse(res.getBody() as string);
}

export function authLoginV2(email: string, password: string) {
  const json = {
    email,
    password,
  };
  const res = request(
    'POST',
        `${URL}/auth/login/v2`,
        {
          json,
        }
  );
  return JSON.parse(res.getBody() as string);
}

export function channelsListAllV1(token: string) {
  const res = request(
    'GET',
    `${URL}/channels/listall/v2`,
    {
      json: {
        token,
      },
    }
  );
  return JSON.parse(res.body as string);
}

export function channelLeaveV1(token: string, channelId: number) {
  const res = request(
    'POST',
    `${URL}/channel/leave/v1`,
    {
      json: {
        token: token,
        channelId: channelId
      }
    }
  );
  return JSON.parse(res.body as string);
}

export function channelInviteV2(token: string, channelId: number, uId: number) {
  const res = request(
    'POST',
      `${URL}/channel/invite/v2`,
      {
        json: {
          token,
          channelId,
          uId,
        },
      }
  );
  return JSON.parse(res.body as string);
}

export function channelMessagesV2(token: string, channelId: number, start: number) {
  const res = request(
    'GET',
      `${URL}/channel/messages/v2`,
      {
        qs: {
          token,
          channelId,
          start
        },
      }
  );
  return JSON.parse(res.body as string);
}

export function dmCreateV1(token: string, uId : Array<number>) {
  const json = { token, uId };
  const res = request(
    'POST',
        `${URL}/dm/create/v1`,
        {
          json
        }
  );
  return JSON.parse(res.getBody() as string);
}

export function channelDetailsV2(token: string, channelId: number) {
  const res = request('GET', `${URL}/channel/details/v2`, { qs: { token, channelId } });
  return JSON.parse(res.getBody() as string);
}

export function messageSendV1(token: string, channelId: number, message: string) {
  const res = request(
    'POST',
      `${URL}/message/send/v1`,
      {
        json: {
          token,
          channelId,
          message,
        },
      }
  );
  return JSON.parse(res.getBody() as string);
}
export function dmLeaveV1(token: string, dmId: number) {
  const json = {
    token, dmId
  };
  const res = request(
    'POST',
    `${URL}/dm/leave/v1`,
    {
      json
    }
  );
  return JSON.parse(res.body as string);
}

export function messageEditV1(token: string, messageId: number, message: string) {
  const res = request(
    'PUT',
      `${URL}/message/edit/v1`,
      {
        qs: {
          token,
          messageId,
          message,
        },
      }
  );
  return JSON.parse(res.getBody() as string);
}

export function messageRemoveV1(token: string, messageId: number) {
  const res = request(
    'DELETE',
      `${URL}/message/remove/v1`,
      {
        qs: {
          token,
          messageId,
        },
      }
  );
  return JSON.parse(res.getBody() as string);
}

export function messageSenddmV1(token: string, dmId: number, message: string) {
  const res = request(
    'POST',
      `${URL}/message/senddm/v1`,
      {
        json: {
          token,
          dmId,
          message,
        },
      }
  );
  return JSON.parse(res.body as string);
}

export function channelAddOwnerV1(token: string, channelId: number, uId: number) {
  const res = request(
    'POST',
    `${URL}/channel/addowner/v1`,
    {
      json: {
        token: token,
        channelId: channelId,
        uId: uId
      }
    }
  );
  return JSON.parse(res.body as string);
}

export function channelRemoveOwnerV1(token: string, channelId: number, uId: number) {
  const res = request(
    'POST',
    `${URL}/channel/removeowner/v1`,
    {
      json: {
        token: token,
        channelId: channelId,
        uId: uId
      }
    }
  );
  return JSON.parse(res.body as string);
}

export function dmDetailsV1(token: string, dmId: number) {
  const qs = { token, dmId };
  const res = request(
    'GET',
      `${URL}/dm/details/v1`,
      {
        qs
      }
  );
  return JSON.parse(res.body as string);
}

export function dmListV1(token: string) {
  const qs = { token };
  const res = request(
    'GET',
      `${URL}/dm/list/v1`,
      {
        qs
      }
  );
  return JSON.parse(res.body as string);
}

export function channelJoinV2(token: string, channelId: number) {
  const res = request(
    'POST',
    `${URL}/channel/join/v2`,
    {
      json: {
        token,
        channelId
      }
    }
  );
  return JSON.parse(res.body as string);
}

export function userProfileV2(token: string, uId: number) {
  const res = request(
    'GET',
      `${URL}/user/profile/v2`,
      {
        qs: {
          token,
          uId,
        },
      }
  );
  return JSON.parse(res.body as string);
}

export function dmRemoveV1(token: string, dmId: number) {
  const qs = { token, dmId };
  const res = request(
    'DELETE',
        `${URL}/dm/remove/v1`,
        {
          qs
        }
  );
  return JSON.parse(res.getBody() as string);
}

export function userProfileSethandleV1(token: string, handleStr:string) {
  const res = request(
    'PUT',
    `${URL}/user/profile/sethandle/v1`,
    {
      qs: {
        token,
        handleStr
      }
    }
  );
  return JSON.parse(res.getBody() as string);
}

export function userProfileSetemailV1(token: string, email: string) {
  const res = request(
    'PUT',
    `${URL}/user/profile/setemail/v1`,
    {
      qs: {
        token,
        email
      },
    }
  );
  return JSON.parse(res.getBody() as string);
}
