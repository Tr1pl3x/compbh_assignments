// import { channelInviteV1 } from './channel';
// import { channelDetailsV1 } from './channel'; // check all Members
// import { authRegisterV1 } from './auth';
// import { channelsCreateV1 } from './channels';
// import { clearV1 } from './other';
// import type { AuthUserId, Channels, ChannelDetails } from './interface';

// const ERROR = { error: expect.any(String) };

// let user1: AuthUserId; // authUserId
// let user2: AuthUserId; // uId
// let user3: AuthUserId;
// let channel1: Channels; // channelId
// let channel2: Channels;
// beforeEach(() => {
//   clearV1();
//   user1 = authRegisterV1('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV1('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
//   user3 = authRegisterV1('test3@gmail.com', '1231231234', 'Dean', 'Wunder') as AuthUserId;
//   channel1 = channelsCreateV1(user1.authUserId, 'New Channel', true) as Channels;
//   channel2 = channelsCreateV1(user2.authUserId, 'New channel2lId', true) as Channels;
// });

// describe('Error scenario', () => {
//   // Return object {error: 'error'} channelId does not refer to a valid channel
//   test('invalid channelId', () => {
//     expect(channelInviteV1(user1.authUserId, channel1.channelId + 3, user2.authUserId)).toStrictEqual(ERROR);
//   });
//   // uId does not refer to a valid user
//   test('invalid uId', () => {
//     expect(channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId + 3)).toStrictEqual(ERROR);
//   });
//   // authUserId is invalid
//   test('invalid authId', () => {
//     expect(channelInviteV1(user1.authUserId + 3, channel1.channelId, user2.authUserId)).toStrictEqual(ERROR);
//   });
//   // authUserId and uId is identical
//   test('authId and uId identical', () => {
//     expect(channelInviteV1(user1.authUserId, channel1.channelId, user1.authUserId)).toStrictEqual(ERROR);
//   });
//   // uId refers to a user who is already a member of the channel
//   test('uId exists in the channel', () => {
//     channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
//     // user 2 is assigned to channel1.channelId
//     expect(channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId)).toStrictEqual(ERROR);
//   });
//   // channelId is valid and the authorised user is not a member of the channel
//   test('authId does not exist in channel, but channelId valid', () => {
//     // user 1 as auth but not member of channel2.channelId, invites a another user
//     expect(channelInviteV1(user1.authUserId, channel2.channelId, user3.authUserId)).toStrictEqual(ERROR);
//   });
//   // Empty authUserId
//   test('empty authId', () => {
//     expect(channelInviteV1('', channel1.channelId, user2.authUserId)).toStrictEqual(ERROR);
//   });
//   // Empty channelId
//   test('empty channelId', () => {
//     expect(channelInviteV1(user1.authUserId, '', user2.authUserId)).toStrictEqual(ERROR);
//   });
//   // Empty uId
//   test('empty uId', () => {
//     expect(channelInviteV1(user1.authUserId, channel1.channelId, '')).toStrictEqual(ERROR);
//   });
// });
test('Valid Parameters, one channel', () => {
  expect(4).toStrictEqual(4);
});

// describe('Valid scenario', () => {
//   test('Valid return value', () => {
//     expect(channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId)).toStrictEqual({});
//   });
//   test('User invited then exists in the channel', () => {
//     channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
//     const channelDetails = channelDetailsV1(user1.authUserId, channel1.channelId) as ChannelDetails;
//     expect(channelDetails.channel.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         )
//       ])
//     );
//   });
//   test('Two users invited then exists in the channel', () => {
//     channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
//     channelInviteV1(user1.authUserId, channel1.channelId, user3.authUserId);
//     const channelDetails = channelDetailsV1(user1.authUserId, channel1.channelId) as ChannelDetails;
//     expect(channelDetails.channel.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         ),
//         expect.objectContaining(
//           {
//             uId: user3.authUserId
//           }
//         )
//       ])
//     );
//   });
//   test('Two users invited, the second user invites a third user', () => {
//     channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
//     channelInviteV1(user2.authUserId, channel1.channelId, user3.authUserId);
//     const channelDetails = channelDetailsV1(user1.authUserId, channel1.channelId) as ChannelDetails;
//     expect(channelDetails.channel.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         ),
//         expect.objectContaining(
//           {
//             uId: user3.authUserId
//           }
//         )
//       ])
//     );
//   });
// });
