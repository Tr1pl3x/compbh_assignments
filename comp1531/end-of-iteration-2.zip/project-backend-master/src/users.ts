import { getData } from './dataStore';

import type { User } from './interface';

export interface ErrorMessage {
  error?: string;
}
/**
  * userProfileV1
  * For a valid user, returns information about their user ID, email, first name, last name, and handle
  *
  * @param {string} token - token of authorized user
  * @param {number} uId - Id of user whose profile to be retrieved
  * @returns {
  *   {
  *     user: {
  *       uId: number,
  *       email: string,
  *       nameFirst: string,
  *       nameLast: string,
  *       handleStr: string
  *     }
  *   }
  * } - Object containing uId, email, nameFirst, nameLast, handleStr
  * @returns {{error: string}} on error
  * description of condition for return
*/

// For a valid user, returns information about their user ID, email, first name, last name, and handle
export function userProfileV1(token: string, uId: number): ErrorMessage | User {
  const data = getData();

  if (!(data.users).find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token)) || token === '') {
    return { error: 'Invalid token: user not found' };
  }
  const authUserId = data.users.find((user: { uId: number }) => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));

  if (authUserId.uId === undefined) {
    return { error: 'Invalid authId' };
  } else if ((!(data.users).find(user => user.uId === uId))) {
    return {
      error: 'invalid uId'
    };
  }

  // finding value of new User from dataStore
  const newUser = data.users.find((userFind: { uId: number }) => userFind.uId === authUserId.uId);
  // Add user details into the array allMembers of channel
  const user = {
    uId: newUser.uId,
    email: newUser.email,
    nameFirst: newUser.nameFirst,
    nameLast: newUser.nameLast,
    handleStr: newUser.handleStr
  };
  return { user };
}
