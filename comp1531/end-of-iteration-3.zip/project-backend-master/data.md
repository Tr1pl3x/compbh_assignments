```javascript
let data = {
	channels: [
		{
			channelId: 1, 
			name: 'My Channel',
			isPublic: true
			admin: [{UId: 1}],
			allMembers: [{UId: 1}, {Uid: 2}],
			allMessages:  [
				{
					messageId: 1,
					message: 'This is a message'
				},
				{
					messageId: 2,
					message: 'This is another test message'
				},
			]
		}
	],
	users: [
		{
			uId: 1,
			nameFirst: 'Rani',
			nameLast: 'Jiang',
			email: 'ranivorous@gmail.com',
			handleStr: 'ranivorous',
			channelsJoined: [{channelId: 1}]
		}
	],
	messages: [
    {
      messageId: 1,
      uId: 1,
      message: 'Hello world',
      timeSent: 1582426789,
    }
  ],
  start: 0,
  end: 50,
};

```

[Optional] short description: 