// import { channelsCreateV3, clearV2, authRegisterV2, channelAddOwnerV1, channelInviteV3 } from './testHelpers';
// import type { AuthUserId, ChannelId } from './interface';

// let newPerson: AuthUserId;
// let newPerson2: AuthUserId;
// let newPerson3: AuthUserId;
// let channelId1: ChannelId;
// beforeEach(() => {
//   clearV2();
//   newPerson = authRegisterV2('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
//   newPerson2 = authRegisterV2('sammyj2@gmail.com', 'pppassword2', 'Sammy', 'Greg') as AuthUserId;
//   newPerson3 = authRegisterV2('sammyj244@gmail.com', 'pppard2', 'Sammy', 'Goerge') as AuthUserId;
//   channelId1 = channelsCreateV3(newPerson.token, 'ChannelName', false) as ChannelId;
// });

// describe('Testing different parameters that covers every line of code', () => {
//   test('channelId is invalid', () => {
//     expect(channelAddOwnerV1(newPerson.token, -1, newPerson.authUserId)).toStrictEqual({ error: 'invalid channelId' });
//   });
//   test('token is invalid', () => {
//     expect(channelAddOwnerV1('abc', channelId1.channelId, newPerson.authUserId)).toStrictEqual({ error: 'invalid token' });
//   });
//   test('uId not a valid member', () => {
//     expect(channelAddOwnerV1(newPerson.token, channelId1.channelId, -1)).toStrictEqual({ error: 'invalid uId' });
//   });
//   test('uId refers to user who is not in the channel', () => {
//     expect(channelAddOwnerV1(newPerson2.token, channelId1.channelId, newPerson2.authUserId)).toStrictEqual({ error: 'uId refers to user who is not in the channel' });
//   });
//   test('authorised user does not have owner permissions to the channel', () => {
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson3.authUserId);
//     expect(channelAddOwnerV1(newPerson2.token, channelId1.channelId, newPerson.authUserId)).toStrictEqual({ error: 'autherised user is not an owner' });
//   });
//   test('valid parameters', () => {
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson2.authUserId);
//     expect(channelAddOwnerV1(newPerson.token, channelId1.channelId, newPerson2.authUserId)).toStrictEqual({});
//   });
//   test('valid parameters, multiple owners', () => {
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson3.authUserId);
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson2.authUserId);
//     expect(channelAddOwnerV1(newPerson.token, channelId1.channelId, newPerson2.authUserId)).toStrictEqual({});
//     expect(channelAddOwnerV1(newPerson2.token, channelId1.channelId, newPerson3.authUserId)).toStrictEqual({});
//   });
// });
test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
