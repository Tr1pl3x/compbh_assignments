/**
 *        << TEST FOR STANDUP BEHAVIOUR TO STRICLY FOLLOW THE SPEC >>
 *   Tests three standup functions,and save the bufered message in the channel.
 */

import {
  authRegisterV3,
  channelsCreateV3,
  channelInviteV3,
  standupStartV1,
  standupSendV1,
  standupActiveV1,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  ChannelId,
  Status,
  Time
} from './interface';

describe('One SUCCESSFUL standup session', () => {
  test('Must save the buffered messages under channel', () => {
    clearV2();
    const mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
    const user2 = authRegisterV3('jodie@gmail.com', 'psascode', 'Jodie', 'Chan') as AuthUserId;
    const thread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;

    // CASE 1: successfully invites
    const case1 = channelInviteV3(mainUser.token, thread.channelId, user2.authUserId);
    expect(case1).toStrictEqual({});

    // CASE 2: successfuly starts the standup session
    const case2 = standupStartV1(mainUser.token, thread.channelId, 2) as Time;
    const timeTest : number = 2 + Date.now() / 1000;
    expect(Math.abs(timeTest - case2.timeFinish)).toBeLessThanOrEqual(5);

    // CASE 3: checks standup is in progress by main user
    const case3 = standupActiveV1(mainUser.token, thread.channelId) as Status;
    expect(case3.isActive).toStrictEqual(true);

    // CASE 4: sends two successive messages: one from main user and one from user 2
    const case4 = standupSendV1(mainUser.token, thread.channelId, 'Hello');
    const case5 = standupSendV1(user2.token, thread.channelId, 'Heyyy');
    expect(case4).toStrictEqual({});
    expect(case5).toStrictEqual({});

    // CASE 5: checks if standup is in progress by user2
    const case6 = standupActiveV1(user2.token, thread.channelId) as Status;
    expect(case6.isActive).toStrictEqual(true);

    // CASE 6: delay by 1 second to make sure standup is finished
    const end = Date.now() + 2000;
    while (Date.now() < end) { /* Do nothing; blocking the execution */ }

    // CASE 7: checks if standup is in progress by user2
    const case7 = standupActiveV1(user2.token, thread.channelId) as Status;
    expect(case7.isActive).toStrictEqual(false);
    expect(case7.timeFinish).toStrictEqual(null);
  });
});
