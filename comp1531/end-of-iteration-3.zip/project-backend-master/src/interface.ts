export type ErrorMessage = { error: string };
export type AuthUserId = { token: string, authUserId: number };
export type Handle = Array<any>;

export interface ChannelId {
  channelId: number;
}

// for auth functions specifically

export interface tokenObj {
  tokenId: string,
}

export interface infoToReset {
  email: string;
  resetCode: string;
}

export interface aUser {
  uId: number,
  tokens?: tokenObj[],
  email: string,
  nameFirst: string,
  nameLast: string,
  password?: string,
  handleStr: string,
  handle?: Handle[],
  channelsJoined?: ChannelId[],
}

export interface getUser {
  uId: number,
  email: string,
  nameFirst: string,
  nameLast: string,
  handleStr: string,
  channelsJoined?: ChannelId[],
}
/* INPUT: dm/create/v2 */
export type UID = { uId: number};
export type UIDs = UID[];

export interface Reacts {
  reactId: number,
  uIds: UIDs,
  isThisUserReacted: boolean
}

export interface MessageInfo {
    messageId: number;
    uId: number;
    message: string;
    timeSent: number;
    reacts: Array<Reacts>,
    isPinned: boolean
}

export interface messageResponse {
  messages: MessageInfo[];
}

export interface Messages {
    messages: Array<MessageInfo>,
    start: number,
    end: number
}

export interface MessageReturn {
    messageId: number;
}

export interface Member {
  uId: number,
  email: string,
  nameFirst: string,
  nameLast: string,
  handleStr: string
}

/* OUTPUT: channel/details/v3 */
export interface ChannelDetails {
  name: string,
  isPublic: boolean,
  ownerMembers: Array<Member>,
  allMembers: Array<Member>
}

export interface Channels {
    channelId: number;
    name: string;
    isPublic: boolean;
    ownerMembers: Array<aUser>;
    allMembers: Array<aUser>;
    allMessages: Array<MessageInfo>;
}

export interface ChannelsListReturn {
  channelId: number,
  name: string,
}

export interface ChannelsReturn {
    channels: Array<ChannelsListReturn>;
  }
export interface ChannelsListAll {
    channelId: number;
    name: string;
  }
export interface ChannelsListAllReturn {
    channels: Array<ChannelsListAll>;
  }

export interface notification {
    channelId: number;
    dm: number;
    notificationMessage: string;
  }

export interface User {
    uId: number,
    email: string,
    nameFirst: string,
    nameLast: string,
    handleStr: string,
    channelsJoined?: Array<ChannelId>,
    notifications?: notification[],
}

/// UserProfile

export interface UserProfile {
  user: {
    uId: number,
    email: string,
    nameFirst: string,
    nameLast: string,
    handleStr: string,
    notifications?: notification[],
    resetCode?: string,
  }
}
export interface UserInfo {
  uId: number,
  email: string,
  nameFirst: string,
  nameLast: string,
  handleStr: string
}

export type Users = UserProfile[];
export type UsersReturn = { users: UserInfo[] };

/// /////////////DMS//////////////////////
export type DM = {
  dmId: number,
  name: string,
  ownerMembers: Array<aUser>
  allMembers: Array<aUser>
  allMessages: Array<MessageInfo>
}

/* OUTPUT: dm/details/v2 */
export type DmDetails = {
    name: string,
    members: Member[],
}

/* OUTPUT: dm/list/v2 */
export interface listDm{
  dmId: number,
  name: string,
}
export type DMs = listDm[];

export interface DMsReturn {
  dms: DMs;
}

/* OUTPUT: dm/create/v2 */
export type DmID = { dmId: number};

export interface DmMessages {
  messages: Array<MessageInfo>,
  start: number,
  end: number
}

/// ///////////// STAND UP //////////////////////

export interface StandUp {
  channelId: number,
  triggerToken: string,
  timeFinish: number,
  message: string,
  queue: string[],
}

/* OUTPUT: standup/start/v1 */
export type Time = { timeFinish: number }

/* OUTPUT: standup/active/v1 */
export type Status = {
  isActive: boolean,
  timeFinish: number | null,
}
