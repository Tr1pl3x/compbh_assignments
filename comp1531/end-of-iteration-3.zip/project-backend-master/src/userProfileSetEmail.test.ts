import { userProfileSetemailV1 } from './testHelpers';
import { clearV2 } from './testHelpers';
import { authRegisterV3 } from './testHelpers';

import type { AuthUserId } from './interface';

// const ERROR = { error: expect.any(String) };

let user1: AuthUserId; // authUserId
let user2: AuthUserId; // authUserId

beforeEach(() => {
  clearV2();
  user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  user2 = authRegisterV3('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
  // console.log(user1)
});

describe('changer user display name', () => {
  test('profile email', () => {
    const changeUser = userProfileSetemailV1(user1.token, 'test1@gmail.com');
    expect(changeUser).toStrictEqual({});
  });

  test('invalid token', () => {
    const changeUser = userProfileSetemailV1(user1.token + 'a', '121313');
    console.log(user2);
    expect(changeUser).toStrictEqual(403);
  });

  test('email used by another user', () => {
    const changeUser = userProfileSetemailV1(user1.token, 'test2@gmail.com');
    expect(changeUser).toStrictEqual(400);
  });

  test('email invalid', () => {
    const changeUser = userProfileSetemailV1(user1.token, 'afnskj@');
    console.log(changeUser);
    expect(changeUser).toStrictEqual({});
  });
});
test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
