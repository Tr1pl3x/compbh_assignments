import { getData, setData } from './dataStore';
/**
  * clearV3
  * Resets the internal data of the application to its initial state
  * @param {} - No parameter required
  * @returns {{}} - No return value
*/
export function clearV1() {
  const dataStore = getData();
  dataStore.channels = [];
  dataStore.users = [];
  dataStore.dms = [];
  dataStore.messages = [];
  dataStore.standups = [];
  dataStore.start = 0;
  dataStore.end = 50;
  setData(dataStore);
  return {};
}
