import { getData, setData } from './dataStore';
import validator from 'validator';
import type { AuthUserId, ErrorMessage, Handle } from './interface';
import { getHashOf, validateName } from './universalFunctions';
import HTTPError from 'http-errors';
import nodemailer from 'nodemailer';
import { SentMessageInfo } from 'nodemailer';

export function authRegisterV1(email: string, password: string, nameFirst: string, nameLast: string): AuthUserId | ErrorMessage {
  // getting our data from dataStore.js
  const data = getData();
  // if email is already in data store return error (being used by another user)
  if (data.users.some(user => user.email === email)) {
    throw HTTPError(400, 'Email already in use');
  }

  // if email is not valid return error (invalid email)
  if (validator.isEmail(email) === false) {
    throw HTTPError(400, 'Email Invalid');
  }
  // Checking for invalid first and last name
  const firstNameError = validateName(nameFirst);
  if (firstNameError) {
    throw HTTPError(400, 'Firstname Error');
  }

  const lastNameError = validateName(nameLast);
  if (lastNameError) {
    throw HTTPError(400, 'Lastname Error');
  }

  // If password length is less than 6 characters return error
  if (password.length < 6) {
    throw HTTPError(400, 'Password too short');
  }

  // Encrypt password
  const Hashedpassword = getHashOf(password);

  // If the arguments are valid, format the handle and return the userId

  // creating a unique user Id
  const authUserIdRet = Math.floor(Math.random() * 1000000000);

  // creating a token that will be associated with this user then convert to string length 16
  const randomNumber = (Math.random() * 100000);
  const tokenRet = randomNumber.toString(16);
  const HashedToken = getHashOf(tokenRet);
  // convert both first and last name to lowercase and remove all alphanumeric characters

  let handle: Handle = (nameFirst + nameLast).toLowerCase().replace(/[^a-z]/g, '').split('');

  // if the length is greater than 20, reduce to 20
  handle = handle.length > 20 ? handle.slice(0, 20) : handle;

  // check if the handle already exists
  // by using the Array.find() method to check if an identical handle already exists in the
  // data.users array
  const userExists = data.users.find(user => user.handle === handle);
  if (userExists) {
    // handle already exists, increment the number on the end of the handle string
    const lastElement: number = handle.length - 1;
    if (typeof handle[lastElement] === 'number') {
      handle[lastElement]++;
    } else {
      handle.push(0);
    }
  }

  const handleString = handle.join('');
  // Push our new client object onto data.users and set it on the datastore
  data.users.push({
    uId: authUserIdRet,
    tokens: [
      { tokenId: HashedToken },
    ],
    nameFirst: nameFirst,
    nameLast: nameLast,
    email: email,
    password: Hashedpassword,
    handleStr: handleString,
    channelsJoined: [],
  });
  setData(data);
  return {
    token: tokenRet,
    authUserId: authUserIdRet
  };
}

/**
  *Given a registered user's email and password,
 returns their authUserId value.

  * @param { email }  - emaail of the student/admin
  * @param { password }  - password of the student/admin
  *
  * @return { token, authUserId } - token and uId of user

*/

export function authLoginV1(email: string, password: string): AuthUserId | ErrorMessage {
  const data = getData();
  let i = 0;
  let k = 0;
  let userId = 0;
  for (const user of data.users) {
    if (user.email === email) {
      i++;
    }
    if (user.password === getHashOf(password)) {
      k++;
      userId = user.uId;
      break;
    }
  }
  // creating a token that will be associated with this user when they login to their session
  const randomNumber = (Math.random() * 100000);
  const token = randomNumber.toString(16);

  if (i !== 1) {
    throw HTTPError(400, 'Email error');
  }
  if (k !== 1) {
    throw HTTPError(400, 'Password too short');
  }
  // If everything is successful, add hashed token to the dataStore
  const tokenRet = randomNumber.toString(16);
  const HashedToken = getHashOf(tokenRet);
  for (const user of data.users) {
    if (user.email === email) {
      user.tokens.push({ tokenId: HashedToken });
    }
  }

  return {
    token: token,
    authUserId: userId,
  };
}

/**
  *Given an active token,
  invalidates the token to log the user out.

  * @param { token }  - token of the student/admin
  *
  * @return { } - empty array from removed token

*/

export function authLogOutV1(token: string) {
  const data = getData();
  // find user with specified token
  const hashedToken = getHashOf(token);
  const user = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  // validate the token
  if (!user) {
    throw HTTPError(403, 'Invalid token');
  }

  const shuffleUser = data.users.findIndex(user1 => user1.uId === user.uId);
  const indexofToken = data.users[shuffleUser].tokens.findIndex((t: { tokenId: string }) => t.tokenId === hashedToken);
  // const numberUser = data.users[shuffleUser];
  data.users[shuffleUser].tokens.splice(indexofToken, 1);
  setData(data);
  return {};
}

export function authPasswordRequestV1(email: string) {
  console.log(email);
  const data = getData();
  const user = data.users.find(user => user.email === email);

  if (!user) {
    return {};
  }

  // Generate a new password reset code for the user
  const resetCode = Math.floor(Math.random() * 1000000000).toString();
  // Store the reset code in the user object in the data store
  user.resetCode = resetCode;
  setData(data);

  // Logout user from all sessions
  user.tokens = [];
  // Save the updated data store
  setData(data);

  // Send reset code to user email
  const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
      user: 'phyllis.klein39@ethereal.emaicleal',
      pass: 'dXKVBND4NMtkzxVT2N',
    },
  });

  const mailOptions = {
    from: 'evan@gmail.com',
    to: user.email,
    subject: 'passcode123',
    text: `Your password reset code is ${resetCode}`,
  };

  transporter.sendMail(mailOptions, function(error: Error | null, info: SentMessageInfo) {
    try {
      // console.log('Email sent successfully');
    } catch (err) {
      console.error('email was not sent');
    }
  });

  return {};
}

export function authPasswordResetV1(resetCode: string, newPassword: string) {
  console.log(resetCode);
  console.log(newPassword);
  if (newPassword.length < 6) {
    throw HTTPError(400, 'passworld less than 6 characters long');
  }

  const data = getData();
  // checking on the length of the passworth smaller than 6

  const user = data.users.find((u) => u.resetCode === resetCode);

  if (!user) {
    throw HTTPError(400, 'Error: Invalid reset code.');
  }

  // Update user's password
  user.password = newPassword;

  // Invalidate reset code
  user.resetCode = '';

  setData(data);

  return {};
}
