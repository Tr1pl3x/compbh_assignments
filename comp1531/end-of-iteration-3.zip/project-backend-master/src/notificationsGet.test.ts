import { notificationsGetV1 } from './testHelpers';
import { authRegisterV3 } from './testHelpers';
import { clearV2 } from './testHelpers';
import type { AuthUserId, notification } from './interface';

let user1: AuthUserId;
// let user2: AuthUserId;
beforeEach(() => {
  clearV2();
  user1 = authRegisterV3('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes') as AuthUserId;
  // user2 = authRegisterV3('yeet.dang@unsw.edu.au', 'password1', 'Brother', 'No') as AuthUserId;

  console.log('start');
});

describe('notification', () => {
  test('returns an array of channel  for valid authUserId', () => {
    const notifCreating = notificationsGetV1(user1.token + 'a') as notification;
    expect(notifCreating).toStrictEqual(403);
  });
});

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
