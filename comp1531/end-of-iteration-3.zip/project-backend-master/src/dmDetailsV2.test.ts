/* /////////////////////// dmDetailsV2 ////////////////////////////////

// # Passing Parameters:( token: string, dmId: number )

// # Return type if no error: { name: string, members: array<Users> }

// # Cases to be considered:
//     -Error Scenarios
//         // 403 ERROR:  invalid token
//         // 400 ERROR:  invalid dmId
//         // 403 ERROR:  unauthorised access to valid channel

//     -Return Correct Type
//         - passing valid token and dmId

////////////////////////////////////////////////////////////////////// */

// import functions
import {
  authRegisterV3,
  dmCreateV2,
  dmDetailsV2,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  DmID,
} from './interface';

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;
let dm: DmID;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV3('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
  dm = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
});

describe('Error Casses', () => {
  test('Invalid token', () => {
    const testVar = dmDetailsV2(mainUser.token + 'abg', dm.dmId);
    expect(testVar).toStrictEqual(403);
  });
  test('Invalid Dm ID', () => {
    const testVar = dmDetailsV2(mainUser.token, dm.dmId + 999);
    expect(testVar).toStrictEqual(400);
  });
  test('Unauthorised access to a valid dm', () => {
    const newUser = authRegisterV3('jj@gmail.com', 'passcoed', 'eblu', 'bad') as AuthUserId;
    const testVar = dmDetailsV2(newUser.token, dm.dmId);
    expect(testVar).toStrictEqual(403);
  });
});

describe('Returns Correct Type', () => {
  test('passing valid token and array of uIds', () => {
    const testVar = dmDetailsV2(user2.token, dm.dmId);

    expect(testVar).toStrictEqual({
      name: 'blueranger,pyaesone,redranger',
      members: expect.arrayContaining([
        expect.objectContaining({
          uId: expect.any(Number),
          email: expect.any(String),
          nameFirst: expect.any(String),
          nameLast: expect.any(String),
          handleStr: expect.any(String),
        }),
      ])
    });
  });
});
