import { userProfileSethandleV2 } from './testHelpers';
import { clearV2 } from './testHelpers';
import { authRegisterV3 } from './testHelpers';

import type { AuthUserId } from './interface';

// const ERROR = { error: expect.any(String) };

let user1: AuthUserId; // authUserId

beforeEach(() => {
  clearV2();
  user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
  // user2 = authRegisterV1('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
  // console.log(user1)
});

describe('changer user display name', () => {
  test('profile handle', () => {
    const changeUser = userProfileSethandleV2(user1.token, 'Babuu');
    expect(changeUser).toStrictEqual({});
  });

  test('profile handle', () => {
    const changeUser = userProfileSethandleV2(user1.token, 'BO');
    expect(changeUser).toStrictEqual(400);
  });

  test('alpha test', () => {
    const changeUser = userProfileSethandleV2(user1.token, '%13131&');
    expect(changeUser).toStrictEqual(400);
  });

  test('alpha test', () => {
    const changeUser = userProfileSethandleV2(user1.token + 'a', '%13131&');
    expect(changeUser).toStrictEqual(403);
  });
});
test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
