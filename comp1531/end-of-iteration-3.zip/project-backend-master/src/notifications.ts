import { getData, setData } from './dataStore';
import HTTPError from 'http-errors';
import { isValidToken, uIdValid, getuId } from './universalFunctions';

export function notificationsGetV1(token: string) {
  const data = getData();
  const uId = getuId(token);
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if ((!(uIdValid(uId)))) {
    throw HTTPError(400, 'Error: Invalid uId');
  }

  for (const notif of data.users) {
    if (notif.uId === notif.authorisedId) {
      return {
        notifications: notif.notifications.slice(0, 20),
      };
    }
  }
  setData(data);
}
