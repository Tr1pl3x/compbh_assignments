import { channelsCreateV3, clearV2, authRegisterV3, messageShare, dmCreateV2, messageSenddmV2, channelInviteV3 } from './testHelpers';
import type { AuthUserId, ChannelId, DmID, MessageReturn } from './interface';

let newPerson: AuthUserId;
let newPerson2: AuthUserId;
let newPerson3: AuthUserId;
let channel1: ChannelId;
let dm1: DmID;
let message1: MessageReturn;

beforeEach(() => {
  clearV2();
  newPerson = authRegisterV3('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
});

describe('Testing different parameters that covers every line of code', () => {
  test('Invlaid token', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles22', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson2.token + 'a', message1.messageId, '', channel1.channelId, -1)).toStrictEqual(403);
  });
  test('both channelId and dmId are invalid', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles22', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson2.token, message1.messageId, '', -1, -1)).toStrictEqual(400);
  });
  test('neither channelId or dmId are -1', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles22', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson2.token, message1.messageId, '', channel1.channelId, dm1.dmId)).toStrictEqual(400);
  });
  test('og message does not refer to a valid message within a channel/dm', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles22', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson2.token, -1, '', channel1.channelId, -1)).toStrictEqual(400);
  });
  test('authorised user is not a part of channel/dm', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles222', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson3.token, message1.messageId, '', channel1.channelId, -1)).toStrictEqual(403);
  });
  test('length of message is greater than 1000', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles222', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson3.token, message1.messageId, 'a'.repeat(1001), channel1.channelId, -1)).toStrictEqual(400);
  });
  test('channelId undefined', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles222', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson3.token, message1.messageId, 'a', undefined, -1)).toStrictEqual(400);
  });
  test('dmId undefined', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles222', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson.token, message1.messageId, '', -1, undefined)).toStrictEqual(400);
  });
  test('valid parameters', () => {
    newPerson2 = authRegisterV3('coke@gmail.com', 'bubbles222', 'Coke', 'Bubblers') as AuthUserId;
    newPerson3 = authRegisterV3('chips@gmail.com', 'salty222', 'Chicken', 'Salt') as AuthUserId;
    channel1 = channelsCreateV3(newPerson.token, 'channel name', false);
    channelInviteV3(newPerson.token, channel1.channelId, newPerson2.authUserId);
    dm1 = dmCreateV2(newPerson.token, [newPerson2.authUserId, newPerson3.authUserId]);
    message1 = messageSenddmV2(newPerson2.token, dm1.dmId, 'Hello world');
    expect(messageShare(newPerson2.token, message1.messageId, '', channel1.channelId, -1)).toStrictEqual({
      sharedMessageId: expect.any(Number),
    });
  });
});
