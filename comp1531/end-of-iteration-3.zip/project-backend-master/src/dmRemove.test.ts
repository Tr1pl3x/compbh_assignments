import {
  authRegisterV3,
  dmRemoveV1,
  dmCreateV2,
  clearV2
} from './testHelpers';

// import interface
import {
  AuthUserId,
  DmID,
} from './interface';

const ERROR = { error: expect.any(String) };

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;
let dm: DmID;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV3('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
  dm = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
});

describe('Returns Correct Type', () => {
  test('passing invalid token and empty array', () => {
    const testVar = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
    const IdRemove = dmRemoveV1('', testVar.dmId);
    expect(IdRemove).toStrictEqual(ERROR);
  });

  test('invalid token check ', () => {
    const Usertesting = dmRemoveV1(mainUser.token, dm.dmId);
    expect(Usertesting).toStrictEqual({});
  });

  test('successful remove', () => {
    const testVar = dmRemoveV1(user1.token, dm.dmId);
    expect(testVar).toStrictEqual(403);
  });

  test('Invalid Dm ID', () => {
    const testVar = dmRemoveV1(mainUser.token, dm.dmId + 999);
    console.log(testVar);
    expect(testVar).toStrictEqual(400);
  });
});
test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
