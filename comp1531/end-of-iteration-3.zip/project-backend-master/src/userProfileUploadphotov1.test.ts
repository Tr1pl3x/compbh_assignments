import { clearV2, authRegisterV3, userProfileUploadphotov1 } from './testHelpers';

import type { AuthUserId } from './interface';

let user1: AuthUserId; // authUserId

beforeEach(() => {
  clearV2();
  user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
});

describe('Expected return values', () => {
  test('Invalid token', () => {
    const changeUser = userProfileUploadphotov1(user1.token + 1,
      'http://webcms3.cse.unsw.edu.au/static/uploads/profilepic/z5030786/5014edd7a6117bc4f2131a365b088a75f4b9eaf1d35c9769c2f6bc512046982b/IMG_2709_2.jpg', 1, 2, 3, 4);
    expect(changeUser).toStrictEqual(403);
  });

  test('Empty token', () => {
    const changeUser = userProfileUploadphotov1('',
      'https://webcms3.cse.unsw.edu.au/static/uploads/profilepic/z5030786/5014edd7a6117bc4f2131a365b088a75f4b9eaf1d35c9769c2f6bc512046982b/IMG_2709_2.jpg', 1, 2, 3, 4);
    expect(changeUser).toStrictEqual(403);
  });

  test('Invalid url', () => {
    const changeUser = userProfileUploadphotov1(user1.token, 'slawfire', 1, 2, 3, 4);
    expect(changeUser).toStrictEqual(400);
  });

  test('Empty url', () => {
    const changeUser = userProfileUploadphotov1(user1.token, '', 1, 2, 3, 4);
    expect(changeUser).toStrictEqual(400);
  });
  test('url doesnt end in jpg', () => {
    const changeUser = userProfileUploadphotov1(user1.token, 'http://www.freecodecamp.org/', 1, 2, 3, 4);
    expect(changeUser).toStrictEqual(400);
  });

  test('start dimensions greater than end dimensions', () => {
    const changeUser = userProfileUploadphotov1(user1.token,
      'http://webcms3.cse.unsw.edu.au/static/uploads/profilepic/z5030786/5014edd7a6117bc4f2131a365b088a75f4b9eaf1d35c9769c2f6bc512046982b/IMG_2709_2.jpg', 4, 9, 3, 4);
    expect(changeUser).toStrictEqual(400);
  });

  test('Cropping area out of bounds', () => {
    const changeUser = userProfileUploadphotov1(user1.token,
      'http://webcms3.cse.unsw.edu.au/static/uploads/profilepic/z5030786/5014edd7a6117bc4f2131a365b088a75f4b9eaf1d35c9769c2f6bc512046982b/IMG_2709_2.jpg', 1, 2, 0, 0);
    expect(changeUser).toStrictEqual(400);
  });

  test('Valid token', () => {
    const changeUser = userProfileUploadphotov1(user1.token,
      'http://webcms3.cse.unsw.edu.au/static/uploads/profilepic/z5030786/5014edd7a6117bc4f2131a365b088a75f4b9eaf1d35c9769c2f6bc512046982b/IMG_2709_2.jpg', 1, 2, 3, 4);
    expect(changeUser).toStrictEqual({});
  });
});
