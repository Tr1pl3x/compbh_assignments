import { channelsCreateV3, clearV2, authRegisterV3 } from './testHelpers';
import type { AuthUserId } from './interface';

let newPerson: AuthUserId;
beforeEach(() => {
  clearV2();
  newPerson = authRegisterV3('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
});

describe('Testing different parameters that covers every line of code', () => {
  test('Name length = 0, valid user', () => {
    expect(channelsCreateV3(newPerson.token, '', false)).toStrictEqual(400);
  });
  test('Name length = 20, valid user', () => {
    expect(channelsCreateV3(newPerson.token, '12345678901234567890', false)).toStrictEqual({ channelId: expect.any(Number) });
  });
  test('Name length = 21, valid user', () => {
    expect(channelsCreateV3(newPerson.token, '123456789012345678901', false)).toStrictEqual(400);
  });
  test('Name length = 1, valid user', () => {
    expect(channelsCreateV3(newPerson.token, '1', false)).toStrictEqual({ channelId: expect.any(Number) });
  });
  test('Invalid authUserId', () => {
    expect(channelsCreateV3('I am not a valid user', '1', false)).toStrictEqual(403);
  });
});
