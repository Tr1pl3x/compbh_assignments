import { getData, setData } from './dataStore';
import {
  isValidChannel, isValidToken, getUserFromToken, returnChannel, returnDm,
  isAuthMemberOfChannel, isAuthMemberOfDm, returnDmFromMessageId, returnChannelFromMessageId,
  returnDmMessage, returnChannelMessage, isDmMessageSentByAuthId,
  isChannelMessageSentByAuthId, isDmOwner, isChannelOwner, getuId, isValidDm, returnDmFromDmId, returnChannelFromChannelId
} from './universalFunctions';
import type { MessageInfo, MessageReturn } from './interface';
import HTTPError from 'http-errors';

/**
 * messageSendV2
 * Send a message from the authorised user to the channel specified by channelId.
 * Note: Each message should have its own unique ID, i.e.
 * no messages should share an ID with another message,
 * even if that other message is in a different channel.
 * @param {string} token - token of authorized user (header)
 * @param {number} channelId - Id of channel to send message to (body)
 * @param {string} message - New message to be sent (body)
 * @returns {{messageId: number}} - Returns corresponding messageId of the message just sent
 * @throws {Error} Throws 400 or 403 error
 */
export function messageSendV1(token: string, channelId: number, message: string): MessageReturn {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (!(isValidChannel(channelId))) {
    throw HTTPError(400, 'Error: Invalid channelId');
  } else if (message.length > 1000 || message.length < 1) {
    throw HTTPError(400, 'Error: Invalid message length');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currChannel = returnChannel(channelId);
  const messageId = Math.floor(Math.random() * 1000000000);
  const timeSent = Math.floor(Date.now() / 1000);
  if (!(isAuthMemberOfChannel(authUserId, currChannel))) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the channel');
  }
  currChannel.allMessages.push({
    messageId: messageId,
    uId: authUserId.uId,
    message: message,
    timeSent: timeSent,
    reacts: [],
    isPinned: false
  });
  setData(data);
  return { messageId };
}

/**
 * messageSenddmV2
 * Send a message from authorised user to the DM specified by dmId. Note: Each message should have it's own unique ID,
 * i.e. no messages should share an ID with another message, even if that other message is in a different channel or
 * DM.s -1 to indicate that there are no more messages to load after this return.
 * @param {string} token - token of authorized user (header)
 * @param {number} dmId - Id of DM to send message to. (body)
 * @param {string} message - message to be sent to DM (body)
 * @returns {{ messageId: number }} - Returns the corresponding messageId that just created
 * @throws {Error} Throws 400 or 403 error
*/
export function messageSenddmV1(token: string, dmId: number, message: string): MessageReturn {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (message.length > 1000 || message.length < 1) {
    throw HTTPError(400, 'Error: Invalid message length');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currDm = returnDm(dmId);
  if ((!(currDm))) {
    throw HTTPError(400, 'Error: Invalid dmId');
  }
  const messageId = Math.floor(Math.random() * 1000000000);
  const timeSent = Math.floor(Date.now() / 1000);
  // If authId is not a member of channel
  if (!(isAuthMemberOfDm(authUserId, currDm))) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the DM');
  }
  // Add user details into the array allMembers of channel
  currDm.allMessages.push({
    messageId: messageId,
    uId: authUserId.uId,
    message: message,
    timeSent: timeSent,
    reacts: [],
    isPinned: false
  });
  setData(data);
  return { messageId };
}

/**
 * messageEditV2
 * Given a message, update its text with new text. If the new message is an empty string, the message is deleted.
 * @param {string} token - token of authorized user (header)
 * @param {number} messageId - Id of mesage to be edited (query string)
 * @param {string} message - new message to be replaced (query string)
 * @returns {Record<string, never>} - empty object if successful
 * @throws {Error} Throws 400 or 403 error
*/
export function messageEditV1(token: string, messageId: number, message: string): Record<string, never> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (message.length > 1000) {
    throw HTTPError(400, 'Error: Invalid message length');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currChannel = returnChannelFromMessageId(messageId);
  if (!currChannel) {
    const currDm = returnDmFromMessageId(messageId);
    if (!currDm) {
      throw HTTPError(400, 'Error: Invalid messageId');
    }
    const isMessageDmFromAuthorizedUser = isDmMessageSentByAuthId(messageId, currDm, authUserId);
    const isUserDmOwner = isDmOwner(currDm, authUserId);
    if (!isMessageDmFromAuthorizedUser && !isUserDmOwner) {
      throw HTTPError(403, 'Error: Message was not sent by the authorised user, and user is not the owner of the dm');
    }
    const dmMessage = returnDmMessage(messageId, currDm);
    if (message === '') {
      currDm.allMessages.splice(currDm.allMessages.indexOf(dmMessage), 1);
      setData(data);
      return {};
    }
    dmMessage.message = message;
    setData(data);
    return {};
  }
  const isMessageFromAuthorizedUser = isChannelMessageSentByAuthId(messageId, currChannel, authUserId);
  const isUserChannelOwner = isChannelOwner(currChannel, authUserId);
  if (!isMessageFromAuthorizedUser && !isUserChannelOwner) {
    throw HTTPError(403, 'Error: Message was not sent by the authorised user, and user is not the owner of the channel');
  }
  const channelMessage = returnChannelMessage(messageId, currChannel);
  if (message === '') {
    currChannel.allMessages.splice(currChannel.allMessages.indexOf(channelMessage), 1);
    setData(data);
    return {};
  }
  channelMessage.message = message;
  setData(data);
  return {};
}

/**
 * messageRemoveV2
 * Given a messageId for a message, this message is removed from the channel/DM
 * @param {string} token - token of authorized user (header)
 * @param {number} messageId - Id of mesage to be removed (query string)
 * @throws {Error} Throws 400 or 403 error
 * @returns {Record<string, never>} - empty object if successful
*/
export function messageRemoveV1(token: string, messageId: number): Record<string, never> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currChannel = returnChannelFromMessageId(messageId);
  if (!currChannel) {
    const currDm = returnDmFromMessageId(messageId);
    if (!currDm) {
      throw HTTPError(400, 'Error: Invalid messageId');
    }
    const isMessageDmFromAuthorizedUser = isDmMessageSentByAuthId(messageId, currDm, authUserId);
    const isUserDmOwner = isDmOwner(currDm, authUserId);
    if (!isMessageDmFromAuthorizedUser && !isUserDmOwner) {
      throw HTTPError(403, 'Error: Message was not sent by the authorised user, and user is not the owner of the dm');
    }
    const dmMessage = returnDmMessage(messageId, currDm);
    currDm.allMessages.splice(currDm.allMessages.indexOf(dmMessage), 1);
    setData(data);
    return {};
  }
  const isMessageFromAuthorizedUser = isChannelMessageSentByAuthId(messageId, currChannel, authUserId);
  const isUserChannelOwner = isChannelOwner(currChannel, authUserId);
  if (!isMessageFromAuthorizedUser && !isUserChannelOwner) {
    throw HTTPError(403, 'Error: Message was not sent by the authorised user, and user is not the owner of the channel');
  }
  const channelMessage = returnChannelMessage(messageId, currChannel);
  currChannel.allMessages.splice(currChannel.allMessages.indexOf(channelMessage), 1);
  setData(data);
  return {};
}

/**
 * messageSendlaterV1
 * Sends a message from the authorised user to the channel specified by channelId
 * automatically at a specified time in the future.
 * The returned messageId will only be considered valid for other actions (editing/deleting/reacting/etc)
 * once it has been sent (i.e. after timeSent).
 * @param {string} token - token of authorized user (header)
 * @param {number} channelId - Id of channel to send message to (body)
 * @param {string} message - New message to be sent (body)
 * @param {number} timeSent - Time in the future to send the message (body)
 * @returns {Promise<MessageReturn>} - Returns corresponding messageId of the message sent after timeSent
 * @throws {Error} Throws 400 or 403 error
 */
export function messageSendlaterV1(token: string, channelId: number, message: string, timeSent: number): Promise<MessageReturn> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (!(isValidChannel(channelId))) {
    throw HTTPError(400, 'Error: Invalid channelId');
  } else if (message.length > 1000 || message.length < 1) {
    throw HTTPError(400, 'Error: Invalid message length');
  } else if (timeSent < (Date.now() / 1000)) {
    throw HTTPError(400, 'Error: Invalid timeSent: cannot be a time in the past');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currChannel = returnChannel(channelId);
  const messageId = Math.floor(Math.random() * 1000000000);
  if (!(isAuthMemberOfChannel(authUserId, currChannel))) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the channel');
  }
  const delay = timeSent * 1000 - (Date.now());
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const newTimeSent = Math.floor(Date.now() / 1000);
      currChannel.allMessages.push({
        messageId: messageId,
        uId: authUserId.uId,
        message: message,
        timeSent: newTimeSent,
        isPinned: false,
        reacts: []
      });
      setData(data);
      resolve({ messageId });
    }, delay);
  });
}

/**
 * messageSendLaterDmV1
 * Sends a message from the authorised user to the channel specified by dmId
 * automatically at a specified time in the future.
 * The returned messageId will only be considered valid for other actions (editing/deleting/reacting/etc)
 * once it has been sent (i.e. after timeSent).
 * @param {string} token - token of authorized user (header)
 * @param {number} dmId - Id of dm to send message to (body)
 * @param {string} message - New message to be sent (body)
 * @param {number} timeSent - Time in the future to send the message (body)
 * @returns {Promise<MessageReturn>} - Returns corresponding messageId of the message sent after timeSent
 * @throws {Error} Throws 400 or 403 error
 */
export function messageSendLaterDmV1(token: string, dmId: number, message: string, timeSent: number): Promise<MessageReturn> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (!(isValidDm(dmId))) {
    throw HTTPError(400, 'Error: Invalid dmId');
  } else if (message.length > 1000 || message.length < 1) {
    throw HTTPError(400, 'Error: Invalid message length');
  } else if (timeSent < (Date.now() / 1000)) {
    throw HTTPError(400, 'Error: Invalid timeSent: cannot be a time in the past');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currDm = returnDm(dmId);
  const messageId = Math.floor(Math.random() * 1000000000);
  if (!(isAuthMemberOfDm(authUserId, currDm))) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the dm');
  }
  const delay = timeSent * 1000 - (Date.now());
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const newTimeSent = Math.floor(Date.now() / 1000);
      currDm.allMessages.push({
        messageId: messageId,
        uId: authUserId.uId,
        message: message,
        timeSent: newTimeSent,
        isPinned: false,
        reacts: []
      });
      setData(data);
      resolve({ messageId });
    }, delay);
  });
}

/**
 * messagePinV1
 * Given a message within a channel or DM, marks it as "pinned".
 * @param {string} token - Token of user (header)
 * @param {number} messageId - Id of message to be pinned (body)
 * @returns {Record<string, never>} - Empty object if successful
 * @throws {Error} Throws 400 or 403 error
 */
export function messagePinV1(token: string, messageId: number): Record<string, never> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currChannel = returnChannelFromMessageId(messageId);
  if (!currChannel) {
    const currDm = returnDmFromMessageId(messageId);
    if (!currDm) {
      throw HTTPError(400, 'Error: Invalid messageId');
    }
    const isUserDmOwner = isDmOwner(currDm, authUserId);
    if (!isUserDmOwner) {
      throw HTTPError(403, 'Error: User does not have DM owner permission');
    }
    const dmMessage = returnDmMessage(messageId, currDm);
    if (dmMessage.isPinned) {
      throw HTTPError(400, 'Error: Message is already pinned');
    }
    dmMessage.isPinned = true;
    setData(data);
    return {};
  }
  const isUserChannelOwner = isChannelOwner(currChannel, authUserId);
  if (!isUserChannelOwner) {
    throw HTTPError(403, 'Error: User does not have channel owner permission');
  }
  const channelMessage = returnChannelMessage(messageId, currChannel);
  if (channelMessage.isPinned) {
    throw HTTPError(400, 'Error: Message is already pinned');
  }
  channelMessage.isPinned = true;
  setData(data);
  return {};
}
/**
 * messageUnpinV1
 * Given a message within a channel or DM, removes its mark as "pinned".
 * @param {string} token - Token of user (header)
 * @param {number} messageId - Id of message to be unpinned (body)
 * @returns {Record<string, never>} - Empty object if successful
 * @throws {Error} Throws 400 or 403 error
 */
export function messageUnpinV1(token: string, messageId: number): Record<string, never> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  }
  const data = getData();
  const authUserId = getUserFromToken(token);
  const currChannel = returnChannelFromMessageId(messageId);
  if (!currChannel) {
    const currDm = returnDmFromMessageId(messageId);
    if (!currDm) {
      throw HTTPError(400, 'Error: Invalid messageId');
    }
    const isUserDmOwner = isDmOwner(currDm, authUserId);
    if (!isUserDmOwner) {
      throw HTTPError(403, 'Error: User does not have DM owner permission');
    }
    const dmMessage = returnDmMessage(messageId, currDm);
    if (!(dmMessage.isPinned)) {
      throw HTTPError(400, 'Error: Message is already unpinned');
    }
    dmMessage.isPinned = false;
    setData(data);
    return {};
  }
  const isUserChannelOwner = isChannelOwner(currChannel, authUserId);
  if (!isUserChannelOwner) {
    throw HTTPError(403, 'Error: User does not have channel owner permission');
  }
  const channelMessage = returnChannelMessage(messageId, currChannel);
  if (!(channelMessage.isPinned)) {
    throw HTTPError(400, 'Error: Message is already unpinned');
  }
  channelMessage.isPinned = false;
  setData(data);
  return {};
}

/**
 * messageReactV1
 * Given a messageId for a message, or DM the authorised user is part of, adds a "react" to that particular message.
 * @headers {string} token - token of authorised user
 * @param {number} messageId - Id of mesage to be removed
 * @returns {{error: string}} on error
 * @returns {{}} - empty object if successful
*/

export function messageReactV1 (token: string, messageId: number, reactId: number): (Error | Record<string, never>) {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  }

  if (reactId !== 1) {
    throw HTTPError(400, 'Error: reactId is not a valid react ID');
  }

  const data = getData();
  const authUserId = getuId(token);
  const currChannel = returnChannelFromMessageId(messageId);
  if (!currChannel) {
    const currDm = returnDmFromMessageId(messageId);
    if (!currDm) {
      throw HTTPError(400, 'Error: Invalid messageId');
    }

    const dmMessage = returnDmMessage(messageId, currDm);

    // check if the dm message has been reacted to by the user
    // check if reacts is empty, if empty create <Reacts>, push to message
    if (dmMessage.reacts.length === 0) {
      const tempuIdArray: Array<{uId: number}> = [];
      const tempUID: { uId: number } = { uId: authUserId };
      tempuIdArray.push(tempUID);
      const tempReact = {
        reactId: reactId,
        uIds: tempuIdArray,
        isThisUserReacted: true
      };
      dmMessage.reacts.push(tempReact);
      setData(data);
      return {};
    }

    const reactsArray = dmMessage.reacts;

    // Check if any of the Reacts objects in the array contain the user ID
    for (const reacts of reactsArray) {
      if (reacts.uIds.some((uid) => uid.uId === authUserId)) {
        // User already reacted, throw 400 error
        throw HTTPError(400, 'Error: User already reacted');
      }
    }

    // if uId not found, add it to the uId's array, set isThisUserReacted to true
    const tempUID: {uId: number} = { uId: authUserId };
    dmMessage.reacts[0].uIds.push(tempUID);
    dmMessage.reacts[0].isThisUserReacted = true;
    setData(data);
    return {};
  }

  const channelMessage = returnChannelMessage(messageId, currChannel);

  // check if there has been a react on message yet, if not then create one
  if (channelMessage.reacts.length === 0) {
    const tempuIdArray: Array<{uId: number}> = [];
    const tempUID: {uId: number} = { uId: authUserId };
    tempuIdArray.push(tempUID);
    const tempReact = {
      reactId: reactId,
      uIds: tempuIdArray,
      isThisUserReacted: true
    };
    channelMessage.reacts.push(tempReact);
    setData(data);
    return {};
  }

  const reactsArray = channelMessage.reacts;

  // Check if any of the Reacts objects in the array contain the user ID
  for (const reacts of reactsArray) {
    if (reacts.uIds.some((uid) => uid.uId === authUserId)) {
      // User already reacted, throw 400 error
      throw HTTPError(400, 'Error: User already reacted');
    }
  }

  // if uId not found, add it to the uId's array, set isThisUserReacted to true
  const tempUID: {uId: number} = { uId: authUserId };
  channelMessage.reacts[0].uIds.push(tempUID);
  channelMessage.reacts[0].isThisUserReacted = true;
  setData(data);
  return {};
}

/**
 * messageReactV1
 * Given a messageId for a message, or DM the authorised user is part of, adds a "react" to that particular message.
 * @headers {string} token - token of authorised user
 * @param {number} messageId - Id of mesage to be removed
 * @returns {{error: string}} on error
 * @returns {{}} - empty object if successful
*/

export function messageUnreactV1 (token: string, messageId: number, reactId: number): (Error | Record<string, never>) {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  }

  if (reactId !== 1) {
    throw HTTPError(400, 'Error: reactId is not a valid react ID');
  }

  const data = getData();
  const authUserId = getuId(token);
  const currChannel = returnChannelFromMessageId(messageId);
  if (!currChannel) {
    const currDm = returnDmFromMessageId(messageId);
    if (!currDm) {
      throw HTTPError(400, 'Error: Invalid messageId');
    }
    const dmMessage = returnDmMessage(messageId, currDm);

    // check if the dm message has been reacted to by the user
    // check if reacts is empty, if empty create return error
    if (dmMessage.reacts.length === 0) {
      throw HTTPError(400, 'Error: No reacts on message');
    }

    const reactsArray = dmMessage.reacts;

    // Check if user has reacted
    let reacted = false;
    for (const reacts of reactsArray) {
      if (reacts.uIds.some((uid) => uid.uId === authUserId)) {
        // User already reacted, remove their uId
        reacts.uIds = reacts.uIds.filter((uid) => uid.uId !== authUserId);
        reacted = true;
        reacts.isThisUserReacted = false;
        setData(data);
        return {};
      }
    }
    if (!reacted) {
      throw HTTPError(400, 'Error: DM User has not reacted');
    }
  }

  const channelMessage = returnChannelMessage(messageId, currChannel);

  // check if there has been a react on message yet, if not then create one
  if (channelMessage.reacts.length === 0) {
    throw HTTPError(400, 'Error: No reacts on message');
  }

  const reactsArray = channelMessage.reacts;

  // Check if user has reacted
  let reacted = false;
  for (const reacts of reactsArray) {
    if (reacts.uIds.some((uid) => uid.uId === authUserId)) {
      // User already reacted, remove their uId
      reacts.uIds = reacts.uIds.filter((uid) => uid.uId !== authUserId);
      reacted = true;
      reacts.isThisUserReacted = false;
      setData(data);
      return {};
    }
  }
  if (!reacted) {
    throw HTTPError(400, 'Error: User has not reacted');
  }
}

export function messageShareV1 (token: string, ogMessageId: number, message: string, channelId: number, dmId: number): { sharedMessageId: number } {
  if (!isValidToken(token)) {
    throw HTTPError(403, 'Error: Invalid token');
  } else if (channelId === -1 && dmId === -1) {
    throw HTTPError(400, 'Error: Both channelId and dmId are invalid');
  } else if (channelId !== -1 && dmId !== -1) {
    throw HTTPError(400, 'Error: Both channelId and dmId are not -1');
  } else if (channelId === -1 && dmId === undefined) {
    throw HTTPError(400, 'dmId is undefined');
  } else if (channelId === undefined && dmId === -1) {
    throw HTTPError(400, 'channelId is undefined');
  } else if (returnDmFromMessageId(ogMessageId) === undefined && returnChannelFromMessageId(ogMessageId) === undefined) {
    throw HTTPError(400, 'ogMessage does not exist');
  } else if (message.length > 1000) {
    throw HTTPError(400, 'message too long');
  }

  const authUser = getUserFromToken(token);
  if (channelId === -1) {
    // message being send to a Dm
    console.log('this is the messageId ', ogMessageId);
    const ogChannel = returnChannelFromMessageId(ogMessageId);
    const authDm = returnDmFromDmId(dmId);
    console.log(ogChannel);
    if (!(isAuthMemberOfChannel(authUser, ogChannel)) || (!(isAuthMemberOfDm(authUser, authDm)))) {
      throw HTTPError(403, 'User is not a part of both the channel and the DM');
    }
  } else if (dmId === -1) {
    // message being sent to channel
    const ogDm = returnDmFromMessageId(ogMessageId);
    const authChannel = returnChannelFromChannelId(channelId);
    if (!(isAuthMemberOfChannel(authUser, authChannel)) || (!(isAuthMemberOfDm(authUser, ogDm)))) {
      throw HTTPError(403, 'User is not a part of both the channel and the DM');
    }
  }

  let messageShared: MessageInfo;
  const data = getData();
  // iterates through channels to find the message that is to be shared
  for (const chan of data.channels) {
    const message = chan.allMessages.find((x: MessageInfo) => x.messageId === ogMessageId);
    if (message !== undefined) {
      messageShared = message;
    }
  }

  // iterates though dms to find the message that is to be shared
  for (const dm of data.dms) {
    const message = dm.allMessages.find((x: MessageInfo) => x.messageId === ogMessageId);
    if (message !== undefined) {
      messageShared = message;
    }
  }

  const date = Math.floor((new Date()).getTime() / 1000);
  const newMessageId = Math.floor(Math.random() * 1000000000);

  const returnMessage = {
    messageId: newMessageId,
    uId: messageShared.uId,
    message: message + messageShared.message,
    timeSent: date,
    reacts: messageShared.reacts,
    isPinned: messageShared.isPinned
  };

  // pushing to DM
  if (channelId === -1) {
    for (const dm of data.dms) {
      if (dm.dmId === dmId) {
        dm.allMessages.push(returnMessage);
      }
    }
  }

  // pushing to channel
  if (dmId === -1) {
    for (const chan of data.channels) {
      if (chan.channelId === channelId) {
        chan.allMessages.push(returnMessage);
      }
    }
  }
  setData(data);
  return { sharedMessageId: newMessageId };
}
