import {
  channelsCreateV3,
  clearV2,
  authRegisterV3,
  messageSendV2,
  messageReact,
  dmCreateV2,
  messageSenddmV2,
  channelInviteV3
} from './testHelpers';

import type {
  AuthUserId,
  ChannelId,
  MessageReturn,
  DmID
} from './interface';

let newPerson: AuthUserId;
let newPerson2: AuthUserId;
let channelId: ChannelId;
let dm1: DmID;
let messageId: MessageReturn;
let messageId2: MessageReturn;

beforeEach(() => {
  clearV2();
  newPerson = authRegisterV3('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
  newPerson2 = authRegisterV3('sammyg@gmail.com', 'pppassword', 'Samuel', 'Grog') as AuthUserId;
  channelId = channelsCreateV3(newPerson.token, 'New Channel', false);
  messageId = messageSendV2(newPerson.token, channelId.channelId, 'this is a message');
});

describe('Testing different parameters for channel messages', () => {
  test('reactId is not a valid ID', () => {
    expect(messageReact(newPerson.token, messageId.messageId, 4)).toStrictEqual(400);
  });
  test('message already contains a react with ID', () => {
    messageReact(newPerson.token, messageId.messageId, 1);
    expect(messageReact(newPerson.token, messageId.messageId, 1)).toStrictEqual(400);
  });
  test('messageId is not valid', () => {
    expect(messageReact(newPerson.token, -1, 1)).toStrictEqual(400);
  });
  test('invalid token not valid', () => {
    expect(messageReact('abc', messageId.messageId, 1)).toStrictEqual(403);
  });
  test('valid parameters', () => {
    expect(messageReact(newPerson.token, messageId.messageId, 1)).toStrictEqual({});
  });
  test('two people reacting to the same message', () => {
    newPerson2 = authRegisterV3('sammyg2@gmail.com', 'pppassword2', 'Sammy', 'Gone') as AuthUserId;
    channelInviteV3(newPerson.token, channelId.channelId, newPerson2.authUserId);
    messageReact(newPerson2.token, messageId.messageId, 1);
    expect(messageReact(newPerson.token, messageId.messageId, 1)).toStrictEqual({});
  });
  test('DM message already contains a react with ID', () => {
    dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
    messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
    messageReact(newPerson.token, messageId2.messageId, 1);
    expect(messageReact(newPerson.token, messageId2.messageId, 1)).toStrictEqual(400);
  });
  test('two people react to same message', () => {
    dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
    messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
    messageReact(newPerson.token, messageId2.messageId, 1);
    expect(messageReact(newPerson2.token, messageId2.messageId, 1)).toStrictEqual({});
  });
  test('Valid DM parameters', () => {
    dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
    messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
    expect(messageReact(newPerson.token, messageId.messageId, 1)).toStrictEqual({});
  });
  // test('Valid DM parameters', () => {
  //   dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
  //   const newPerson3 = authRegisterV3('sammygg@gmail.com', 'pppassword', 'Samuelo', 'Grogy') as AuthUserId;
  //   messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
  //   expect(messageReact(newPerson3.token, messageId.messageId, 1)).toStrictEqual(400);
  // });
});
