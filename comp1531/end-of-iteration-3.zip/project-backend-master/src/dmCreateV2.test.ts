/* //////////////// dmCreateV2 ////////////////////

#Passing Parameters:( token: string, uIds: Array<uId> )

# Return type if no error: { dmId: number }

# Cases to be considered:
    -Error Scenarios
        // 403 ERROR: invalid token is given
        // 400 ERROR: invalid uId in given array of uIds
        // 400 ERROR: Duplicate uId in given array of uIds
        // 400 ERROR: ID of token owner is in  given array of uIds
    -Return Correct Type (x2)
        - passing valid token and empty array
        - passing valid token and array of uIds

// /////////////////////////////////////////////////// */

// import functions
import {
  authRegisterV3,
  dmCreateV2,
  clearV2
} from './testHelpers';

// import interface
import {
  AuthUserId,
} from './interface';

let mainUser: AuthUserId;
let user1: AuthUserId;
let user2: AuthUserId;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
  user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
  user2 = authRegisterV3('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
});

describe('Error Casses', () => {
  test('Invalid token', () => {
    const testVar = dmCreateV2(mainUser.token + 'ABG', [user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual(403);
  });

  test('Invalid uId in given array of uIds', () => {
    const testVar = dmCreateV2(mainUser.token, [user1.authUserId + 999, user2.authUserId]);
    expect(testVar).toStrictEqual(400);
  });

  test('duplicate uId in given array of uIds', () => {
    const testVar = dmCreateV2(mainUser.token, [user2.authUserId, user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual(400);
  });
});

describe('Returns Correct Type', () => {
  test('Passing valid token and empty array', () => {
    const testVar = dmCreateV2(mainUser.token, []);
    expect(testVar).toStrictEqual({ dmId: expect.any(Number) });
  });

  test('Passing valid token and array of uIds', () => {
    const testVar = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
    expect(testVar).toStrictEqual({ dmId: expect.any(Number) });
  });
});
