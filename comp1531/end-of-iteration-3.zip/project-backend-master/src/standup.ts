// import functions
import { getData, setData } from './dataStore';
import { getHashOf } from './universalFunctions';
import { messageSendV1 } from './message';
import HTTPError from 'http-errors';

// import interface
import {
  ErrorMessage,
  Time,
  StandUp,
  Status,
  tokenObj,
  aUser
} from './interface';

/**
 *  /standup/start/v1
 *
 *  For a given channel, starts a standup period lasting
 *  length seconds.
 *  During this standup period, if someone calls standup/send
 *  with a message, it will be buffered during the length-second
 *  window. Then, at the end of the standup, all buffered messages
 *  are packaged into one message, and this packaged message is sent
 *  to the channel from the user who started the standup: see section 6.13
 *  for more details. If no standup messages are sent during the standup,
 *  no message should be sent at the end.
 *
 *  @param {string} token       - token of a user who requests
 *  @param {number} channelId   - channel ID for stand up
 *  @param {number} length      - length of standup
 *  @returns {{error: string}}  - if error
 *  @returns {{timeFinish}}     - returns the dmId if successful.
 */
export function standupStartV1(token: string, channelId: number, length: number): (Time|ErrorMessage) {
  const data = getData();

  // Validates incoming length of the standup
  if (length < 0) throw HTTPError(400, 'Error: Length must be greater than zero.');

  // Validates the incoming token
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid access: Unauthorized request');

  // Valididats the incoming channel ID
  const thread = data.channels.find(channel => channel.channelId === channelId);
  if (!thread) throw HTTPError(400, 'Error: Channel does not exist');

  // Authorised access check
  if (!(thread.allMembers.find((access: aUser) => access.uId === validUser.uId))) {
    throw HTTPError(403, 'Error: ACCESS DENIED');
  }

  /**   -----ACTIVE STANDUP CHECK + Creates new standup-------
   *  # checks whether channel exists in data.standups
   *        if existing standup is found:
   *          - checks whether the exisiting standup is in progress
   *              => if in progress, RETURNS ERROR.
   *              => else, updates the exisiting standup with new finishing time
   *        if not:
   *          - this means there are no standups from the channel
   *          - proceess to start a new standup.
   */
  const index = data.standups.findIndex(check => check.channelId === thread.channelId);
  const finishTime = Math.floor(Date.now() / 1000) + length;
  if (index !== -1) {
    // active Standup in progress check
    const activeCheck = data.standups[index].timeFinish - Math.floor(Date.now() / 1000);
    if (activeCheck > 0) throw HTTPError(400, 'Error: Active Standup in Progress');

    // Updates the existing standup with new finishing time new triggerId;
    data.standups[index].triggerToken = token;
    data.standups[index].timeFinish = finishTime;
  } else {
    // Creates a new standup
    const newStandup : StandUp = {
      channelId: thread.channelId,
      triggerToken: token,
      timeFinish: finishTime,
      message: '',
      queue: [],
    };
    data.standups.push(newStandup);
  }
  setData(data);
  return { timeFinish: finishTime };
}

/**
 *  standup/active/v1
 *
 *  For a given channel, returns whether a standup is active
 *  in it, and what time the standup finishes. If no standup
 *  is active, then timeFinish should be null.
 *
 *  @param {string} token       - token of a user who requests
 *  @param {number} channelId   - channel ID for stand up
 *  @returns {{error: string}}  - if error
 *  @returns {{
 *    isActive: boolean,
 *    timeFinish: number | null
 *  }} - returns if successful.
 */
export function standupActiveV1(token: string, channelId: number): (Status | ErrorMessage) {
  const data = getData();
  // Validates the incoming token
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: tokenObj) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // Valididats the incoming channel ID
  const thread = data.channels.find(channel => channel.channelId === channelId);
  if (!thread) throw HTTPError(400, 'Error: Invalid Channel');

  // Authorised access check
  if (!(thread.allMembers.find((access: aUser) => access.uId === validUser.uId))) {
    throw HTTPError(403, 'Error: ACCESS DENIED');
  }

  // GETS THE STATUS OF THE STANDUP
  const info = data.standups.find(s => s.channelId === thread.channelId);
  if (info) {
    const status = info.timeFinish - Math.floor(Date.now() / 1000);

    // if standup is active
    if (status > 0) return { isActive: true, timeFinish: info.timeFinish };

    // if standup is inactive but message and queue isn't sent to channel.
    if (info.message.length > 0) {
      // eslint-disable-next-line
      const msgId = messageSendV1(info.triggerToken, channelId, info.message);

      // reset the message string and queue of the standup
      const index = data.standups.findIndex(i => i.channelId === thread.channelId);
      data.standups[index].message = '';
      data.standups[index].queue = [];
    }
  }

  // standup is inactive OR channel is not in data.standups
  return { isActive: false, timeFinish: null };
}

/**
 *  standup/send/v1
 *
 *  For a given channel, if a standup is currently active
 *  in the channel, sends a message to get buffered in the
 *  standup queue. Note: @ tags should not be parsed as proper
 *  tags (i.e. no notification should be triggered on send,
 *  or when the standup finishes)
 *
 *  @param {string} token       - token of a user who requests
 *  @param {number} channelId   - channel ID for stand up
 *  @param {string} message     - message to be sent
 *  @returns {{error: string}}  - if error
 *  @returns {} - returns if successful.
*/
export function standupSendV1(token: string, channelId: number, message: string): (Record<string, never> | ErrorMessage) {
  const data = getData();

  // Validates the incoming token
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: tokenObj) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // Valididats the incoming channel ID
  const thread = data.channels.find(channel => channel.channelId === channelId);
  if (!thread) throw HTTPError(400, 'Error: Invalid Channel');

  // Validates lenght of the string
  if (message.length > 1000) throw HTTPError(400, 'Error: Message is too long!');

  // Authorised access check
  if (!(thread.allMembers.find((access: aUser) => access.uId === validUser.uId))) {
    throw HTTPError(403, 'Error: ACCESS DENIED');
  }

  // Checks if standup is running
  const index = data.standups.findIndex(index => index.channelId === thread.channelId);
  if (index === -1) throw HTTPError(400, 'No Standup is in progress');
  const check = data.standups[index].timeFinish - Math.floor(Date.now() / 1000);
  if (check <= 0) throw HTTPError(400, 'No Standup is in progress');

  // Manipulate the incoming the message and update the standup
  const newMsg = `${validUser.handleStr}: ${message}`;
  data.standups[index].queue.push(newMsg);
  data.standups[index].message = data.standups[index].queue.join('\n');
  setData(data);
  return {};
}
