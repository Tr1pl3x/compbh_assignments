import { getData, setData } from './dataStore';
import type { ChannelId, Channels, ChannelsReturn, ChannelsListAll, ChannelsListAllReturn, ErrorMessage, ChannelsListReturn } from './interface';
import { isValidToken, getUserFromToken } from './universalFunctions';
import HTTPError from 'http-errors';

/**
  * <Creates a new channel with the given name, that is either a public or private channel.
  *  The user who created it automatically joins the channel.>
  *
  * @param {authUserId} - User Id of member/admin
  * @param {name}       - name of the channel being created
  * @param {isPublic}   - Booleen value for if the channle is public
  * ...
  *
  * @returns {channelId} - returns the Id of the created channel
*/

export function channelsCreateV1 (token: string, name: string, isPublic: boolean): (ChannelId | ErrorMessage | undefined) {
  if (name.length < 1 || name.length > 20) {
    // returns error if the length of name is less than 1 or more than 20 characters
    throw HTTPError(400, 'name length too long/short');
  }
  // generating a unique channelId
  const channelId = Math.floor(Math.random() * 1000000000);
  const data = getData();

  // checking that the token is valid
  if (!isValidToken(token)) {
    throw HTTPError(403, 'Invalid Token');
  }

  // finding user in the dataStore with the given token
  const user = getUserFromToken(token);

  const tempMember = {
    uId: user.uId,
    email: user.email,
    nameFirst: user.nameFirst,
    nameLast: user.nameLast,
    handleStr: user.handleStr,
    // channelsJoined: user.channelsJoined,
  };

  // creating new channel to push
  const newChannel: Channels = {
    channelId: channelId,
    name: name,
    isPublic: isPublic,
    ownerMembers: [],
    allMembers: [],
    allMessages: []
  };
  newChannel.allMembers.push(tempMember);
  newChannel.ownerMembers.push(tempMember);
  user.channelsJoined.push(newChannel);

  // pushing new channel and returning
  data.channels.push(newChannel);
  setData(data);
  return { channelId };
}

/**
  * <Provides an array of all channels (and their associated details)
  * that the authorised user is part of.>
  *
  * @param { authUserId } name - User Id of the student/admin
  * ...
  * @returns { channels } - array of the channels and their details
*/
export function channelsListV1 (token: string): (ChannelsReturn | ErrorMessage) {
  const data = getData();

  // checking that the token is valid
  if (!isValidToken(token)) {
    throw HTTPError(403, 'Invalid Token');
  }

  // finding user in the dataStore with the given token
  const user = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === token));
  // channelNames is an array of the channels that the user is in
  const channelNames = user.channelsJoined;
  const channels: Array<ChannelsListReturn> = [];

  // going through the array of channel names
  for (const Id of channelNames) {
    for (const potentialChannel of data.channels) {
      // finding channel
      if (potentialChannel.channelId === Id.channelId) {
        // found the channel, pushing it into channels[]
        channels.push(
          {
            channelId: potentialChannel.channelId,
            name: potentialChannel.name
          }
        );
      }
    }
  }
  return { channels };
}

export function channelsListAllV1(token: string): ChannelsListAllReturn | ErrorMessage {
  const data = getData();

  // check if authUserId is valid
  // const iDchecker = data.users.find(iDchecker => iDchecker.uId === authUserId);
  if (!isValidToken(token)) {
    throw HTTPError(403, 'Invalid Token');
  }
  for (const person of data.users) {
    // looping through tokens as there could be multiple
    for (const tokenObj of person.tokens) {
      if (tokenObj.tokenId === token) {
        // validToken = true;
        break;
      }
    }
  }

  const channels: Array<ChannelsListAll> = [];
  // console.log(channels)
  for (const channel of data.channels) {
    const createChan: ChannelsListAll = {
      channelId: channel.channelId,
      name: channel.name,
    };
    channels.push(createChan);
  }
  return { channels };
}
