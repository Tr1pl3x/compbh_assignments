// import functions
import HTTPError from 'http-errors';
import { getData, setData } from './dataStore';
import {
  getuId,
  getUserFromId,
  getHashOf,
  getUserFromToken,
  isValidChannel,
  isValidToken,
  isAuthMemberOfChannel,
  isSameUser,
  isUidMemberOfChannel,
  returnChannel,
  uIdValid,
} from './universalFunctions';
// import types
import type { ChannelDetails, Messages, MessageInfo, ErrorMessage, User, aUser } from './interface';

/**
 * channelInviteV3
 * Invites a user with ID uId to join a channel with ID channelId.
 * Once invited, the user is added to the channel immediately.
 * In both public and private channels, all members are able to invite users.
 * @param {string} token - The auth token (header)
 * @param {number} channelId - channelId specified (body)
 * @param {number} uId - uId of user to be invited (body)
 * @returns {Record<string, never>} - Empty object if successful.
 * @throws {Error} Throws 400 or 403 error
 */
export function channelInviteV1(token: string, channelId: number, uId: number): Record<string, never> {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (!(isValidChannel(channelId))) {
    throw HTTPError(400, 'Error: Invalid channelId');
  } else if ((!(uIdValid(uId)))) {
    throw HTTPError(400, 'Error: Invalid uId');
  }
  const data = getData();
  const validUserId = getUserFromToken(token);
  if (isSameUser(validUserId, uId)) {
    throw HTTPError(400, 'Error: Enter another user uId');
  }
  const currChannel = returnChannel(channelId);

  if (!(isAuthMemberOfChannel(validUserId, currChannel))) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the channel');
  }
  if (isUidMemberOfChannel(uId, currChannel)) {
    throw HTTPError(400, 'Error: uId already exists in channel');
  }
  // Retrieve the member to be added
  const newUser: User = getUserFromId(uId);
  // Add user details into the array allMembers of channel
  currChannel.allMembers.push({
    uId: newUser.uId,
    email: newUser.email,
    nameFirst: newUser.nameFirst,
    nameLast: newUser.nameLast,
    handleStr: newUser.handleStr
  });
  // Add channelId to the array channelsJoined of the user
  newUser.channelsJoined.push({ channelId });
  setData(data);
  return {};
}

/**
 * channelDetailsV3
 * Given a channel with ID channelId that the authorised user is a member of,
 * provides basic details about the channel.
 *
 * @param {string} token - token of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @returns {{error: string}} on error
 * @returns {{
*     name: string,
*     isPublic: boolean,
*     Array{ownerMembers},
*     Array{allMembers}
* }} - Returns name of owner, status of channel, array of owner members
* and followed by an array of all members if successful.
*/
export function channelDetailsV1(token: string, channelId: number): (ChannelDetails|ErrorMessage) {
  const data = getData();

  // valid token check
  const hashedToken = getHashOf(token);
  const theUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!theUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // valid channel check
  const thread = (data.channels).find(channel => channel.channelId === channelId);
  if (!thread) throw HTTPError(400, 'ERROR: Channel does not exist');

  // authorised access check
  const accessUser = thread.ownerMembers.find((accessUser: { uId: number }) => accessUser.uId === theUser.uId);
  if (!accessUser) throw HTTPError(403, 'Error: Permission Denied: Unauthorised access');

  // returns data successfully
  const theChannel = {
    name: thread.name,
    isPublic: thread.isPublic,
    ownerMembers: thread.ownerMembers,
    allMembers: thread.allMembers,
  };
  return theChannel;
}

/**
 * channelJoinV3
 * Given a channelId of a channel that the authorised user can join,
 * adds them to that channel.
 *
 * @param {number} validUserId - Id of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @returns {{error: string}} on error
 * @returns {{}} - No return value if successful.
 */

export function channelJoinV1(token: string, channelId: number): (ErrorMessage | Record<string, never>) {
  const data = getData();

  // if empty inputs are given
  if (token === '') throw HTTPError(403, 'Error: Invalid token: user not found');

  // valid token check
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // invalid channel
  const thread = data.channels.find(thread => thread.channelId === channelId);
  if (!thread) throw HTTPError(400, 'ERROR: Channel does not exist');

  // Private Channel Check
  if (thread.isPublic === false) throw HTTPError(403, 'Error: Permission Denied: Unauthorised access');

  // if validUser is already in the requested channel
  const check = thread.allMembers.find((user: aUser) => user.uId === validUser.uId);
  if (check) throw HTTPError(400, 'ERROR: User already part of requested channel');

  // adding new member to the requested channel and return
  const newMember = {
    uid: validUser.uId,
    tokens: validUser.tokens,
    email: validUser.email,
    nameFirst: validUser.nameFirst,
    nameLast: validUser.nameLast,
    handleStr: validUser.handleStr
  };

  // Iterates to find the requested channel,
  // then push the new member to the all members array of the found channel
  for (const curr of data.channels) {
    if (curr.channelId === channelId) {
      curr.allMembers.push(newMember);
    }
  }
  // iterates to find the user,
  // then push the new joined channel id to the users' channelJoined Arr[]
  for (const curr of data.users) {
    if (curr.uId === validUser.uId) {
      curr.channelsJoined.push(thread.channelId);
    }
  }
  setData(data);
  return {};
}
/**
 * channelMessagesV3
 * Given a channel with ID channelId that the authorised user is a member of,
 * returns up to 50 messages between index "start" and "start + 50".
 * Message with index 0 (i.e. the first element in the returned array of messages)
 * is the most recent message in the channel.
 *
 * This function returns a new index "end".
 * If there are more messages to return after this function call,
 * "end" equals "start + 50".
 * If this function has returned the least recent messages in the channel,
 * "end" equals -1 to indicate that there are no more messages to load after this return.
 * @param {string} token - The auth token (header)
 * @param {number} channelId - channelId specified (query string)
 * @param {number} start - starting index of messages (query string)
 * @returns {{
 *    Array<{message}>
 *    start: number,
 *    end: number
 * }}
 * @throws {Error} Throws 400 or 403 error
 */
export function channelMessagesV1(token: string, channelId: number, start: number): Messages {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if (!(isValidChannel(channelId))) {
    throw HTTPError(400, 'Error: Invalid channelId');
  } else if (start < 0) {
    throw HTTPError(400, 'Error: Start must be positive number');
  }
  const data = getData();
  const validUserId = getUserFromToken(token);
  const currChannel = returnChannel(channelId);
  const messages: Array<MessageInfo> = [];

  if (!(isAuthMemberOfChannel(validUserId, currChannel))) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the channel');
  }
  data.start = start;
  let end = start + 50;
  if ((start === 0) && ((currChannel.allMessages).length === 0)) {
    data.end = -1;
    setData(data);
    end = data.end;
    return {
      messages,
      start,
      end
    };
  }
  if (start >= (currChannel.allMessages).length) {
    throw HTTPError(400, 'Start index exceeds the number of messages in the channel');
  }
  const tempStart = start.valueOf();
  let messageIndex = 0;
  for (let i = tempStart; i < (currChannel.allMessages).length; i++, messageIndex++) {
    messages[messageIndex] = currChannel.allMessages[i];
    // Limit the number of messages to 50
    if (messageIndex === 49) break;
  }
  if (start < (currChannel.allMessages).length && (currChannel.allMessages).length <= end) {
    data.end = -1;
    end = data.end;
  }
  setData(data);
  messages.reverse();
  return {
    messages,
    start,
    end
  };
}

export function channelLeaveV1 (token : string, channelId: number) : (ErrorMessage | Record<string, never>) {
  const data = getData();
  // checking that the token is valid
  if (!isValidToken(token)) {
    throw HTTPError(403, 'invalid token');
  }

  // check that the channel is reffering to a valid channel
  if (!isValidChannel(channelId)) {
    throw HTTPError(400, 'invlaid channelId');
  }

  // need to add code to check of the user is the starter of an active startup in the channel

  // getting channel
  const chan = returnChannel(channelId);

  // getting uId of user
  const userId = getuId(token);

  // finding user in ownerMembers and removing them
  for (let i = 0; i < chan.ownerMembers.length; i++) {
    const user = chan.ownerMembers[i];
    if (user.uId === userId) {
      chan.ownerMembers.splice(i, 1);
    }
  }

  // finding user in channel and removing them
  for (let i = 0; i < chan.allMembers.length; i++) {
    const user = chan.allMembers[i];
    if (user.uId === userId) {
      chan.allMembers.splice(i, 1);
      setData(data);
      return {};
    }
  }
  throw HTTPError(403, 'user is not a member!');
}

/**
  * <Makes user with user ID uId an owner of the channel>
  *
  * @header: token      - token of member/admin
  * @param {channelId}  - channelID of channel
  * @param {uId}        - uId of potential new owner
  * ...
  *
  * @returns {}         - returns {} on success
*/
export function channelAddOwnerV1 (token: string, channelId: number, uId: number) : (ErrorMessage | Record<string, never>) {
  const data = getData();
  // checking that the token is valid
  if (!isValidToken(token)) {
    throw HTTPError(403, 'invalid token');
  }

  // check that the channel is reffering to a valid channel
  if (!isValidChannel(channelId)) {
    throw HTTPError(400, 'invalid channelId');
  }

  // check if the uId is valid
  if (!uIdValid(uId)) {
    throw HTTPError(400, 'invalid uId');
  }

  // check if user is in the channel
  let isMember: boolean;
  isMember = false;
  const chan = returnChannel(channelId);
  for (const member of chan.allMembers) {
    if (member.uId === uId) {
      isMember = true;
    }
  } if (!isMember) {
    throw HTTPError(400, 'uId refers to user who is not in the channel');
  }

  // check if authorised user has owner permissions
  let isAuthOwner: boolean;
  let isUIdOwner: boolean;
  isAuthOwner = false;
  isUIdOwner = false;
  const authId = getuId(token);
  for (const owner of chan.ownerMembers) {
    if (owner.uId === authId) {
      isAuthOwner = true;
    }
    if (owner.uId === uId) {
      isUIdOwner = true;
    }
  }

  // throwing error if authorised user is not an owner/ uId is already an owner
  if (!isAuthOwner) {
    throw HTTPError(403, 'autherised user is not an owner');
  } if (isUIdOwner) {
    throw HTTPError(400, 'User Id is already an owner');
  }

  // autherised user is an owner, add user to ownerMembers
  const user = getUserFromId(uId);
  chan.ownerMembers.push(user);
  setData(data);
  return {};
}

/**
  * <Removes user with user ID uId as an owner of the channel>
  *
  * @header: token      - token of member/admin
  * @param {channelId}  - channelID of channel
  * @param {uId}        - uId of potential new owner being removed
  * ...
  *
  * @returns {}         - returns {} on success
*/
export function channelRemoveOwnerV1 (token: string, channelId: number, uId: number) : (ErrorMessage | Record<string, never>) {
  const data = getData();
  // checking that the token is valid
  if (!isValidToken(token)) {
    throw HTTPError(403, 'invalid token');
  }

  // check that the channel is reffering to a valid channel
  if (!isValidChannel(channelId)) {
    throw HTTPError(400, 'invalid channelId');
  }

  // check if the uId is valid
  if (!uIdValid(uId)) {
    throw HTTPError(400, 'invalid uId');
  }

  // check if user is in the channel
  let isMember: boolean;
  isMember = false;
  const chan = returnChannel(channelId);
  for (const member of chan.allMembers) {
    if (member.uId === uId) {
      isMember = true;
    }
  } if (!isMember) {
    throw HTTPError(400, 'uId refers to user who is not in the channel');
  }

  // check if  user/autherised user has owner permissions
  let isOwner: boolean;
  let isAuthOwner: boolean;
  const authuId = getuId(token);
  isAuthOwner = false;
  isOwner = false;

  // looping through owners and throwing errors if either user/authuser is not an owner
  for (const owner of chan.ownerMembers) {
    if (owner.uId === uId) {
      isOwner = true;
    }
    if (owner.uId === authuId) {
      isAuthOwner = true;
    }
  } if (!isOwner) {
    throw HTTPError(400, 'user is not an owner');
  } else if (!isAuthOwner) {
    throw HTTPError(403, 'autherised user is not an owner');
  }

  // check if user is the only owner
  if (chan.ownerMembers.length === 1) {
    throw HTTPError(400, 'user is the only owner');
  }

  // remove the owner
  for (const owner of chan.ownerMembers) {
    if (owner.uId === uId) {
      const index = chan.ownerMembers.indexOf(owner);
      chan.ownerMembers.splice(index, 1);
    }
  }

  setData(data);
  return {};
}
