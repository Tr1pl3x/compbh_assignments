import { clearV2, authLogOutV2, authRegisterV3, authLoginV3 } from './testHelpers';
import type { AuthUserId } from './interface';
beforeEach(() => {
  clearV2();
});

// Tests for invalid emails
test('Testing for Invalid emails', () => {
  const result = authRegisterV3('Jonnygmail.com', 'Password', 'John', 'Smith');
  expect(result).toBe(400);
});

// Tests for email already in use
describe('Testing for email already in use', () => {
  test('Registering user with already existing email', () => {
    authRegisterV3('Jonny@gmail.com', 'Pass1234', 'John', 'Smith');
    const newuser = authRegisterV3('Jonny@gmail.com', 'Pass12345', 'Johno', 'Smith');
    expect(newuser).toBe(400);
  });
});

// Tests for invalid passwords
describe('Testing for Invalid passwords', () => {
  test('Password contains less than 6 characters', () => {
    const User = authRegisterV3('Jonny@gmail.com', 'Pswrd', 'John', 'Smith');
    expect(User).toBe(400);
  });
});

// Tests for firstName
describe('Testing for Invalid first names', () => {
  test.each([
    ['', 'First name contains less than 1 character'],
    ['qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmoopd',
      'First name contains more than 50 characters'],
  ])('Invalid first name: %s (%s)', (firstName, testName) => {
    const User = authRegisterV3('Jonny@gmail.com', 'Pswrdfadd', firstName, 'Smith');
    expect(User).toBe(400);
  });
});

// Tests for lastName
describe('Testing for Invalid last names', () => {
  test.each([
    ['', 'Last name contains less than 1 character'],
    ['qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmoopd',
      'Last name contains more than 50 characters'],
  ])('Invalid last name: %s (%s)', (lastName, testName) => {
    const User = authRegisterV3('Jonny@gmail.com', 'Pswrdasd', 'John', lastName);
    expect(User).toBe(400);
  });
});

// Testing expected correct output (valid parameters)
describe('Testing for valid parameters that produce a non-error output', () => {
  // If we have no errors, the UserId returned will be a number
  test.each([
    ['Password is of expected length (length 9)', 'Jonny@gmail.com', 'Alpha4345', 'John', 'Smith'],
    ['Password is smallest it can be (length 6)', 'Jonny@gmail.com', 'Alpha1', 'John', 'Smith']
  ])('%s', (description, email, password, firstName, lastName) => {
    const result = authRegisterV3(email, password, firstName, lastName);
    expect(result).toHaveProperty('authUserId');
    expect(result).toHaveProperty('token');
  });
  test.each([
    ['J', 'S'],
    ['John', 'S'],
    ['J', 'Smith'],
  ])('First name and/or last name are of minimum value (%s, %s)', (firstName, lastName) => {
    const result = authRegisterV3('Jonny@gmail.com', 'Alpha4345', firstName, lastName);
    expect(result).toHaveProperty('authUserId');
    expect(result).toHaveProperty('token');
  });

  test.each([
    ['aqwsedrftgyhujikolpqwertyueuujdfghjksdfjgkfjdksdfj', 'aqwsedrftgyhujikolpqwertyueuujdfghjksdfjgkfjdksdfj']
  ])('First name and last name are of maximum value (%s, %s)', (firstName, lastName) => {
    const result = authRegisterV3('Jonny@gmail.com', 'Alpha4345', firstName, lastName);
    expect(result).toHaveProperty('authUserId');
    expect(result).toHaveProperty('token');
  });

  test('First name and last name are purely numerical', () => {
    const result = authRegisterV3('Jonny@gmail.com', 'Alpha4345', '12423329873402458', '3089540892340893240');
    expect(result).toHaveProperty('authUserId');
    expect(result).toHaveProperty('token');
  });
});

// We check if the email is valid
describe('authLoginV1 test', () => {
  test('Valid parameters', () => {
    authRegisterV3('evan.dang@unsw.edu.au', '1234322', 'Evan', 'Dang');
    const testing = authLoginV3('evan.dang@unsw.edu.au', '1234322');
    expect(testing).toHaveProperty('authUserId');
    expect(testing).toHaveProperty('token');
  });
  test('Invalid email', () => {
    authRegisterV3('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes');
    const testing = authLoginV3('evan.danekjrg@unsw.edu.au', '123456');
    expect(testing).toBe(400);
  });
  test('Invalid password', () => {
    authRegisterV3('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes');
    const testing = authLoginV3('evan.dang@unsw.edu.au', '12345kdfa6');
    expect(testing).toBe(400);
  });
});

/// --------test for logout---/////////
describe('Testing for logout', () => {
  test('Token Removed sucessfully', () => {
    const user = authRegisterV3('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes') as AuthUserId;
    const Logout = authLogOutV2(user.token);
    expect(Logout).toStrictEqual({});
  });
  test('Invalid Token', () => {
    const user = authRegisterV3('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes');
    const logout = authLogOutV2(user.token + 1);
    expect(logout).toBe(403);
  });
  test('2 Tokens added', () => {
    authRegisterV3('evan.dang@unsw.edu.au', '1234567', 'Johnny', 'Yes') as AuthUserId;
    const user1 = authLoginV3('evan.dang@unsw.edu.au', '1234567') as AuthUserId;
    const user2 = authLoginV3('evan.dang@unsw.edu.au', '1234567') as AuthUserId;
    const logout = authLogOutV2(user1.token);
    const logout1 = authLogOutV2(user2.token);
    expect(logout).toStrictEqual({});
    expect(logout1).toStrictEqual({});
  });
});
