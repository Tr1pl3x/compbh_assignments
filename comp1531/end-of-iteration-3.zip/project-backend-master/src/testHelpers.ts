import request from 'sync-request';
import config from './config.json';
export const URL = `${config.url}:${config.port}`;

/// ////////////////// AUTH ////////////////////////////////////

export function authRegisterV3(email: string, password: string, nameFirst: string, nameLast: string) {
  const json = {
    email,
    password,
    nameFirst,
    nameLast,
  };
  const res = request(
    'POST',
        `${URL}/auth/register/v3`,
        {
          json,
        }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function authLogOutV2(token: string) {
  const res = request(
    'POST',
    `${URL}/auth/logout/v2`,
    {
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function authLoginV3(email: string, password: string) {
  const json = {
    email,
    password,
  };
  const res = request(
    'POST',
        `${URL}/auth/login/v3`,
        {
          json,
        }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

/// /////////////////// CHANNEL ////////////////////////////////

export function channelAddOwnerV1(token: string, channelId: number, uId: number) {
  const res = request(
    'POST',
    `${URL}/channel/addowner/v2`,
    {
      json: {
        channelId: channelId,
        uId: uId
      },
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelRemoveOwnerV1(token: string, channelId: number, uId: number) {
  const res = request(
    'POST',
    `${URL}/channel/removeowner/v2`,
    {
      json: {
        channelId: channelId,
        uId: uId
      },
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelJoinV3(token: string, channelId: number) {
  const res = request(
    'POST',
    `${URL}/channel/join/v3`,
    {
      headers: { token },
      json: { channelId }
    }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function channelsListV2 (token : string) {
  const res = request(
    'GET',
    URL + '/channels/list/v3',
    {
      headers: {
        token: token,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelLeaveV1(token: string, channelId: number) {
  const res = request(
    'POST',
    `${URL}/channel/leave/v2`,
    {
      json: {
        channelId: channelId
      },
      headers: {
        token: token,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelInviteV3(token: string, channelId: number, uId: number) {
  const res = request(
    'POST',
      `${URL}/channel/invite/v3`,
      {
        headers: {
          token,
        },
        json: {
          channelId,
          uId,
        }
      }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelMessagesV3(token: string, channelId: number, start: number) {
  const res = request(
    'GET',
      `${URL}/channel/messages/v3`,
      {
        headers: {
          token,
        },
        qs: {
          channelId,
          start
        }
      }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelDetailsV3(token: string, channelId: number) {
  const res = request(
    'GET',
      `${URL}/channel/details/v3`,
      {
        headers: { token },
        qs: { channelId },
      });
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

/// /////////////////// CHANNEL(S) ////////////////////////////////
export function channelsCreateV3 (token : string, name : string, isPublic?: boolean) {
  const res = request(
    'POST',
    URL + '/channels/create/v3',
    {
      json: {
        name: name,
        isPublic: isPublic
      },
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function channelsListAllV3(token: string) {
  const res = request(
    'GET',
    `${URL}/channels/listAll/v3`,
    {
      headers: {
        token: token,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}
/// ////////////////////// DM //////////////////////////////

export function dmCreateV2(token: string, uId : number[]) {
  const res = request(
    'POST',
        `${URL}/dm/create/v2`,
        {
          headers: { token },
          json: { uId },
        }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function dmDetailsV2(token: string, dmId: number) {
  const res = request(
    'GET',
      `${URL}/dm/details/v2`,
      {
        headers: { token },
        qs: { dmId },
      }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function dmListV2(token: string) {
  const res = request(
    'GET',
      `${URL}/dm/list/v2`,
      {
        headers: { token },
      }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function dmLeaveV2(token: string, dmId: number) {
  const res = request(
    'POST',
    `${URL}/dm/leave/v2`,
    {
      headers: { token },
      json: { dmId },
    }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function dmRemoveV1(token: string, dmId: number) {
  const res = request(
    'DELETE',
        `${URL}/dm/remove/v2`,
        {
          headers: { token },
          qs: { dmId },
        }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function dmMessagesV2(token: string, dmId: number, start: number) {
  const res = request(
    'GET',
    `${URL}/dm/messages/v2`,
    {
      headers: { token },
      qs: { dmId, start },
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

/// ////////////////// MESSAGE ///////////////////////////////////

export function messageSenddmV2(token: string, dmId: number, message: string) {
  const res = request(
    'POST',
      `${URL}/message/senddm/v2`,
      {
        headers: {
          token
        },
        json: {
          dmId,
          message,
        },
      }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageSendV2(token: string, channelId: number, message: string) {
  const res = request(
    'POST',
    `${URL}/message/send/v2`,
    {
      headers: {
        token,
      },
      json: {
        channelId,
        message,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageEditV2(token: string, messageId: number, message: string) {
  const res = request(
    'PUT',
    `${URL}/message/edit/v2`,
    {
      headers: {
        token,
      },
      qs: {
        messageId,
        message,
      },
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageReact (token : string, messageId : number, reactId: number) {
  const res = request(
    'POST',
    URL + '/message/react/v1',
    {
      json: {
        messageId: messageId,
        reactId: reactId
      },
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageUnreact (token : string, messageId : number, reactId: number) {
  const res = request(
    'POST',
    URL + '/message/unreact/v1',
    {
      json: {
        messageId: messageId,
        reactId: reactId
      },
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageRemoveV2(token: string, messageId: number) {
  const res = request(
    'DELETE',
    `${URL}/message/remove/v2`,
    {
      headers: {
        token,
      },
      qs: {
        messageId,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageSendlaterV1(token: string, channelId: number, message: string, timeSent: number) {
  const res = request(
    'POST',
    `${URL}/message/sendlater/v1`,
    {
      headers: {
        token,
      },
      json: {
        channelId,
        message,
        timeSent,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageSendLaterDmV1(token: string, dmId: number, message: string, timeSent: number) {
  const res = request(
    'POST',
    `${URL}/message/sendlaterdm/v1`,
    {
      headers: {
        token,
      },
      json: {
        dmId,
        message,
        timeSent
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageUnpinV1(token: string, messageId: number) {
  const res = request(
    'POST',
    `${URL}/message/unpin/v1`,
    {
      headers: {
        token,
      },
      json: {
        messageId,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messagePinV1(token: string, messageId: number) {
  const res = request(
    'POST',
    `${URL}/message/pin/v1`,
    {
      headers: {
        token,
      },
      json: {
        messageId,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function messageShare(token: string, ogMessageId: number, message: string, channelId: number, dmId: number) {
  const res = request(
    'POST',
    `${URL}/message/share/v1`,
    {
      headers: {
        token,
      },
      json: {
        ogMessageId,
        message,
        channelId,
        dmId
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function userProfileV3(token: string, uId: number) {
  const res = request(
    'GET',
      `${URL}/user/profile/v3`,
      {
        headers: {
          token,
        },
        qs: {
          uId,
        }
      }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function userProfileSethandleV2(token: string, handleStr:string) {
  const res = request(
    'PUT',
    `${URL}/user/profile/sethandle/v2`,
    {
      headers: {
        token,
      },
      qs: {
        handleStr,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function userProfileSetemailV1(token: string, email: string) {
  const res = request(
    'PUT',
    `${URL}/user/profile/setemail/v2`,
    {
      headers: {
        token,
      },
      qs: {
        email,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function userProfileSetnameV2(token: string, nameFirst: string, nameLast: string) {
  const res = request(
    'PUT',
    `${URL}/user/profile/setname/v2`,
    {
      headers: {
        token,
      },
      qs: {
        nameFirst,
        nameLast,
      },
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

/// /////////////////////// USER(S) ////////////////////////////
export function usersAllV2(token: string) {
  const headers = {
    token,
  };
  const res = request(
    'GET',
    `${URL}/users/all/v2`,
    {
      headers,
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function userProfileUploadphotov1(token: string, imgUrl: string, xStart: number, yStart: number, xEnd: number, yEnd: number) {
  const json = {
    imgUrl,
    xStart,
    yStart,
    xEnd,
    yEnd,
  };
  const res = request(
    'POST',
        `${URL}/user/profile/uploadphoto/v1`,
        {
          headers: {
            token,
          },
          json,
        }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

/// ///////////////////////////////////////////////////////////

export function clearV2() {
  const res = request(
    'DELETE',
    `${URL}/clear/v2`
  );
  return JSON.parse(res.getBody() as string);
}

export function notificationsGetV1(token: string) {
  const res = request(
    'GET',
      `${URL}/notifications/get/v1`,
      {
        headers: { token },
      }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function authPasswordRequestV1(email: string) {
  const res = request(
    'POST',
    `${URL}/auth/passwordreset/request/v1`,
    {
      qs: {
        email,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function authPasswordResetV1(resetCode: string, newPassword: string) {
  const res = request(
    'POST',
    `${URL}/auth/passwordreset/reset/v1`,
    {
      qs: {
        resetCode,
        newPassword,
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

export function clearData() {
  request(
    'DELETE',
    URL + '/clear/v1'
  );
}

/// /////////////////// STANDUP //////////////////////////////

export function standupStartV1(token: string, channelId : number, length: number) {
  const res = request(
    'POST',
        `${URL}/standup/start/v1`,
        {
          headers: { token },
          json: { channelId, length },
        }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function standupActiveV1(token: string, channelId: number) {
  const res = request(
    'GET',
        `${URL}/standup/active/v1`,
        {
          headers: { token },
          qs: { channelId },
        }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

export function standupSendV1(token: string, channelId : number, message: string) {
  const res = request(
    'POST',
        `${URL}/standup/send/v1`,
        {
          headers: { token },
          json: { channelId, message },
        }
  );
  if (res.statusCode === 200) return JSON.parse(res.getBody() as string);
  return res.statusCode;
}

/// //////////////////////// Search //////////////////////////////////////////
export function searchV1(token: string, queryStr: string) {
  const res = request(
    'GET',
    `${URL}/search/v1`,
    {
      qs: {
        queryStr: queryStr
      },
      headers: {
        token: token
      }
    }
  );
  if (res.statusCode === 200) {
    return JSON.parse(res.getBody() as string);
  }
  return res.statusCode;
}

/// //////////////////////////////////////////////////////////////////////////
