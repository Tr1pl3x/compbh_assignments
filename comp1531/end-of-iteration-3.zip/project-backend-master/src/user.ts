import { getData, setData } from './dataStore';
import validator from 'validator';
import type { UserProfile, ErrorMessage, UsersReturn, tokenObj, aUser, UserInfo } from './interface';
import { isValidToken, uIdValid, getUserFromId, validateName, getHashOf, isValidHttpUrl } from './universalFunctions';
import HTTPError from 'http-errors';
import Image from 'image-js';

/**
  * userProfileV3
  * For a valid user, returns information about their user ID, email, first name, last name, and handle
  * @param {string} token - The auth token (header)
  * @param {number} channelId - channelId specified (query string)
  * @param {number} uId - uId of user to be checked (query string)
  * @returns {{
  *   user: {
  *     uId: number,
  *     email: string,
  *     nameFirst: string,
  *     nameLast: string,
  *     handleStr: string
  *   }
  * }}
  * @throws {Error} Throws 400 or 403 error
*/

export function userProfileV1(token: string, uId: number): UserProfile {
  if (!isValidToken(token) || token === '') {
    throw HTTPError(403, 'Error: Invalid token: user not found');
  } else if ((!(uIdValid(uId)))) {
    throw HTTPError(400, 'Error: Invalid uId');
  }
  const newUser = getUserFromId(uId);
  const user = {
    uId: newUser.uId,
    email: newUser.email,
    nameFirst: newUser.nameFirst,
    nameLast: newUser.nameLast,
    handleStr: newUser.handleStr
  };
  return { user };
}

export function userProfileSethandleV1(token: string, handleStr: string) {
  // console.log(token)
  // console.log(handleStr)
  const data = getData();

  if (handleStr.length < 3 || handleStr.length > 20) {
    // console.log(handleStr.length)
    // return { error: 'handle length issue' };
    throw HTTPError(400, 'Error: handle length issue');
  }

  // avoid handle is already exist

  const handleCheck = data.users.find(a => a.handleStr === handleStr);
  // console.log(handleCheck)
  if (handleCheck) return { error: 'handle existed' };

  // console.log(unAlpha)
  // Validates the incoming token
  const hashedToken = getHashOf(token);
  const validUser = data.users.find((user: aUser) => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // const unAlpha = a-zA-Z0-9]/g;
  // handle chataacrer contains that is not alphanumeric
  const unAlpha = handleStr.match(/[^a-zA-Z0-9]/);
  if (unAlpha !== null) {
    // return { error: 'contains non alpha' };
    throw HTTPError(400, 'Error: contains non alpha');
  }

  for (const iD of data.users) {
    if (iD.handleStr === handleStr) {
      // return { error: 'User used' };
      throw HTTPError(400, 'Error: User has been used');
    }
  }

  const existedId = data.users.find((user: aUser) => user.tokens.find((t: tokenObj) => t.tokenId === hashedToken));
  for (const updatedHandle of data.users) {
    if (updatedHandle.uId === existedId.uId) {
      updatedHandle.handleStr = handleStr;
      setData(data);
      return {};
    }
  }
  return {};
}

export function userProfileSetemailV1(token: string, email: string) {
  const data = getData();

  validator.isEmail(email);

  // avoid email is already exist

  const emailCheck = data.users.find(a => a.email === email);
  // console.log(handleCheck)
  if (emailCheck) {
    // console.log(emailCheck)
    throw HTTPError(400, 'Email is not valid');
  }

  const hashedToken = getHashOf(token);
  const validUser = data.users.find((user: aUser) => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  if (!(data.users).find((user: aUser) => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken)) || token === '') {
    throw HTTPError(400, 'Email is already being used by another user');
  }

  const existedId = data.users.find((user: aUser) => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  for (const updatedemail of data.users) {
    if (updatedemail.uId === existedId.uId) {
      updatedemail.email = email;
      setData(data);
      return {};
    }
  }
  return { };
}

/**
  * userProfileSetnameV1
  * For a valid user, updates the value of their first and last name in the dataStore.
  * @param {string} token - The auth token (header)
  * @param {string} nameFirst - given First name (query string)
  * @param {string} nameLast - given Last name (query string)
  * @returns {
*   {}
  * }
  * @throws {Error} Throws 400 or 403 error
*/

export function userProfileSetnameV1(token: string, nameFirst: string, nameLast: string): (ErrorMessage | Record<string, never>) {
  // getting our data from dataStore.ts
  const data = getData();
  const firstNameError = validateName(nameFirst);
  const lastNameError = validateName(nameLast);
  if (!(isValidToken(token)) || (token === '')) {
    throw HTTPError(403, 'Token is invalid!');
  }

  if ((lastNameError) || (firstNameError)) {
    throw HTTPError(400, 'Invalid first or last name!');
  }

  // hash the token
  const hashedToken = getHashOf(token);

  // if token and first/last names are valid, set the users first and last name to the parameter values
  // use find method to find user associated to that token (store that in usersToken)
  const user = data.users.find((user: aUser) => user.tokens.find((t: tokenObj) => t.tokenId === hashedToken));
  user.nameFirst = nameLast;
  user.nameLast = nameLast;
  setData(data);
  return {};
}

export function usersAllV1(token: string): ErrorMessage | UsersReturn {
  // getting our data from dataStore.js
  const data = getData();

  if (isValidToken(token) && (token !== '')) {
    const users: UserInfo[] = [];
    for (const person of data.users) {
      const UserObject: UserInfo = {
        uId: person.uId,
        nameFirst: person.nameFirst,
        nameLast: person.nameLast,
        handleStr: person.handleStr,
        email: person.email
      };
      users.push(UserObject);
    }
    return { users };
  } else {
    throw HTTPError(403, 'Token is invalid!');
  }
}

export function userProfileUploadPhotov1(token: string, imgUrl: string, xStart: number, yStart: number, xEnd: number, yEnd: number) {
  // Error checking
  // const data = getData();
  // valid token check
  if (!isValidToken(token)) {
    throw HTTPError(403, 'Token is invalid!');
  }

  // checking if URL is valid
  if (!isValidHttpUrl(imgUrl)) {
    throw HTTPError(400, 'Image URL is invalid!');
  }
  // more valid URL checks
  if (!imgUrl.endsWith('.jpg') && !imgUrl.endsWith('.jpeg')) {
    throw HTTPError(400, 'Image URL is not jpg forma t!');
  }

  // checking valid dimensions
  if ((xEnd <= xStart) || (yEnd <= yStart)) {
    throw HTTPError(400, 'Invalid dimensions given');
  }

  const ImgWidth = xEnd - xStart;
  const ImgHeight = yEnd - yStart;
  Image.load(imgUrl).then(image => {
    // const croppedImage = image.crop({});
    const Width = image.width;
    const height = image.height;
    console.log(height);
    if ((ImgWidth > Width) || (ImgHeight > height) || ImgWidth < 0 || ImgHeight < 0) {
      throw HTTPError(400, 'Invalid x and y values given (cropping area out of bounds)!');
    }
  }).catch(function (err) {
    console.log(err);
  });

  // If there are no errors return an emtpy object
  return {};
}
