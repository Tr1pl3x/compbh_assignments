import { channelsCreateV1, channelsListV1, channelInviteV1 } from "./channels";
import { authRegisterV1 } from "./auth.js";
import { clearV1 } from "./other.js"

let newPerson;
let newPerson2

beforeEach(() => {
  clearV1();
  newPerson = authRegisterV1('csgo@gmail.com', 'PASSworD12', 'Sam', 'Jackson');
});

describe('Testing different parameters that covers every line of code', () => {
  test('Valid Parameters, one channel', () => {
    channelsCreateV1(newPerson.authUserId, 'Channel Name', true);
    expect(channelsListV1(newPerson.authUserId)).toStrictEqual({
      channels: [
        {
          channelId: expect.any(Number),
          name: expect.any(String),
          isPublic: expect.any(Boolean),
          admin: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMembers: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMessages: expect.any(Array),
        },
      ],
    });
  });

  test('authUserId is invalid', () => {
    channelsCreateV1(newPerson.authUserId, 'Channel Name', true);
    expect(channelsListV1('invalid userId')).toStrictEqual({ error: 'error' });
  });

  test('Valid Parameters, multiple channels', () => {
    channelsCreateV1(newPerson.authUserId, 'Channel Name', true);
    channelsCreateV1(newPerson.authUserId, 'Channel Name2', true);
    channelsCreateV1(newPerson.authUserId, 'Channel Name3', true);
    channelsCreateV1(newPerson.authUserId, 'Channel Name4', true);
    expect(channelsListV1(newPerson.authUserId)).toStrictEqual( {
      channels: [
        {
          channelId: expect.any(Number),
          name: expect.any(String),
          isPublic: expect.any(Boolean),
          admin: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMembers: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMessages: expect.any(Array),
        },
        {
          channelId: expect.any(Number),
          name: expect.any(String),
          isPublic: expect.any(Boolean),
          admin: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMembers: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMessages: expect.any(Array),
        },
        {
          channelId: expect.any(Number),
          name: expect.any(String),
          isPublic: expect.any(Boolean),
          admin: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMembers: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMessages: expect.any(Array),
        },
        {
          channelId: expect.any(Number),
          name: expect.any(String),
          isPublic: expect.any(Boolean),
          admin: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMembers: expect.arrayContaining([
            expect.objectContaining({ 
              uId: expect.any(Number), 
              email: expect.any(String),
              nameFirst: expect.any(String),
              nameLast: expect.any(String),
              handleStr: expect.any(String)
            })
          ]),
          allMessages: expect.any(Array),
        }
      ],
    });
  });

});