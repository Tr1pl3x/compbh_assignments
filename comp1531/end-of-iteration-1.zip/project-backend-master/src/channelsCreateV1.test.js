import { channelsCreateV1 } from "./channels"
import { authRegisterV1 } from "./auth.js"
import { clearV1 } from "./other.js"

let newPerson;

beforeEach(() => {
  clearV1();
  newPerson = authRegisterV1('csgo@gmail.com', 'PASSworD12', 'Sam', 'Jackson');
});

describe('Testing different parameters that covers every line of code', () => {
  test('Name length = 0, valid user', () => {
    expect(channelsCreateV1(newPerson.authUserId, '', false)).toStrictEqual({ error: 'error' });
  });
  test('Name length = 20, valid user', () => {
    expect(channelsCreateV1(newPerson.authUserId, '12345678901234567890', false)).toStrictEqual({ channelId: expect.any(Number) });
  });
  test('Name length = 21, valid user', () => {
    expect(channelsCreateV1(newPerson.authUserId, '123456789012345678901', false)).toStrictEqual({ error: 'error' });
  });
  test('Name length = 1, valid user', () => {
    expect(channelsCreateV1(newPerson.authUserId, '1', false)).toStrictEqual({ channelId: expect.any(Number) });
  });
  test('Invalid authUserId', () => {
    expect(channelsCreateV1('I am not a valid user', '1', false)).toStrictEqual({ error: 'error' });
  });
});
