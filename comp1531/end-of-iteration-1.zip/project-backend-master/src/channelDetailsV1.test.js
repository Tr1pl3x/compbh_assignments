/*
//////////////// channelDetailsV1 ////////////////////
Description :Given a channel with ID channelId that the authorised user.authUserId is a member of, provides basic details about the channel.
    
Parameters:( authUserId, channelId )

Return type if no error: { 
    name, 
    isPublic, 
    ownerMembers, 
    allMembers 
}

Return object {error: 'error'} when any of:
        channelId does not refer to a valid channel
        channelId is valid and the authorised user.authUserId is not a member of the channel
        authUserId is invalid
*/

/*///////////////////////////////////////////////////
Cases to be considered:
    -Error Scenarios
        // empty input is given
        // invalid channelId
        // invalid authUserId
        // valid channelId + authUserId have no access
    -Return Correct Type (x2)
*/////////////////////////////////////////////////////

import {authRegisterV1} from './auth.js';
import {channelsCreateV1} from './channels.js';
import {channelDetailsV1} from './channel.js';
import {clearV1} from './other.js';


// Reduces repitation assigning consant varaiable.
const ERROR = { error: expect.any(String) };

let user, thread
// Clear the data store before each test is run.
beforeEach(() => {
    clearV1();
    user = authRegisterV1('pyae@gmail.com','passcode','Pyae','Sone');
    thread = channelsCreateV1(user.authUserId, 'myChannel', true);    
});

describe('Error Casses', () => {
    test('empty input 1', () => {
        const testVar = channelDetailsV1('', thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });

    test('empty input 2', () => {
        const testVar = channelDetailsV1(user.authUserId, '');
        expect(testVar).toStrictEqual(ERROR);
    });
    
    test('invalid authUserID', () => {
        const testVar = channelDetailsV1(user.authUserId * 999, thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });

    test('invalid channelID', () => {
        const testVar = channelDetailsV1(user.authUserId, thread.channelId * 999);
        expect(testVar).toStrictEqual(ERROR);
    });

    test('Test', () => {
        const newUser = authRegisterV1('hellloQT@gmail.com','waasup','Shaw','Tea');
        const testVar = channelDetailsV1(newUser,thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });
});

describe('Returns Correct Type', () => {  
    test('correct data', () => {
        const testVar = channelDetailsV1(user.authUserId, thread.channelId);
        expect(testVar).toStrictEqual(
            {channel:{
                name: 'myChannel',
                isPublic: true,
                admin: expect.arrayContaining([
                    expect.objectContaining({ 
                      uId: expect.any(Number), 
                      email: 'pyae@gmail.com',
                      nameFirst: 'Pyae',
                      nameLast: 'Sone',
                      handleStr: 'pyaesone'
                    })
                  ]),
                  allMembers: expect.arrayContaining([
                    expect.objectContaining({ 
                        uId: expect.any(Number), 
                        email: 'pyae@gmail.com',
                        nameFirst: 'Pyae',
                        nameLast: 'Sone',
                        handleStr: 'pyaesone'
                    })
                  ])        
            }}
        )
    });
});

