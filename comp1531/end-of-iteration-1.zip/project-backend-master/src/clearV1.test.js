import { clearV1 } from './other.js'
import { authRegisterV1 } from './auth.js'
import { userProfileV1 } from './users.js'

const ERROR = { error: expect.any(String) };

beforeEach(() => {
  clearV1();
});

describe('clearV1 valid scenario', () => {
  // Test Return Value
  test('clearV1 returns empty dictionary', () => {
    expect(clearV1()).toStrictEqual({});
  });

});

describe('clearV1 data check', () => {
  // Test data 
  const user1 = authRegisterV1('email@gmail.com', 'password', 'Hayden', 'Smith');
  const user2 = authRegisterV1('test@gmail.com', '12345', 'Dean', 'Wunder');
  clearV1();
  test('clearV1 deletes user1 and user2 data ', () => {
    expect(userProfileV1(user1.uId, user2.uId)).toStrictEqual(ERROR);
  });

});