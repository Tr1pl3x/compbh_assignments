/*
/////////////////////// channelJoinV1 ////////////////////////

# Description
    Given a channelId of a channel that the authorised user.authUserId can join, 
    adds them to that channel.
    
#Parameters:( authUserId, channelId )

# Return type if no error:{}
    
# Return object {error: 'error'} when any of:
      
    - channelId does not refer to a valid channel

    - the authorised user.authUserId is already a member of the channel

    - channelId refers to a channel that is private, 
    when the authorised user.authUserId is not already a channel 
    member and is not a global owner

    - authUserId is invalid

*/

/*///////////////////////////////////////////////////////////////
Cases to be considered:
    - Error Scenarios
        // empty input is given
        // invalid channelId
        // invalid authUserId
        // authUser already part of channel
        // private channel + (authUser not in channel and not owner)
    - Return Correct Type
        // expect no return if successful
*///////////////////////////////////////////////////////////////

import {authRegisterV1} from './auth.js';
import {channelsCreateV1} from './channels.js';
import {channelJoinV1} from './channel.js';
import {clearV1} from './other.js';


// Reduces repitation assigning consant varaiable.
const ERROR = { error: expect.any(String) };

// Clear the data store before each test is run.
let user, thread
beforeEach(() => {
    clearV1();
    user = authRegisterV1('pyae@gmail.com','passcode','Pyae','Sone');
    thread = channelsCreateV1(user.authUserId, 'AwesomeChannel', false);
});

describe('Error Casses', () => {
  
    test('empty input 1', () => {
        const testVar = channelJoinV1('', thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });

    test('empty input 2', () => {
        const testVar = channelJoinV1(user.authUserId,'');
        expect(testVar).toStrictEqual(ERROR);
    });
    
    test('invalid authUserID', () => {
        const testVar = channelJoinV1(user.authUserId * 999 , thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });

    test('invalid channelID', () => {
        const testVar = channelJoinV1(user.authUserId, thread.channelId * 999);
        expect(testVar).toStrictEqual(ERROR);
    });

    test('user.authUserId already part of requested channel', () => {
        const testVar = channelJoinV1(user.authUserId, thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });
    
    test('Private channel', () => {
        const newUser = authRegisterV1('alien@gmail.com','ufo','alien','invasion');
        const testVar = channelJoinV1(newUser.authUserId, thread.channelId);
        expect(testVar).toStrictEqual(ERROR);
    });
});

describe('Returns Correct Type', () => {

    test('one user.authUserId join', () => {
        let newUser = authRegisterV1('alien@gmail.com','ufo1234','alien','invasion');
        let newThread = channelsCreateV1(user.authUserId,'AlienArmy',true);
        const testVar = channelJoinV1(newUser.authUserId, newThread.channelId);
        expect(testVar).toStrictEqual({});
    });
    test('multiple users join', () => {
        let newUser = authRegisterV1('alien@gmail.com','ufo1234','alien','invasion');
        let newThread = channelsCreateV1(user.authUserId,'AlienArmy',true);
        let newUser1 = authRegisterV1('aliendad@gmail.com','ufo999','alien69','invasion01');
        let newUser2 = authRegisterV1('alienmom@gmail.com','ufo1234','alien','invasion02');
        let newUser3 = authRegisterV1('alienbby@gmail.com','ufo5678','alien2','invasion1');
        channelJoinV1(newUser1.authUserId, newThread.channelId);
        channelJoinV1(newUser2.authUserId, newThread.channelId);
        const testVar = channelJoinV1(newUser3.authUserId, newThread.channelId);
        expect(testVar).toStrictEqual({});
    });
});
