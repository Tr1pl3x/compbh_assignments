import { channelInviteV1 } from './channel.js';
import { channelDetailsV1 } from './channel.js'; // check all Members
import { authRegisterV1 } from './auth.js';
import { channelsCreateV1 } from './channels.js';
import { clearV1 } from './other.js';

const ERROR = { error: expect.any(String) };

let user1; //authUserId
let user2; //uId
let user3;
let channel1; //channelId
let channel2;
beforeEach(() => {
  clearV1();
	user1 = authRegisterV1('test@gmail.com','password', 'Rani', 'Jiang');
	user2 = authRegisterV1('test2@gmail.com','12345pas', 'Hayden', 'Smith');
	user3 = authRegisterV1('test3@gmail.com','1231231234', 'Dean', 'Wunder');
	channel1 = channelsCreateV1(user1.authUserId, 'New Channel', true);
	channel2 = channelsCreateV1(user2.authUserId, 'New channel2lId', true)
});


describe('Error scenario', () => {

	// Return object {error: 'error'} channelId does not refer to a valid channel
  test('invalid channelId', () => {
    expect(channelInviteV1(user1.authUserId, channel1.channelId + 3, user2.authUserId)).toStrictEqual(ERROR);
  });
  // uId does not refer to a valid user
  test('invalid uId', () => {
    expect(channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId + 3)).toStrictEqual(ERROR);
  });
	// authUserId is invalid
	test('invalid authId', () => {
    expect(channelInviteV1(user1.authUserId + 3, channel1.channelId, user2.authUserId)).toStrictEqual(ERROR);
  });
	// authUserId and uId is identical
	test('authId and uId identical', () => {
		expect(channelInviteV1(user1.authUserId, channel1.channelId, user1.authUserId)).toStrictEqual(ERROR);
	});
	// uId refers to a user who is already a member of the channel
	test('uId exists in the channel', () => {
		channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId); 
		// user 2 is assigned to channel1.channelId
    expect(channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId)).toStrictEqual(ERROR);
  });
	// channelId is valid and the authorised user is not a member of the channel
	test('authId does not exist in channel, but channelId valid', () => {
		// user 1 as auth but not member of channel2.channelId, invites a another user
    expect(channelInviteV1(user1.authUserId, channel2.channelId, user3.authUserId)).toStrictEqual(ERROR);
  });
	// Empty authUserId
	test('empty authId', () => {
    expect(channelInviteV1('', channel1.channelId, user2.authUserId)).toStrictEqual(ERROR);
  });
	// Empty channelId
	test('empty channelId', () => {
    expect(channelInviteV1(user1.authUserId, '', user2.authUserId)).toStrictEqual(ERROR);
  });
	// Empty uId
	test('empty uId', () => {
    expect(channelInviteV1(user1.authUserId, channel1.channelId, '')).toStrictEqual(ERROR);
  });
});

describe('Valid scenario', () => {
	test('Valid return value', () => {
    expect(channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId)).toStrictEqual({});
  });
	test('User invited then exists in the channel', () => {
		channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
		const channelDetails = channelDetailsV1(user1.authUserId, channel1.channelId);
		expect(channelDetails.channel.allMembers).toEqual(
			expect.arrayContaining([
				expect.objectContaining(
					{
						uId: user2.authUserId
					}
				)
			])
		);
	});
	test('Two users invited then exists in the channel', () => {
		channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
		channelInviteV1(user1.authUserId, channel1.channelId, user3.authUserId);
		const channelDetails = channelDetailsV1(user1.authUserId, channel1.channelId);
		expect(channelDetails.channel.allMembers).toEqual(
			expect.arrayContaining([
				expect.objectContaining(
					{
						uId: user2.authUserId
					}
				)
			]),
			expect.arrayContaining([
				expect.objectContaining(
					{
						uId: user3.authUserId
					}
				)
			])
		);
	});
	test('Two users invited, the second user invites a third user', () => {
		channelInviteV1(user1.authUserId, channel1.channelId, user2.authUserId);
		channelInviteV1(user2.authUserId, channel1.channelId, user3.authUserId);
		const channelDetails = channelDetailsV1(user1.authUserId, channel1.channelId);
		expect(channelDetails.channel.allMembers).toEqual(
			expect.arrayContaining([
				expect.objectContaining(
					{
						uId: user2.authUserId
					}
				)
			]),
			expect.arrayContaining([
				expect.objectContaining(
					{
						uId: user3.authUserId
					}
				)
			])
		);
	});
})