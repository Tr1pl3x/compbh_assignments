// import our functions from auth.js
import { authRegisterV1, authLoginV1 } from './auth.js';
import { clearV1 } from './other.js';


//import { authLoginV1, authRegisterV1  } from './auth';
import validator from 'validator';

beforeEach(() => {
  clearV1();
});

// Tests for invalid emails 
test('Testing for Invalid emails', () => {
  expect(authRegisterV1('Jonnygmail.com', 'Password', 'John', 'Smith')).toStrictEqual({ error: 'Email invalid' });
  expect(authRegisterV1('', 'Passwrd', 'John', 'Smith')).toStrictEqual({ error: 'Email invalid'});
});

// Tests for email already in use  
describe('Testing for email already in use', () => {
  test('Registering user with already existing email', () => {
    const new_user = authRegisterV1('Jonny@gmail.com', 'Pass1234', 'John', 'Smith')
    expect(authRegisterV1('Jonny@gmail.com', 'Password', 'Johnny', 'Sins')).toStrictEqual({ error: 'Email already in use' });
  });
});

// Tests for invalid passwords 
describe('Testing for Invalid passwords', () => {
  test('Password contains less than 6 characters', () => {
    expect(authRegisterV1('Jonny@gmail.com', 'Pswrd', 'John', 'Smith')).toStrictEqual({ error: 'Password error' });
  });
  test('Password is an empty string', () => {
    expect(authRegisterV1('Jonny@gmail.com', '', 'John', 'Smith')).toStrictEqual({ error: 'Password error' });
  });
});

// Tests for firstName 
describe('Testing for Invalid first names', () => {
  test.each([
    ['', 'First name contains less than 1 character'],
    ['qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmoopd',
    'First name contains more than 50 characters'],
  ])('Invalid first name: %s (%s)', (firstName, testName) => {
    expect(authRegisterV1('Jonny@gmail.com', 'Password', firstName, 'Hash')).toStrictEqual({ error: 'firstName Error' });
  });
});

// Tests for lastName 
describe('Testing for Invalid last names', () => {
  test.each([
    ['', 'Last name contains less than 1 character'],
    ['qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmoopd', 
    'Last name contains more than 50 characters'],
  ])('Invalid last name: %s (%s)', (lastName, testName) => {
    expect(authRegisterV1('Jonny@gmail.com', 'Password', 'John', lastName)).toStrictEqual({ error: 'lastName Error' });
  });
});

// Testing expected correct output (valid parameters)
describe('Testing for valid parameters that produce a non-error output', () => {
  // If we have no errors, the UserId returned will be a number
  test.each([
    ['Password is of expected length (length 9)', 'Jonny@gmail.com', 'Alpha4345', 'John', 'Smith'],
    ['Password is smallest it can be (length 6)', 'Jonny@gmail.com', 'Alpha1', 'John', 'Smith']
  ])('%s', (description, email, password, firstName, lastName) => {
    expect(authRegisterV1(email, password, firstName, lastName)).toHaveProperty('authUserId');
  });
  test.each([
    ['J', 'S'],
    ['John', 'S'],
    ['J', 'Smith'],
  ])('First name and/or last name are of minimum value (%s, %s)', (firstName, lastName) => {
    expect(authRegisterV1('Jonny@gmail.com', 'Alpha4345', firstName, lastName)).toHaveProperty('authUserId');
  });

  test.each([
    ['aqwsedrftgyhujikolpqwertyueuujdfghjksdfjgkfjdksdfj', 'aqwsedrftgyhujikolpqwertyueuujdfghjksdfjgkfjdksdfj']
  ])('First name and last name are of maximum value (%s, %s)', (firstName, lastName) => {
    expect(authRegisterV1('Jonny@gmail.com', 'Alpha4345', firstName, lastName)).toHaveProperty('authUserId');
  });

  test('First name and last name are purely numerical', () => {
    expect(authRegisterV1('Jonny@gmail.com', 'Alpha4345', '12423329873402458', '3089540892340893240')).toHaveProperty('authUserId');
  });
});

// We check if the email is valid
describe('authLoginV1 test', () => {
    test('return type', () => {
        const inpit = authRegisterV1('evan.dang@unsw.edu.au','123456', 'Johnny','Yes')
        const testing = authLoginV1('evan.dang@unsw.edu.au', '123456');
        //const authUserId = testing.authUserId;
        //authLoginV1('evan.dang@unsw.edu.au', '123456')
        expect(testing).toStrictEqual({authUserId: 'evan.dang@unsw.edu.au'});
    });
});
