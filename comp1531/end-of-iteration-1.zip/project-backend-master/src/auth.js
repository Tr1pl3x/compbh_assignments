import { getData, setData } from './dataStore.js';

import validator from 'validator';

export function authRegisterV1 (email, password, nameFirst, nameLast) {
  // getting our data from dataStore.js
  const data = getData();

  // if email is already in data store return error (being used by another user)
  if (data.users.some(user => user.email === email)) {
    return { error: 'Email already in use' };
  } 
  
  // if email is not valid return error (invalid email)
  if (validator.isEmail(email) === false) {
    return { error: 'Email invalid' }; 
  }

  // Checking for invalid first and last name
  const firstNameError = validate_name(nameFirst);
  if (firstNameError) {
    return { error: 'firstName Error' };
  }

  const lastNameError = validate_name(nameLast);
  if (lastNameError) {
    return { error: 'lastName Error' };
  }

const dataStore = {
  users: []
};


  // If password length is less than 6 characters return error
  if (password.length < 6) {
    return { error: 'Password error' };
  }
  
  // If the arguments are valid, format the handle and return the userId

  // creating a unique user Id
  const authUserId = Math.floor(Math.random() * 1000000000);

  // convert both first and last name to lowercase and remove all alphanumeric characters
  let handle = (nameFirst + nameLast).toLowerCase().replace(/[^a-z]/g, '');

  // if the length is greater than 20, reduce to 20
  handle = handle.length > 20 ? handle.slice(0, 20) : handle;
  
  // check if the handle already exists
  // by using the Array.find() method to check if a handle already exists in the 
  // data.users array
  const userExists = data.users.find(user => user.handle === handle);
  if (userExists) {
    // handle already exists, increment the number on the end of the handle string
    const lastElement = handle.length - 1;
    if (typeof handle[lastElement] === 'number') {
      handle[lastElement]++;
    } else {
      handle.push(0);
    }
  }
  // Push our new client object onto data.users and set it on the datastore
  data.users.push({
    uId: authUserId,
    nameFirst: nameFirst,
    nameLast: nameLast,
    email: email,
    password: password,
    handleStr: handle,
    channelsJoined: [],
  })
  setData(data);
  return {
    authUserId
  };
}

// function to validate a name (first or last)
// Used in authRegisterV1
function validate_name(name) {
  if (name.length > 50 || name.length < 1) {
    return { error: 'error'};
  }
}

export function authLoginV1(email, password) {
  
  const data = getData();
  const user = data.users.find(user => user.email === email);
  
  if (!user) {
    return { error: "email error" };
  } else if (user.password !== password) {
    return { error: 'password error' };
  } else {
    return { 
      authUserId: user.email 
    };
  }

}
    
  
  

