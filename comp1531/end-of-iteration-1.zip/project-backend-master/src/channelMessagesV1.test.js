import { channelMessagesV1 } from './channel.js';
import { authRegisterV1 } from './auth.js';
import { channelsCreateV1 } from './channels.js';
import { clearV1 } from './other.js';

const ERROR = { error: expect.any(String) };
let user1; //authUserId
let user2; //uId
let channel1; //channelId
beforeEach(() => {
  clearV1();
	user1 = authRegisterV1('test@gmail.com','password', 'Rani', 'Jiang')
	user2 = authRegisterV1('test2@gmail.com','123456', 'Hayden', 'Smith')
	channel1 = channelsCreateV1(user1.authUserId, 'New Channel', true)
});
describe('Error scenario', () => {
	// Return object {error: 'error'} channelId does not refer to a valid channel
  test('invalid channelId', () => {
		expect(channelMessagesV1(user1.authUserId, channel1.channelId + 1, 0)).toStrictEqual(ERROR);
  });
	// authId is invalid
	test('invalid authId', () => {
    expect(channelMessagesV1(user1.authUserId + 1, channel1.channelId, 0)).toStrictEqual(ERROR);
  });
	// channelId is valid and the authorised user is not a member of the channel
	test('authId does not exist in channel, but channelId valid', () => {
		//User 2 is auth of channel2
		const channel2 = channelsCreateV1(user2.authUserId, 'New Channel2', true) ;
		expect(channelMessagesV1(user1.authUserId, channel2.channelId, 0)).toStrictEqual(ERROR);
	});
	// Start is a negative value, returns error
	test('Start is negative', () => {
		expect(channelMessagesV1(user1.authUserId, channel1.channelId, -1)).toStrictEqual(ERROR);
	});
	// Start greater than end
	test('Start greater than end', () => {
    expect(channelMessagesV1(user1.authUserId, channel1.channelId, 51)).toStrictEqual(ERROR);
  });
	// Assumption start === end, returns undefined, therefore return error
	test('Start equal to end', () => {
    expect(channelMessagesV1(user1.authUserId, channel1.channelId, 50)).toStrictEqual(ERROR);
  });
	// Empty uId
	test('empty authId', () => {
    expect(channelMessagesV1('', channel1.channelId, 0)).toStrictEqual(ERROR);
  });
	// Empty channelId
	test('empty channelId', () => {
    expect(channelMessagesV1(user1.authUserId, '', 0)).toStrictEqual(ERROR);
  });
	// Empty start
	test('empty start', () => {
    expect(channelMessagesV1(user1.authUserId, channel1.channelId, '')).toStrictEqual(ERROR);
  });
});

describe('Valid scenario', () => {
	test('New channel, empty message', () => {
    expect(channelMessagesV1(user1.authUserId, channel1.channelId, 0)).toStrictEqual(
			expect.objectContaining(
			{
				messages: [],
				start: 0,
				end: 50,
			}
		));
  });
	// Future scenario :
	// Test message added using messagesCreateV1
	// If message is exactly 50
	// If message is below 50
	// if Message is between 50 and 100
	// If message is above 100
	// if message is above 200
});