import { getData, setData } from './dataStore.js';
/**
 * channelInviteV1
 * Invites a user with ID uId to join a channel with ID channelId. O
 * nce invited, the user is added to the channel immediately. 
 * In both public and private channels, all members are able to invite users.
 * 
 * @param {number} authUserId - Id of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @param {number} uId - Id of user to invite.
 * @returns {{error: string}} on error
 * @returns {{}} - No return value if successful.
 */

function channelInviteV1(authUserId, channelId, uId) {
	let data = getData();
	// authUserId is invalid
	if ((!(data.users).find(user => user.uId === authUserId)) || authUserId === undefined ||
	authUserId === '') {
    return {
      error: 'Invalid authId'
		}
	// channelId does not refer to a valid channel
  } else if ((!(data.channels).find(channel => channel.channelId === channelId)) || 
	channelId === undefined || channelId === '') {
		return {
			error: 'Invalid channelId'
		}
	// uId does not refer to a valid user
	} else if ((!(data.users).find(user => user.uId === uId)) || uId === undefined ||
	uId === '') {
		return {
			error: 'Invalid uId'
		}
	// If authUserId is identical to uId
	} else if (authUserId === uId)  {
		return {
			error: 'Enter another user uId'
		}
	}
	
	for (const channel of data.channels) {
		if (channel.channelId === channelId) {
			// If uId refers to a user already in the channel
			if ((channel.allMembers).find(member => member.uId === uId)) {
				return {
					error: 'uId already exists in the channel'
				}
			}
			// If authId is not a member of channel
			if (!(channel.allMembers).find(member => member.uId === authUserId)) {
				return {
					error: 'authId is not member of channel'
				}
			}
			// Retrieve the member to be added
			let newUser = data.users.find(user => user.uId === uId)
			// Add user details into the array allMembers of channel
			channel.allMembers.push(
				{
					uId: newUser.uId,
					email: newUser.email,
					nameFirst: newUser.nameFirst,
					nameLast: newUser.nameLast,
					handleStr: newUser.handleStr
				}
			)
			setData(data);
			return {
      }
		}
	}
}
/**
 * channelDetailsV1
 * Given a channel with ID channelId that the authorised user is a member of,
 * provides basic details about the channel.
 * 
 * @param {number} authUserId - Id of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @returns {{error: string}} on error
 * @returns {{
* 				name: string, 
* 				isPublic: boolean, 
* 				Array{ownerMembers}, 
* 				Array{allMembers} 
* }} - Returns name of owner, status of channel, array of owner members 
* and followed by an array of all members if successful. 
*/
function channelDetailsV1(authUserId, channelId ) {

   // if empty parameter is received
   if (authUserId === '' || channelId === '') return {error: 'Empty Input is Given'};
   
   let data = getData();
   // if given authUserId is invalid
   const authUser = data.users.find(users=>users.uId === authUserId);
   if (!authUser) return {error: 'ID does not exist.'};

   // if given channelId is invalid
   const thread = data.channels.find(thread=>thread.channelId === channelId);
   if (!thread) return {error: 'Channel does not exist'};

   // if authUserId have no access to requested channel
   // [might change find to include because accessUser will not be used if found ]
   const accessUser = thread.admin.find(accessUser => accessUser.uId === authUser.uId);
   if (!accessUser) return {error: 'ID does not have access to requested channel'};

   // returns data successfully
   const channel = {
	   name: thread.name,
	   isPublic: thread.isPublic,
	   admin: thread.admin,
	   allMembers: thread.allMembers
	}
	return{channel};
}

/**
 * channelJoinV1
 * Given a channelId of a channel that the authorised user can join, 
 * adds them to that channel.
 * 
 * @param {number} authUserId - Id of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @returns {{error: string}} on error
 * @returns {{}} - No return value if successful.
 */

function channelJoinV1(authUserId, channelId ) {

	// if empty inputs are given
	if ( authUserId === '' || channelId === '') return {error:'Empty Input is Given'};

	let data = getData();
	// if given authUserId is invalid
	const authUser = data.users.find(user => user.uId === authUserId);
	if (!authUser) return {error: 'ID does not exist.'};
	
	// if given channelId is invalid
	const thread = data.channels.find(thread=>thread.channelId === channelId);
	if (!thread) return {error: 'Channel does not exist'};

	// if the requested channel is private
	if ( thread.isPublic === false) return {error:'Failed. Requested Channel is Private.'};

	// if authUserId is already in the requested channel
	const check = thread.allMembers.find(check => check.uId === authUser.uId);
	if (check) return {error:'User already exists in the channel'};

	// adding new member to the requested channel and return
	const newMember = {
		uid: authUser.uid,
		email: authUser.email,
		nameFirst:authUser.nameFirst,
		nameLast:authUser.nameLast,
		handleStr: authUser.handleStr
	}

	// Iterates to find the requested channel,
	// then push the new member to the all members array of the found channel
	for (const curr of data.channels){ 
		if (curr.channelId === channelId) {
			curr.allMembers.push(newMember);
			setData(data);
		}
	}
	return {};
}
/**
 * channelMessagesV1
 * Given a channel with ID channelId that the authorised user is a member of,
 * returns up to 50 messages between index "start" and "start + 50". 
 * Message with index 0 (i.e. the first element in the returned array of messages) 
 * is the most recent message in the channel. 
 * 
 * This function returns a new index "end". 
 * If there are more messages to return after this function call,
 * "end" equals "start + 50". 
 * If this function has returned the least recent messages in the channel,
 * "end" equals -1 to indicate that there are no more messages to load after this return.
 * 
 * @param {number} authUserId - Id of authorized user
 * @param {number} channelId - Id of channel to invite user to.
 * @param {number} start - starting index of messages
 * @returns {{error: string}} on error
 * @returns {{	
 * 		Array<{message}>
 * 		start: number,
 * 		end: number
 * }} - Returns an array of message followed by start and end index,
 * end index is -1 if there are no more messages to load.
 */
function channelMessagesV1(authUserId, channelId, start) {
	let data = getData();
	let messages = [];
	data.start = start;
	let end = data.start + 50;
	if (!(data.channels.find(channel => channel.channelId === channelId)) ||
	channelId === undefined || channelId.channelId === '') {
		return {
			error: 'Invalid channelId'
		}
	}
	const currChannel = data.channels.find(channel => channel.channelId === channelId);
	if (authUserId === undefined || authUserId.authUserId === '') {
		return {
			error: 'Invalid authId'
		}
	} if (!(currChannel.allMembers.find(member => member.uId === authUserId))) { 
		return {
			error: 'authId is not member of channel'
		}	
	}  if (start < 0) {
		return {
			error: 'Start must be positive number'
		}
	// If start index is 0 and no message exists, return the messages array and indexes instead of error
	} if ((start === 0) && ((currChannel.allMessages).length === 0)) {
		return {
			messages, 
			start,
			end
		}
	} if (start >= (currChannel.allMessages).length) {
		return {
			error: 'Start index exceeds the number of messages in the channel'
		}
	} if (start === '' || start === undefined)   {
		return {
			error: 'Enter start index'
		}
	}
	// retrieves the value of end instead of reference to end
	let tempStart = start.valueOf();
	let tempEnd = end.valueOf();
	// If authId is not a member of channel	
	for (const channel of data.channels) {
		if (channel.channelId === channelId) {
			if (!(channel.allMembers).find(member => member.uId === authUserId)) {
				return {
					error: 'authId is not member of channel'
				}
			}
			for (let i = tempStart; i < tempEnd; i++) { 
				messages[i] = channel.allMessages[i].message
			}
			
			if (start < (channel.allMessages).length < end) {
				data.end = -1;
			}
			setData(data);
			messages.reverse()
			return {
				messages,
				start,
				end
			}
		}
	}
}

export {channelInviteV1, channelDetailsV1, channelJoinV1, channelMessagesV1};
