import { userProfileV1 } from './users.js'
import { authRegisterV1 } from './auth.js'
import { clearV1 } from './other.js'

const ERROR = { error: expect.any(String) };

let user1; //authUserId
let user2; //uId
beforeEach(() => {
  clearV1();
	user1 = authRegisterV1('test@gmail.com','password', 'Rani', 'Jiang');
  user2 = authRegisterV1('test2@gmail.com','12345pas', 'Hayden', 'Smith');
});

describe('userProfileV1 error scenario', () => {
  test('invalid authId', () => {
    expect(userProfileV1(user1.authUserId + 3 , user2.authUserId)).toStrictEqual(ERROR);
  });
	test('invalid uId', () => {
    expect(userProfileV1(user1.authUserId , user2.authUserId + 3)).toStrictEqual(ERROR);
  });
	test('invalid authId and uId', () => {
    expect(userProfileV1(user1.authUserId + 3, user2.authUserId + 3)).toStrictEqual(ERROR);
  });
	test('empty authId', () => {
    expect(userProfileV1('', user2.authUserId )).toStrictEqual(ERROR);
  });
	test('empty uId', () => {
    expect(userProfileV1(user1.authUserId , '')).toStrictEqual(ERROR);
  });
});

describe('userProfileV1 display valid user data', () => {
  test('check uId data', () => {
    let user = userProfileV1(user1.authUserId, user2.authUserId)
    expect(user).toStrictEqual({
			uId: user.uId,
      firstName: user.firstName,
      lastName: user.lastName,
			email: user.email,
      handleStr: user.handleStr,
    });
  });
	test('check authId data', () => {
    let user = userProfileV1(user1.authUserId, user1.authUserId)
    expect(user).toStrictEqual({
			uId: user.uId,
      firstName: user.firstName,
      lastName: user.lastName,
			email: user.email,
      handleStr: user.handleStr,
		});
  });
});