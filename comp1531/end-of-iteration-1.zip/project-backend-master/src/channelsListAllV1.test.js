import { channelsListAllV1, channelsCreateV1 } from './channels';
import { authRegisterV1 } from './auth.js';
import { clearV1 } from "./other.js"

describe('channelsListAllV1', () => {
    test('returns an array of channel  for valid authUserId', () => {
      //const authUserId = 'validUserId';
      const input = authRegisterV1('evan.dang@unsw.edu.au','123456', 'Johnny','Yes')
      const channel_creating = channelsCreateV1(input.authUserId, 'Valid channel name', false);
      const result = channelsListAllV1(input.authUserId);
//console.log(result)
      expect(result).toStrictEqual(  
          { 
            channels: [{
            channelId: channel_creating.channelId, 
            name: 'Valid channel name',
          }]
          }
        
      );
      clearV1();
    });


    
    
  

    describe('Return value for variosu function ', () => {
  test('channelsListAllV1 testing', () => {

    let inputfirst = authRegisterV1('evan.dang@unsw.edu.au','123456', 'Johnny','Yes');
    let firsttest = channelsCreateV1(inputfirst.authUserId, 'channelname_A', true);
    let secondtest = channelsCreateV1(inputfirst.authUserId, 'channelname_B', false);
    let thirdtests = channelsCreateV1(inputfirst.authUserId, 'channelname_C', true);
    expect(channelsListAllV1(inputfirst.authUserId)).toStrictEqual({
        channels: [
          {
            channelId: firsttest.channelId,
            name: 'channelname_A',
          },
          {
            channelId: secondtest.channelId,
            name: 'channelname_B',
          },
          {
            channelId:thirdtests.channelId,
            name: 'channelname_C',
          },
        ]
    });
  });
  clearV1();
});

  });