import { getData, setData } from "./dataStore.js"
import { authRegisterV1 } from "./auth.js"


/**
  * <Creates a new channel with the given name, that is either a public or private channel. 
  *  The user who created it automatically joins the channel.>
  * 
  * @param {authUserId} - User Id of member/admin
  * @param {name}       - name of the channel being created
  * @param {isPublic}   - Booleen value for if the channle is public
  * ...
  * 
  * @returns {channelId} - returns the Id of the created channel
*/
function channelsCreateV1 (authUserId, name, isPublic) {
  if (name.length < 1 || name.length > 20) {
    // returns error if the length of name is less than 1 or more than 20 characters
    return { error: 'error' };
  }
  // generating a unique channelId
  const channelId = Math.floor(Math.random() * 1000000000);
  let data = getData();
  // checking if the user is valid
  const person = data.users.find(user => user.uId === authUserId);

  let validUser = false;
  
  for (const person of data.users) {
    if (person.uId === authUserId) {
      // if the user is valid push the channelId into their channelsJoined array
      //person.channelsJoined.push(channelId);
      validUser = true;
      break;
    }
  }
  // the user is not valid
  if (validUser === false) {
    return { error: 'error' };
  }
  const user = data.users.find(user => user.uId === authUserId);

  let tempMember = {
    uId: user.uId,
    email: user.email,
    nameFirst: user.nameFirst,
    nameLast: user.nameLast,
    handleStr: user.handleStr,
    channelsJoined: user.channelsJoined
  }
  // creating new channel to push
  let newChannel = {
    channelId: channelId,
    name: name,
    isPublic: isPublic,
    admin: [],
    allMembers: [],
    allMessages: []
  }
  newChannel.allMembers.push(tempMember);
  newChannel.admin.push(tempMember);
  user.channelsJoined.push(newChannel);
  // pushing new channel and returning
  data.channels.push(newChannel);
  setData(data);
  
  return { channelId };
}
/**
  * <Provides an array of all channels (and their associated details) 
  * that the authorised user is part of.>
  * 
  * @param { authUserId } name - User Id of the student/admin
  * ...
  * @returns { channels } - array of the channels and their details
*/
function channelsListV1 ( authUserId ) {
  let data = getData();
  // check if authUserId is valid
  const person = data.users.find(person => person.uId === authUserId);
  if (!person) {
    return { error: "error" };
  }

  // channelNames is an array of the channels that the user is in
  const channelNames = person.channelsJoined;
  // console.log('this is the person: ', person);
  let channels = [];

  // going through the array of channel names
  for (let Id of channelNames) {
    for (let potentialChannel of data.channels) {
      // finding channel
      if (potentialChannel.channelId === Id.channelId) {
        // found the channel, pushing it into channels[]
        channels.push(potentialChannel);
        // console.log('this is the channelId that i am pushing: ', potentialChannel);
      }
    }
  }
  // console.log(channels);
  return {channels}
}

//const person = authRegisterV1('csgo@gmail.com', 'PASSworD12', 'Sam', 'Jackson');
//channelsCreateV1(person, 'Valid channel name', false);
//channelsListV1(person);

function channelsListAllV1(authUserId) {
  let data = getData();

  // check if authUserId is valid
  const iDchecker = data.users.find(iDchecker => iDchecker.uId === authUserId);
  //console.log(authUserId)
  if (!iDchecker) {
    return { error: "authUserId" };
  }
    let result = [];
    for (let channel of data.channels) {
      let create_chan = {};

      create_chan['channelId'] = channel.channelId;
      create_chan['name'] = channel.name;
      result.push(create_chan);
    }
    return {
      channels: result
    };
  return { channels };
}
export {channelsCreateV1, channelsListAllV1, channelsListV1} 
