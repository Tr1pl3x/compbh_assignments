import { getData } from './dataStore.js';
/**
  * userProfileV1
  * For a valid user, returns information about their user ID, email, first name, last name, and handle
  * 
  * @param {number} authUserId - Id of authorized user 
  * @param {number} uId - Id of user whose profile to be retrieved
  * @returns {
  *   {
  *     user: {
  *       uId: number, 
  *       firstName: string, 
  *       lastName: string, 
  *       handleStr: string
  *     }
  *   }
  * } - Object containing uId, email, nameFirst, nameLast, handleStr
  * @returns {{error: string}} on error 
  * description of condition for return
*/

// For a valid user, returns information about their user ID, email, first name, last name, and handle
export function userProfileV1(authUserId, uId) {
	let data = getData();
	if ((!(data.users).find(user => user.uId === authUserId)) || authUserId === undefined ||
	authUserId === '') {
    return {
      error: 'invalid authUserId'
    }
  } else if ((!(data.users).find(user => user.uId === uId)) || uId === undefined ||
	uId === '') {
    return {
      error: 'invalid uId'
    }
  }
	for (const currUser of data.users) {
    if (currUser.uId === uId) {
      let user = {
				uId: currUser.uId,
				email: currUser.email,
				firstName: currUser.firstName,
				lastName: currUser.lastName,
				handleStr: currUser.handleStr,
			}
			return user
    }
  }
}
