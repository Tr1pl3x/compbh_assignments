import { makeStyles, useTheme } from '@material-ui/core/styles';
import React from 'react';
import { drawerWidth} from '../../utils/constants';
import { Paper } from "@material-ui/core";


const useStyles = makeStyles(theme => ({
  body: {
    [theme.breakpoints.up('sm')]: {
      width: `calc(100% - ${drawerWidth}px)`,
    },
    padding: 20,
    backgroundColor: theme.palette.type === 'dark' ? theme.palette.background.default : 'inherit', 
    height: '100vh', // for smaller screens
    overflow: 'auto', // enable scrolling if content overflows
  },
  toolbar: theme.mixins.toolbar,
}));

function Body({ children }) {
  const classes = useStyles();
  const theme = useTheme();

  return (
   // <Paper style={{backgroundColor: theme.palette.type === 'dark' ? theme.palette.background.default : 'inherit', height: '100vh', width: '100vw'}}>
    <div className={classes.body}>
      {/* Padding */}
      <div className={classes.toolbar} />
      {children}
    </div>
   // </Paper>
  );
}

export default Body;
