import React, { useContext } from 'react';
import { Switch } from '@material-ui/core';
import ThemeContext from './themeContext';
import Brightness4Icon from '@material-ui/icons/Brightness4';

export default function DarkModeToggle() {
  const { darkMode, toggleDarkMode } = useContext(ThemeContext);

  const handleDarkModeToggle = (event) => {
    toggleDarkMode();
  };

  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      <Brightness4Icon style={{ marginRight: "1px" }} />
      <Switch checked={darkMode} onChange={handleDarkModeToggle} />
    </div>
  );
  // return (
  //   <>
  //     <Brightness4Icon style={{ verticalAlign: 'middle' }} />
  //     <Switch checked={darkMode} onChange={handleDarkModeToggle} />
  //   </>
  // );
}
