import { red } from '@material-ui/core/colors';
import { createMuiTheme } from '@material-ui/core/styles';

// A custom theme for this app
const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#556cd6',
    },
    secondary: {
      main: '#19857b',
    },
    error: {
      main: red.A400,
    },
    background: {
      default: '#fff',
    },
  },
});

// Dark mode theme
const darkTheme = createMuiTheme({
  palette: {
    primary: {
      main: "#25272b"
    },
    secondary: {
      main: "#00e5ff"
    },
    error: {
      main: red.A400
    },
    background: {
      default: "#35393e"
    },
    type: "dark"
  }
});

export { theme, darkTheme };
