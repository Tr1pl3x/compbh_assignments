
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// /* //////////////////// dmListV2 ///////////////////////

// // # Passing Parameters:( token: number )

// // # Return type if no error: { dms: dm[]}

// // # Cases to be considered:
// //     -Error Scenarios
// //         // 403 ERROR:  invalid token
// //     -Return Correct Type
// // /////////////////////////////////////////////////// */

// // import functions
// import {
//   authRegisterV3,
//   dmCreateV2,
//   dmListV2,
//   clearV2,
// } from './testHelpers';

// // import interface
// import {
//   AuthUserId,
//   DmID,
// } from './interface';

// let mainUser: AuthUserId;
// let user1: AuthUserId;
// let user2: AuthUserId;
// /* eslint-disable */
// // these are for test cases purpose only.
// let dm1: DmID;
// let dm2: DmID;
// let dm3: DmID;
// /* eslint-enable */

// beforeEach(() => {
//   clearV2();
//   mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
//   user2 = authRegisterV3('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
//   /* eslint-disable */
//   // these are for test cases purpose only.
//   dm1 = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
//   dm2 = dmCreateV2(user2.token, [mainUser.authUserId])as DmID;
//   dm3 = dmCreateV2(mainUser.token, [])as DmID;
//   /* eslint-enable */
// });

// describe('Error Casses', () => {
//   test('Invalid token', () => {
//     const testVar = dmListV2(mainUser.token + 'abg');
//     expect(testVar).toStrictEqual(403);
//   });
// });

// describe('Returns Correct Type', () => {
//   test('passing valid token', () => {
//     const testVar = dmListV2(mainUser.token);
//     expect(testVar).toStrictEqual({
//       dms: expect.arrayContaining([
//         expect.objectContaining({
//           dmId: expect.any(Number),
//           name: expect.any(String),
//         })
//       ])
//     });
//   });
// });
