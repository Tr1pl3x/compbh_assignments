
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
// import { userProfileV3, authRegisterV3, clearV2 } from './testHelpers';
// import type { AuthUserId } from './interface';

// beforeEach(() => {
//   clearV2();
// });
// afterEach(() => {
//   clearV2();
// });

// describe('clearV2 valid scenario', () => {
//   test('clearV2 returns empty dictionary', () => {
//     expect(clearV2()).toStrictEqual({});
//   });
// });

// describe('clearV2 data check', () => {
//   const user1 = authRegisterV3('email@gmail.com', 'password', 'Hayden', 'Smith') as AuthUserId;
//   const user2 = authRegisterV3('test@gmail.com', '12345', 'Dean', 'Wunder') as AuthUserId;
//   clearV2();
//   test('clearV2 deletes user1 and user2 data ', () => {
//     expect(userProfileV3(user1.token, user2.authUserId)).toStrictEqual(403);
//   });
// });
