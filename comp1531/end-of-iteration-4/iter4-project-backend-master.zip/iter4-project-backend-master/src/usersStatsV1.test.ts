/* users/stats/v1

# Passing Parameters:( token: string)

# Return type if no error: { workspaceStats }

# (OUTPUT)
    {
        workspaceStats:{
            channelsExist: Array<{numChannelsExist: number, timeStamp: number}>,
            dmsExist: Array<{numDmsExist: number, timeStamp: number}>,
            messagesExist: Array<{numMessagesSent: number, timeStamp: number}>,
            utilizationRate : number,
        }
    }

# utilizationRate =
(
    numUsersWhoHaveJoinedAtLeastOneChannelOrDm
    /
    number of users
);

# Cases to be considered:
    -Error Scenarios
        // 403 ERROR:   Invalid token
    -Return Correct Type (x2)
        - successful stats return

///////////////////////////////////////////////////// */

// import functions
import {
  authRegisterV3,
  channelsCreateV3,
  dmCreateV2,
  messageSendV2,
  messageSenddmV2,
  usersStatsV1,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  ChannelId,
  DmID,
  MessageReturn,
} from './interface';

let mainUser: AuthUserId;
beforeEach(() => {
  clearV2();
  mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
});

describe('Error Scenario', () => {
  test('Invalid Token', () => {
    const testVar = usersStatsV1(mainUser.token + 'abg');
    expect(testVar).toStrictEqual(403);
  });
});

describe('Successful Cases', () => {
  test('Correct return type when a new user registered.', () => {
    const testVar = usersStatsV1(mainUser.token);
    expect(testVar).toStrictEqual({
      workspaceStats: {
        channelsExist: [
          {
            numChannelsExist: 0,
            timeStamp: expect.any(Number)
          }
        ],
        dmsExist: [
          {
            numDmsExist: 0,
            timeStamp: expect.any(Number)
          }
        ],
        messagesExist: [
          {
            numMessagesExist: 0,
            timeStamp: expect.any(Number)
          }
        ],
        utilizationRate: 0
      }
    });
  });

  test('created one channel, one dm, one msg in channel, one in dm', () => {
    /* eslint-disable */
      const channel = channelsCreateV3(mainUser.token, 'MyChannel',) as ChannelId;
      const dm = dmCreateV2(mainUser.token,[]) as DmID;
      const msg1 = messageSendV2(mainUser.token, channel.channelId, 'Hello') as MessageReturn;
      const msg2 = messageSenddmV2(mainUser.token, dm.dmId, 'World') as MessageReturn
      /* eslint-enable */

    const testVar = usersStatsV1(mainUser.token);
    expect(testVar).toStrictEqual({
      workspaceStats: {
        channelsExist: expect.arrayContaining(
          [expect.objectContaining(
            {
              numChannelsExist: expect.any(Number),
              timeStamp: expect.any(Number),
            }
          )]
        ),
        dmsExist: expect.arrayContaining(
          [
            {
              numDmsExist: expect.any(Number),
              timeStamp: expect.any(Number),
            }
          ]
        ),
        messagesExist: expect.arrayContaining(
          [expect.objectContaining(
            {
              numMessagesExist: expect.any(Number),
              timeStamp: expect.any(Number),
            }
          )]
        ),
        utilizationRate: 1,
      }
    });
  });
});
