
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, clearV2, usersAllV2, userProfileV3 } from './testHelpers';
// import type { UserProfile, AuthUserId, UsersReturn } from './interface';

// let user1: AuthUserId;
// let user2: AuthUserId;
// let user3: AuthUserId;
// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('Johnny@gmail.com', 'Password', 'Johre', 'Smith') as AuthUserId;
//   user2 = authRegisterV3('Johnny1@gmail.com', 'Password', 'John', 'Smith') as AuthUserId;
//   user3 = authRegisterV3('Johnny2@gmail.com', 'Passaword', 'John', 'Smith') as AuthUserId;
// });

// // Tests for invalid tokens
// describe('Tests for an invalid token', () => {
//   test('Testing for empty string', () => {
//     const result = usersAllV2('');
//     expect(result).toStrictEqual(403);
//   });

//   test('Testing for token not associated with a user', () => {
//     const result = usersAllV2(user1.token + 3) as UsersReturn;
//     expect(result).toStrictEqual(403);
//   });
// });

// // testing for valid output
// test('Testing for valid token associated with a user', () => {
//   const result = usersAllV2(user1.token) as UsersReturn;
//   const UserProfile1 = userProfileV3(user1.token, user1.authUserId) as UserProfile;
//   const UserProfile2 = userProfileV3(user1.token, user2.authUserId) as UserProfile;
//   const UserProfile3 = userProfileV3(user1.token, user3.authUserId) as UserProfile;
//   expect(result).toStrictEqual(
//     expect.objectContaining({
//       users:
//       expect.arrayContaining([
//         expect.objectContaining({
//           uId: UserProfile1.user.uId,
//           email: UserProfile1.user.email,
//           nameFirst: UserProfile1.user.nameFirst,
//           nameLast: UserProfile1.user.nameLast,
//           handleStr: UserProfile1.user.handleStr
//         }),
//         expect.objectContaining({
//           uId: UserProfile2.user.uId,
//           email: UserProfile2.user.email,
//           nameFirst: UserProfile2.user.nameFirst,
//           nameLast: UserProfile2.user.nameLast,
//           handleStr: UserProfile2.user.handleStr
//         }),
//         expect.objectContaining({
//           uId: UserProfile3.user.uId,
//           email: UserProfile3.user.email,
//           nameFirst: UserProfile3.user.nameFirst,
//           nameLast: UserProfile3.user.nameLast,
//           handleStr: UserProfile3.user.handleStr
//         })
//       ])
//     })
//   );
// });
