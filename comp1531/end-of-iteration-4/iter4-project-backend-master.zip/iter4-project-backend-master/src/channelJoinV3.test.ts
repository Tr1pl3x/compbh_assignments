
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// /* /////////////////////// channelJoinV3 ////////////////////////

// // # Parameters:( token, channelId )

// // # Return type if no error:{}

// // # Cases to be considered:
// //     - Error Scenarios
// //         // 403 ERROR:  invalid token
// //         // 400 ERROR:  invalid channel
// //         // 400 ERROR:  user of the token already part of channel
// //         // 403 ERROR:  private channel + (authUser not in channel and not owner)
// //     - Return Correct Type
// // // *//// ///////////////////////////////////////////////////////////

// import {
//   authRegisterV3,
//   channelsCreateV3,
//   channelJoinV3,
//   clearV2,
// } from './testHelpers';

// // import interface
// import {
//   AuthUserId,
//   ChannelId,
// } from './interface';

// let user: AuthUserId;
// let newUser: AuthUserId;
// let thread: ChannelId;
// let Pthread: ChannelId;
// let newThread: ChannelId;
// beforeEach(() => {
//   clearV2();
//   user = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   newUser = authRegisterV3('alien@gmail.com', 'passcoed', 'alien', 'invasion') as AuthUserId;
//   thread = channelsCreateV3(user.token, 'AwesomeChannel', true) as ChannelId;
//   Pthread = channelsCreateV3(user.token, 'PChannel', false) as ChannelId;
// });

// describe('Error Casses', () => {
//   test('invalid token', () => {
//     const testVar = channelJoinV3(user.token + 'abg', thread.channelId);
//     expect(testVar).toStrictEqual(403);
//   });

//   test('invalid channel', () => {
//     const testVar = channelJoinV3(user.token, thread.channelId * 999);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('User already in channel', () => {
//     const testVar = channelJoinV3(user.token, thread.channelId);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Private channel: Request Denied', () => {
//     const testVar = channelJoinV3(newUser.token, Pthread.channelId);
//     expect(testVar).toStrictEqual(403);
//   });
// });

// describe('Returns Correct Type', () => {
//   test('successful join attempt', () => {
//     newThread = channelsCreateV3(user.token, 'AlienArmy', true) as ChannelId;
//     const testVar = channelJoinV3(newUser.token, newThread.channelId);
//     expect(testVar).toStrictEqual({});
//   });
// });
