import express, { json, Request, Response } from 'express';
import { echo } from './echo';
import morgan from 'morgan';
import config from './config.json';
import cors from 'cors';
import errorHandler from 'middleware-http-errors';
import fs from 'fs';
import { getData } from './dataStore';
import { notificationsGetV1 } from './notifications';
import {
  userStatsV1,
  usersStatsV1,
} from './analytics';
import {
  authRegisterV1,
  authLogOutV1,
  authLoginV1,
  authPasswordRequestV1,
  authPasswordResetV1,
} from './auth';

import {
  channelsCreateV1,
  channelsListV1,
  channelsListAllV1
} from './channels';

import {
  channelDetailsV1,
  channelInviteV1,
  channelMessagesV1,
  channelLeaveV1,
  channelAddOwnerV1,
  channelRemoveOwnerV1,
  channelJoinV1,
} from './channel';
import {
  dmCreateV1,
  dmDetailsV1,
  dmLeaveV1,
  dmListV1,
  dmRemoveV1,
  dmMessagesV1
} from './dm';
import {
  messageSendV1,
  messageRemoveV1,
  messageEditV1,
  messageSenddmV1,
  messageSendlaterV1,
  messageSendLaterDmV1,
  messagePinV1,
  messageUnpinV1,
  messageReactV1,
  messageUnreactV1,
  messageShareV1
} from './message';
import {
  standupStartV1,
  standupActiveV1,
  standupSendV1,
} from './standup';
import {
  clearV1
} from './other';
import {
  userProfileSethandleV1,
  userProfileSetemailV1,
  userProfileSetnameV1,
  usersAllV1,
  userProfileV1,
  userProfileUploadPhotov1
} from './user';
import { searchV1 } from './search';

let data = getData();
// Set up web app
const app = express();
// Use middleware that allows us to access the JSON body of requests
app.use(json());
// Use middleware that allows for access from other domains
app.use(cors());
// for logging errors (print to terminal)
app.use(morgan('dev'));

const PORT: number = parseInt(process.env.PORT || config.port);
const HOST: string = process.env.IP || 'localhost';

const initializeDatabase = () => {
  if (!fs.existsSync('./database.json')) {
    const defaultData = data;
    fs.writeFileSync('./database.json', JSON.stringify(defaultData));
  }
};

initializeDatabase();

if (fs.existsSync('./database.json')) {
  const databaseStr = fs.readFileSync('./database.json');
  data = JSON.parse(String(databaseStr));
}

// start server
const server = app.listen(PORT, HOST, () => {
  // DO NOT CHANGE THIS LINE
  console.log(`⚡️ Server started on port ${PORT} at ${HOST}`);
});

// For coverage, handle Ctrl+C gracefully
process.on('SIGINT', () => {
  server.close(() => console.log('Shutting down server gracefully.'));
});

const save = () => {
  const dataString = JSON.stringify(data);
  fs.writeFileSync('./database.json', dataString, { flag: 'w' });
};
// Example get request
app.get('/echo', (req: Request, res: Response, next) => {
  const data = req.query.echo as string;
  return res.json(echo(data));
});

// route for clearV1
app.delete('/clear/v1', (req, res) => {
  const result = clearV1();
  save();
  res.json(result);
});

/// /////////////// AUTH ////////////////////

// route for auth/passwordreset/request/v1
app.post('/auth/passwordreset/request/v1', (req, res) => {
  const email = req.query.email as string;
  save();
  res.json(authPasswordRequestV1(email));
});

// route for auth/password/reset/v1
app.post('/auth/passwordreset/reset/v1', (req, res) => {
  const resetCode = req.query.resetCode as string;
  const newPassword = req.query.newPassword as string;
  save();
  res.json(authPasswordResetV1(resetCode, newPassword));
});

// route for authRegisterV3
app.post('/auth/register/v3', (req, res) => {
  const { email, password, nameFirst, nameLast } = req.body;
  const result = authRegisterV1(email, password, nameFirst, nameLast);
  save();
  res.json(result);
});

// route for authLoginV3
app.post('/auth/login/v3', (req: Request, res: Response, next) => {
  const { email, password } = req.body;
  const result = authLoginV1(email, password);
  save();
  res.json(result);
});

// route for authLogoutV2
app.post('/auth/logout/v2', (req, res) => {
  const token = req.header('token');
  const result = authLogOutV1(token);
  save();
  res.json(result);
});

/// /////////////// CHANNEL(S) ////////////////////

// route for channelsCreateV3
app.post('/channels/create/V3', (req, res) => {
  const { name, isPublic } = req.body;
  const token = req.header('token');
  const result = channelsCreateV1(token, name, isPublic);
  save();
  res.json(result);
});
// route for channelsList
app.get('/channels/list/v3', (req, res) => {
  const token = req.header('token');
  res.json(channelsListV1(token));
});

// route for /channelsListAllV3
app.get('/channels/listAll/v3', (req, res) => {
  const token = req.headers.token as string;
  res.json(channelsListAllV1(token));
});

/// //////////////// CHANNEL //////////////////////
// route for channelsLeaveV1
app.post('/channel/leave/v2', (req, res) => {
  const { channelId } = req.body;
  const token = req.header('token');
  const result = channelLeaveV1(token, channelId);
  save();
  res.json(result);
});

// route for channelDetailsV2
app.get('/channel/details/v3', (req, res) => {
  const token = req.headers.token as string;
  const channelId = req.query.channelId as string;
  res.json(channelDetailsV1(token, parseInt(channelId)));
});

// route for channelJoinV3
app.post('/channel/join/v3', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.body.channelId as string;
  const result = channelJoinV1(token, parseInt(channelId));
  save();
  res.json(result);
});

// route for /channelsListAllV2
app.get('/channels/listall/v2', (req, res) => {
  const token = req.query.token as string;
  res.json(channelsListAllV1(token));
});

// route for channelInviteV3
app.post('/channel/invite/v3', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.body.channelId as number;
  const uId = req.body.uId as number;
  const result = channelInviteV1(token, channelId, uId);
  save();
  res.json(result);
});

// route for channelMessagesV2
app.get('/channel/messages/v3', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.query.channelId as string;
  const start = req.query.start as string;
  res.json(channelMessagesV1(token, parseInt(channelId), parseInt(start)));
});

// route for channelAddOwnerV2
app.post('/channel/addowner/v2', (req, res) => {
  const { channelId, uId } = req.body;
  const token = req.header('token');
  const result = channelAddOwnerV1(token, channelId, uId);
  save();
  res.json(result);
});

app.post('/channel/removeowner/v2', (req, res) => {
  const { channelId, uId } = req.body;
  const token = req.header('token');
  const result = channelRemoveOwnerV1(token, channelId, uId);
  save();
  res.json(result);
});

/// ///////////////// DM //////////////////////

// route for dmCreateV2
app.post('/dm/create/v2', (req: Request, res:Response, next) => {
  const token = req.headers.token as string;
  const uIds = req.body.uIds as number[];
  const result = dmCreateV1(token, uIds);
  save();
  res.json(result);
});

// route for dmDetailsv2
app.get('/dm/details/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const dmId = req.query.dmId as string;
  res.json(dmDetailsV1(token, parseInt(dmId)));
});

// route for dmListV2
app.get('/dm/list/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  res.json(dmListV1(token));
});

// route for dmLeaveV2
app.post('/dm/leave/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const dmId = req.body.dmId as number;
  const result = dmLeaveV1(token, dmId);
  save();
  res.json(result);
});

// route for dmMessagesV1
app.get('/dm/messages/v2', (req, res, next) => {
  const token = req.headers.token as string;
  const dmId = req.query.dmId as string;
  const start = req.query.start as string;
  res.json(dmMessagesV1(token, parseInt(dmId), parseInt(start)));
});

// route for dmRemoveV2
app.delete('/dm/remove/v2', (req, res, next) => {
  const token = req.headers.token as string;
  const dmId = req.query.dmId as string;
  const result = dmRemoveV1(token, parseInt(dmId));
  save();
  res.json(result);
});

/// ///////////////// MESSAGES ////////////////////////

// route for messageSenddmV1
app.post('/message/senddm/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const dmId = req.body.dmId as number;
  const message = req.body.message as string;
  const result = messageSenddmV1(token, dmId, message);
  save();
  res.json(result);
});

// route for messageSendV1
app.post('/message/send/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.body.channelId as number;
  const message = req.body.message as string;
  const result = messageSendV1(token, channelId, message);
  save();
  res.json(result);
});

// route for messageEditV1
app.put('/message/edit/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const messageId = req.query.messageId as string;
  const message = req.query.message as string;
  const result = messageEditV1(token, parseInt(messageId), message);
  save();
  res.json(result);
});

// route for messageRemoveV1
app.delete('/message/remove/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const messageId = req.query.messageId as string;
  const result = messageRemoveV1(token, parseInt(messageId));
  save();
  res.json(result);
});

app.post('/message/sendlater/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.body.channelId as number;
  const message = req.body.message as string;
  const timeSent = req.body.timeSent as number;
  const result = messageSendlaterV1(token, channelId, message, timeSent);
  save();
  res.json(result);
});

app.post('/message/sendlaterdm/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const dmId = req.body.dmId as number;
  const message = req.body.message as string;
  const timeSent = req.body.timeSent as number;
  const result = messageSendLaterDmV1(token, dmId, message, timeSent);
  save();
  res.json(result);
});

app.post('/message/pin/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const messageId = req.body.messageId as number;
  const result = messagePinV1(token, messageId);
  save();
  res.json(result);
});

app.post('/message/unpin/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const messageId = req.body.messageId as number;
  const result = messageUnpinV1(token, messageId);
  save();
  res.json(result);
});

// messageReact route
app.post('/message/react/v1', (req: Request, res: Response, next) => {
  const token = req.header('token');
  const messageId = req.body.messageId as number;
  const reactId = req.body.reactId as number;
  const result = messageReactV1(token, messageId, reactId);
  save();
  res.json(result);
});

// messageUnreact route
app.post('/message/unreact/v1', (req: Request, res: Response, next) => {
  const token = req.header('token');
  const messageId = req.body.messageId as number;
  const reactId = req.body.reactId as number;
  const result = messageUnreactV1(token, messageId, reactId);
  save();
  res.json(result);
});

// route for messageShare
app.post('/message/share/v1', (req: Request, res: Response, next) => {
  const token = req.header('token');
  const ogMessageId = req.body.ogMessageId as number;
  const message = req.body.message as string;
  const channelId = req.body.channelId as number;
  const dmId = req.body.dmId as number;
  const result = messageShareV1(token, ogMessageId, message, channelId, dmId);
  save();
  res.json(result);
});

// route for search
app.get('/search/v1', (req, res) => {
  const token = req.header('token');
  const queryStr = req.query.queryStr as string;
  res.json(searchV1(token, queryStr));
});

/// //////////////////// USER ///////////////////////////

// route for userProfileV3
app.get('/user/profile/v3', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const uId = req.query.uId as string;
  res.json(userProfileV1(token, parseInt(uId)));
});

// route for userProfileSethandleV1
app.put('/user/profile/sethandle/v2', (req, res, next) => {
  const token = req.headers.token as string;
  const handleStr = req.query.handleStr as string;
  const result = userProfileSethandleV1(token, handleStr);
  save();
  res.json(result);
});

// route for userProfileSetemailV1
app.put('/user/profile/setemail/v2', (req, res, next) => {
  const token = req.headers.token as string;
  const email = req.query.email as string;
  const result = userProfileSetemailV1(token, email);
  save();
  res.json(result);
});

// userProfileSetname route
app.put('/user/profile/setname/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const nameFirst = req.query.nameFirst as string;
  const nameLast = req.query.nameLast as string;
  const result = userProfileSetnameV1(token, nameFirst, nameLast);
  save();
  res.json(result);
});

app.post('/user/profile/uploadphoto/v1', (req: Request, res: Response, next) => {
  const token = req.header('token');
  const imgUrl = req.body.imgUrl as string;
  const xStart = req.body.xStart as number;
  const yStart = req.body.yStart as number;
  const xEnd = req.body.xEnd as number;
  const yEnd = req.body.yEnd as number;
  const result = userProfileUploadPhotov1(token, imgUrl, xStart, yStart, xEnd, yEnd);
  save();
  res.json(result);
});

/// /////////////////// USER(S) /////////////////////////

// route for usersAllV1
app.get('/users/all/v2', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  return res.json(usersAllV1(token));
});

// get route for retrieving users
app.get('/users/all/v1', (req: Request, res: Response, next) => {
  const token = req.query.token as string;
  return res.json(usersAllV1(token));
});

/// ///////////////////// STANDUP ///////////////////////////

// route for standupStartV1
app.post('/standup/start/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.body.channelId as number;
  const length = req.body.length as number;
  const result = standupStartV1(token, channelId, length);
  save();
  res.json(result);
});

// route for standupSendV1
app.post('/standup/send/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.body.channelId as number;
  const message = req.body.message as string;
  const result = standupSendV1(token, channelId, message);
  save();
  res.json(result);
});

// route for standupActiveV1
app.get('/standup/active/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  const channelId = req.query.channelId as string;
  res.json(standupActiveV1(token, parseInt(channelId)));
});

/// //////////////// NOTIFICATION(S) /////////////////////////
app.get('/notifications/get/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  save();
  res.json(notificationsGetV1(token));
});

/// //////////////// Iteration 4 Functions /////////////////////

// route for user/stats/v1
app.get('/user/stats/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  res.json(userStatsV1(token));
});

// route for user/stats/v1
app.get('/users/stats/v1', (req: Request, res: Response, next) => {
  const token = req.headers.token as string;
  res.json(usersStatsV1(token));
});

/// //////////////////////////////////////////////////////////
/* errorHandler MUST BE KEPT BELOW ALL THE ROUTES */
app.use(errorHandler());
