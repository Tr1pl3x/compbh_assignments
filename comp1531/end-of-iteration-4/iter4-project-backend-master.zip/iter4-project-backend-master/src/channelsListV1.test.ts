
/**
 * For iteration 4, this test file is commented.
*/

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import type { AuthUserId } from './interface';
// import { clearV2, channelsListV3, authRegisterV3, channelsCreateV3 } from './testHelpers';

// let newPerson: AuthUserId;

// beforeEach(() => {
//   clearV2();
//   newPerson = authRegisterV3('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
// });

// describe('Testing different parameters that covers every line of code', () => {
//   test('Valid Parameters, one channel', () => {
//     console.log(newPerson.token)
//     const thread = channelsCreateV3(newPerson.token, 'Channel Name', true);
//     console.log(thread);
//     expect(channelsListV3(newPerson.token)).toStrictEqual({
//       channels: [
//         {
//           channelId: expect.any(Number),
//           name: expect.any(String),
//         },
//       ],
//     });
//   });

// test('authUserId is invalid', () => {
//   channelsCreateV3(newPerson.token, 'Channel Name', true);
//   expect(channelsListV3('invalid userId')).toStrictEqual(403);
// });

// test('Valid Parameters, multiple channels', () => {
//   channelsCreateV3(newPerson.token, 'Channel Name', true);
//   channelsCreateV3(newPerson.token, 'Channel Name2', true);
//   channelsCreateV3(newPerson.token, 'Channel Name3', true);
//   channelsCreateV3(newPerson.token, 'Channel Name4', true);
//   expect(channelsListV3(newPerson.token)).toStrictEqual({
//     channels: [
//       {
//         channelId: expect.any(Number),
//         name: expect.any(String),
//       },
//       {
//         channelId: expect.any(Number),
//         name: expect.any(String),
//       },
//       {
//         channelId: expect.any(Number),
//         name: expect.any(String),
//       },
//       {
//         channelId: expect.any(Number),
//         name: expect.any(String),
//       }
//     ],
//   });
// });
// });
