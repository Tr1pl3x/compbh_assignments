
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
// import { clearV2, authRegisterV3, userProfileSetnameV2, userProfileV3 } from './testHelpers';

// import type { AuthUserId, UserProfile } from './interface';

// // const ERROR = { error: expect.any(String) };

// let user1: AuthUserId; // authUserId

// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
// });

// describe('Expected return values', () => {
//   test('Invalid token', () => {
//     const changeUser = userProfileSetnameV2(user1.token + 1, 'Joe', 'Chand');
//     expect(changeUser).toStrictEqual(403);
//   });

//   test('Invalid name length', () => {
//     const changeUser = userProfileSetnameV2(user1.token, '', 'Chand');
//     expect(changeUser).toStrictEqual(400);
//   });

//   test('Valid Return and Updates the dataStore correctly', () => {
//     const changeUser = userProfileSetnameV2(user1.token, 'Joey', 'Chand');
//     expect(changeUser).toStrictEqual({});
//     const userprofile = userProfileV3(user1.token, user1.authUserId) as UserProfile;
//     expect(userprofile).toStrictEqual({
//       user: {
//         uId: user1.authUserId,
//         nameFirst: userprofile.user.nameFirst,
//         nameLast: userprofile.user.nameLast,
//         email: userprofile.user.email,
//         handleStr: userprofile.user.handleStr,
//       }
//     });
//   });
// });
