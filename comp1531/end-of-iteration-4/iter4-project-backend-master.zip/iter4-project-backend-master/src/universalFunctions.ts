// this is a file for functions that get repeated many times throughout the project
import { getData } from './dataStore';
import type { Channels, User, aUser, DM, MessageInfo, tokenObj } from './interface';
import crypto from 'crypto';
/*
* the below function returns true if the token is valid and
* false if the token is invalid
*/

export function getHashOf(Anystring: string) {
  const secret = 'BOOST';
  return crypto.createHash('sha256').update(Anystring + secret).digest('hex');
}

export function isValidToken(token: string): (boolean) {
  const data = getData();
  const hash = getHashOf(token);
  // checking if the token is valid
  for (const person of data.users) {
    // looping through tokens as there could be multiple
    for (const tokenObj of person.tokens) {
      if (tokenObj.tokenId === hash) {
        return true;
      }
    }
  }
  return false;
}

/*
* the below function checks that the channel is valid
*/
export function isValidChannel(channelId: number): boolean {
  const data = getData();
  // looping through channels
  for (const channel of data.channels) {
    // finding channelId
    if (channel.channelId === channelId) {
      return true;
    }
  }
  return false;
}

/*
* the below function checks that the dm is valid
*/
export function isValidDm(DMID: number): boolean {
  const data = getData();
  // looping through channels
  for (const dm of data.dms) {
    // finding channelId
    if (dm.dmId === DMID) {
      return true;
    }
  }
  return false;
}

export function uIdValid (uId: number): (boolean) {
  const data = getData();
  // checking if the token is valid
  for (const person of data.users) {
    if (person.uId === uId) {
      return true;
    }
  }
  return false;
}

/*
* the below function returns the channel given a channelId
* returns undefined if the channel does not exist
*/
export function returnChannel (channelId: number): (Channels) {
  const data = getData();
  // checking the channelId is valid
  for (const channels of data.channels) {
    // looping through channels
    if (channels.channelId === channelId) {
      return channels;
    }
  }
  return undefined;
}
/*
* the below function returns the dm object given a dmId
* returns undefined if the dm does not exist
*/
export function returnDm (dmId: number): (DM) {
  const data = getData();
  return (data.dms).find((dm: DM) => dm.dmId === dmId);
}

/*
* the below function returns the uId of a user given a token
* return is undefined if the user does not exist
*/
export function getuId (token: string): (number) {
  const data = getData();
  const hash = getHashOf(token);
  const user = data.users.find((user: aUser) => user.tokens.find((t: tokenObj) => t.tokenId === hash));
  if (user !== undefined) {
    return user.uId;
  } else {
    return undefined;
  }
}

/*
* the below function returns the user given a token
* return is undefined if the user does not exist
*/
export function getUserFromToken (token: string): (User) {
  const data = getData();
  const hash = getHashOf(token);
  const user = data.users.find((user: aUser) => user.tokens.find((t: tokenObj) => t.tokenId === hash));
  if (user === undefined) {
    return undefined;
  } else {
    return {
      uId: user.uId,
      email: user.email,
      nameFirst: user.nameFirst,
      nameLast: user.nameLast,
      handleStr: user.handleStr,
      channelsJoined: user.channelsJoined
    };
  }
}

/*
* the below function returns the user given a token
* return is undefined if the user does not exist
*/
export function getUserFromId (uId: number): (User) {
  const data = getData();
  for (const person of data.users) {
    if (person.uId === uId) {
      const tempMember: User = {
        uId: person.uId,
        email: person.email,
        nameFirst: person.nameFirst,
        nameLast: person.nameLast,
        handleStr: person.handleStr,
        channelsJoined: person.channelsJoined
      };
      return tempMember;
    }
  }
  return undefined;
}
/*
* Helper function to check if user calling the function is the same as
* the user to be added/invited
* used in channelInviteV3
*/
export function isSameUser (validUserId: User, uId: number) : boolean {
  if (validUserId.uId === uId) {
    return true;
  }
  return false;
}

/*
* Helper function to check check whether authorized user is
* a member of the channel
*/
export function isAuthMemberOfChannel(validUserId: User, currChannel: Channels) : boolean {
  if (currChannel.allMembers.find((member: aUser) => member.uId === validUserId.uId)) {
    return true;
  }
  return false;
}

/*
* Helper function to check check whether authorized user is
* a member of the dm
*/
export function isAuthMemberOfDm(validUserId: User, currDm: DM) : boolean {
  if (currDm.allMembers.find((member: aUser) => member.uId === validUserId.uId)) {
    return true;
  }
  return false;
}

export function isAuthIdMemberOfDm(validUserId: User, currDm: DM) : boolean {
  if (currDm.allMembers.find((member: aUser) => member.uId === validUserId.uId)) {
    return true;
  }
  return false;
}

/*
* Helper function to check check whether uId / user to be invited is
* a member of the channel
*/
export function isUidMemberOfChannel(uId: number, currChannel: Channels) : boolean {
  if ((currChannel.allMembers).find((member: aUser) => member.uId === uId)) {
    return true;
  }
  return false;
}

/*
* Helper function returns the dm given a messageId
* returns undefined if the messageId is invalid
*/
export function returnDmFromMessageId (messageId: number): (DM) {
  const data = getData();
  return data.dms.find((d: DM) => d.allMessages.find((m: MessageInfo) => m.messageId === messageId));
}

/*
* Helper function returns the channel given a messageId
* returns undefined if the messageId is invalid
*/
export function returnChannelFromMessageId (messageId: number): (Channels) {
  const data = getData();
  return data.channels.find((c: Channels) => c.allMessages.find((m: MessageInfo) => m.messageId === messageId));
}

/*
* Helper function returns the specified channel message
* takes current channel object and message id
* returns undefined if the messageId is invalid
*/
export function returnChannelMessage (messageId: number, currChannel: Channels): MessageInfo {
  return currChannel.allMessages.find((m: MessageInfo) => m.messageId === messageId);
}

/*
* Helper function returns the specified dm message
* takes current dm object and message id
* returns undefined if the messageId is invalid
*/
export function returnDmMessage (messageId: number, currDm: DM): MessageInfo {
  return currDm.allMessages.find((m: MessageInfo) => m.messageId === messageId);
}

/*
* Helper function determines whether the message sent was from the authorized user
* takes in current auth user object, current dm object and message id
* returns false if message was not sent by the authorized user
*/
export function isDmMessageSentByAuthId (messageId: number, currDm: DM, validUserId: User) : boolean {
  return Boolean(currDm.allMessages.find((m: MessageInfo) => m.messageId === messageId).uId === validUserId.uId);
}

/*
* Helper function determines whether the message sent was from the authorized user
* takes in current auth user object, current channel object and message id
* returns false if message was not sent by the authorized user
*/
export function isChannelMessageSentByAuthId (messageId: number, currChannel: Channels, validUserId: User) : boolean {
  return Boolean(currChannel.allMessages.find((m: MessageInfo) => m.messageId === messageId).uId === validUserId.uId);
}

/*
* Helper function to check whether user is the owner of channel
* takes in current channel object and authorized user object
* returns true if user is the owner of the channel
*/
export function isDmOwner (currDm: DM, validUserId: User) : boolean {
  return Boolean(currDm.ownerMembers.find((member: aUser) => member.uId === validUserId.uId));
}
/*
* Helper function to check whether user is the owner of channel
* takes in current channel object and authorized user object
* returns true if user is the owner of the channel
*/
export function isChannelOwner (currChannel: Channels, validUserId: User) : boolean {
  return Boolean(currChannel.ownerMembers.find((member: aUser) => member.uId === validUserId.uId));
}

/*
* Helper function to check whether a name is valid as per the specification
* takes in a name a returns a boolean
*/
export function validateName(name: string): boolean {
  if ((name.length > 50) || (name.length < 1)) {
    return true;
  } else {
    return false;
  }
}

/*
* Helper function to check whether a url is valid as per the specification
* takes in a url a returns a boolean. If the url is not HTTP, returns false.
*/
export function isValidHttpUrl(url: string): boolean {
  const pattern = new RegExp(
    '^(http?:\\/\\/)?' + // protocol
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
      '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
      '(\\#[-a-z\\d_]*)?$', // fragment locator
    'i'
  );
  return pattern.test(url);
}

/*
* Helper function returns the dm given a dmId
* returns undefined if the messageId is invalid
*/
export function returnDmFromDmId (dmId: number): (DM) {
  const data = getData();
  const dm = data.dms.find(dm => dm.dmId === dmId);
  return dm;
}

/*
* Helper function returns the channel given a messageId
* returns undefined if the messageId is invalid
*/
export function returnChannelFromChannelId (chanId: number): (Channels) {
  const data = getData();
  const channel = data.channels.find(c => c.channelId === chanId);
  return channel;
}
