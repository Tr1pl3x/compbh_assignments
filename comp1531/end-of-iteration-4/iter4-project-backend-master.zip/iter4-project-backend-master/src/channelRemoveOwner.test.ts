
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { channelsCreateV3, clearV2, authRegisterV2, channelAddOwnerV1, channelInviteV3, channelRemoveOwnerV1 } from './testHelpers';
// import type { AuthUserId, ChannelId } from './interface';

// let newPerson: AuthUserId;
// let newPerson2: AuthUserId;
// let channelId1: ChannelId;
// beforeEach(() => {
//   clearV2();
//   newPerson = authRegisterV2('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
//   newPerson2 = authRegisterV2('sammyj2@gmail.com', 'pppassword2', 'Sammy', 'Greg') as AuthUserId;
//   channelId1 = channelsCreateV3(newPerson.token, 'ChannelName', false) as ChannelId;
// });

// describe('Testing different parameters that covers every line of code', () => {
//   test('channelId is invalid', () => {
//     expect(channelRemoveOwnerV1(newPerson.token, -1, newPerson2.authUserId)).toStrictEqual({ error: 'invalid channelId' });
//   });
//   test('token is invalid', () => {
//     expect(channelRemoveOwnerV1('abc', channelId1.channelId, newPerson2.authUserId)).toStrictEqual({ error: 'invalid token' });
//   });
//   test('user id is invalid', () => {
//     expect(channelRemoveOwnerV1(newPerson.token, channelId1.channelId, -1)).toStrictEqual({ error: 'invalid uId' });
//   });
//   test('User is not in channel', () => {
//     expect(channelRemoveOwnerV1(newPerson.token, channelId1.channelId, newPerson2.authUserId)).toStrictEqual({ error: 'user is not in channel' });
//   });
//   test('User is not an owner', () => {
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson2.authUserId);
//     expect(channelRemoveOwnerV1(newPerson.token, channelId1.channelId, newPerson2.authUserId)).toStrictEqual({ error: 'user is not an owner' });
//   });

//   test('User is the only owner', () => {
//     expect(channelRemoveOwnerV1(newPerson.token, channelId1.channelId, newPerson.authUserId)).toStrictEqual({ error: 'user is the only owner' });
//   });

//   test('Authorised user does not have owner permissions', () => {
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson2.authUserId);
//     expect(channelRemoveOwnerV1(newPerson2.token, channelId1.channelId, newPerson.authUserId)).toStrictEqual({ error: 'authorised user not an owner' });
//   });
//   test('Valid Parameters', () => {
//     channelInviteV3(newPerson.token, channelId1.channelId, newPerson2.authUserId);
//     channelAddOwnerV1(newPerson.token, channelId1.channelId, newPerson2.authUserId);
//     expect(channelRemoveOwnerV1(newPerson2.token, channelId1.channelId, newPerson.authUserId)).toStrictEqual({});
//   });
// });
