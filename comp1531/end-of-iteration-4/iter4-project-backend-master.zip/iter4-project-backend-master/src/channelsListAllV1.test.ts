
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { channelsListAllV3, channelsCreateV3 } from './testHelpers';
// import { authRegisterV3 } from './testHelpers';
// import { clearV2 } from './testHelpers';
// import type { AuthUserId, Channels } from './interface';

// beforeEach(() => {
//   clearV2();
// });

// describe('channelsListAllV1', () => {
//   test('returns an array of channel  for valid authUserId', () => {
//     // const authUserId = 'validUserId';
//     const user1 = authRegisterV3('evan.dang@unsw.edu.au', '123456', 'Johnny', 'Yes') as AuthUserId;
//     const channelCreating = channelsCreateV3(user1.token, 'Valid channel name', false) as Channels;
//     expect(channelsListAllV3(user1.token)).toStrictEqual(
//       {
//         channels: [{
//           channelId: channelCreating.channelId,
//           name: 'Valid channel name'
//         }]
//       });
//     clearV2();
//   });

//   // test('Valid Parameters, one channel', () => {
//   //   expect(4).toStrictEqual(4);
//   // });

//   describe('Return value for variosu function ', () => {
//     test('channelsListAllV1 testing', () => {
//       const user1first = authRegisterV3('evan.dang@unsw.edu.au', '123456aA', 'Johnny', 'Yes') as AuthUserId;
//       const firsttest = channelsCreateV3(user1first.token, 'channelname_A', true) as Channels;
//       const secondtest = channelsCreateV3(user1first.token, 'channelname_B', false) as Channels;
//       const thirdtests = channelsCreateV3(user1first.token, 'channelname_C', true) as Channels;
//       expect(channelsListAllV3(user1first.token)).toStrictEqual({
//         channels: [
//           {
//             channelId: firsttest.channelId,
//             name: 'channelname_A',
//           },
//           {
//             channelId: secondtest.channelId,
//             name: 'channelname_B',
//           },
//           {
//             channelId: thirdtests.channelId,
//             name: 'channelname_C',
//           },
//         ]
//       });
//     });
//     clearV2();
//   });
// });
// test('valid test', () => {
//   expect(2 + 2).toStrictEqual(4);
// });
