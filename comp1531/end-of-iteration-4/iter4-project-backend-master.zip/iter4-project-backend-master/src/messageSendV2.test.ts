
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, channelsCreateV3, clearV2 } from './testHelpers';
// import type { AuthUserId, ChannelId } from './interface';
// import { channelMessagesV3, messageSendV2 } from './testHelpers';

// let user1: AuthUserId;
// let user2: AuthUserId;
// let channel1: ChannelId;
// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
//   channel1 = channelsCreateV3(user1.token, 'New Channel', true) as ChannelId;
// });
// describe('messageSendV2 Tests', () => {
//   test('Error: invalid token', () => {
//     expect(messageSendV2(user1.token + 1, channel1.channelId, 'inputmessage')).toStrictEqual(403);
//   });
//   test('Error: empty token', () => {
//     expect(messageSendV2('', channel1.channelId + 1, 'inputmessage')).toStrictEqual(403);
//   });
//   test('Error: invalid channelId', () => {
//     expect(messageSendV2(user1.token, channel1.channelId + 1, 'inputmessage')).toStrictEqual(400);
//   });
//   test('Message length > 1000', () => {
//     expect(messageSendV2(user1.token, channel1.channelId, 'a'.repeat(1001))).toStrictEqual(400);
//   });
//   test('Error: authId does not exist in channel, but channelId valid', () => {
//     const channel2 = channelsCreateV3(user2.token, 'New Channel2', true) as ChannelId;
//     expect(messageSendV2(user1.token, channel2.channelId, 'inputmessage')).toStrictEqual(403);
//   });
//   test('Error: Message length < 1', () => {
//     expect(messageSendV2(user1.token, channel1.channelId, '')).toStrictEqual(400);
//   });
//   test('Valid: New channel, empty message', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining(
//         {
//           messages: [],
//           start: 0,
//           end: -1,
//         }
//       ));
//   });
//   test('Valid: New channel, Send Message', () => {
//     expect(messageSendV2(user1.token, channel1.channelId, 'Hello World')).toStrictEqual(
//       expect.objectContaining({
//         messageId: expect.any(Number),
//       })
//     );
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Hello World',
//             timeSent: expect.any(Number),
//           })
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
//   test('Valid: Send 2 Message', () => {
//     expect(messageSendV2(user1.token, channel1.channelId, 'Hello World')).toStrictEqual(
//       expect.objectContaining({
//         messageId: expect.any(Number),
//       })
//     );
//     expect(messageSendV2(user1.token, channel1.channelId, 'Good Mythical Morning')).toStrictEqual(
//       expect.objectContaining({
//         messageId: expect.any(Number),
//       })
//     );
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Good Mythical Morning',
//             timeSent: expect.any(Number),
//           }),
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Hello World',
//             timeSent: expect.any(Number),
//           })
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
// });
