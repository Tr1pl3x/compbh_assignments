
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import {
//   authRegisterV3,
//   dmCreateV2,
//   clearV2,
//   dmMessagesV2,
//   messageSenddmV2
// } from './testHelpers';

// import {
//   AuthUserId
// } from './interface';

// let mainUser: AuthUserId, user1: AuthUserId, user2: AuthUserId;

// beforeEach(() => {
//   clearV2();
//   mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
//   user2 = authRegisterV3('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
// });

// describe('Testing invalid parameters', () => {
//   test('Passing invalid token', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const start = 0;
//     const Messagesreturn = dmMessagesV2(mainUser.token + 1, testDM.dmId, start);
//     expect(Messagesreturn).toStrictEqual(403);
//   });

//   test('Passing empty token', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const start = 0;
//     const Messagesreturn = dmMessagesV2('', testDM.dmId, start);
//     expect(Messagesreturn).toStrictEqual(403);
//   });

//   test('Passing invalid DMId', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const start = 0;
//     const Messagesreturn = dmMessagesV2(mainUser.token, testDM.dmId + 1, start);
//     expect(Messagesreturn).toStrictEqual(400);
//   });

//   test('Passing invalid start value', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const start = 51;
//     const Messagesreturn = dmMessagesV2(mainUser.token, testDM.dmId, start);
//     expect(Messagesreturn).toStrictEqual(400);
//   });
//   test('Authorised access check', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const randomUser = authRegisterV3('bcr@gmail.com', 'psacode', 'Bl', 'Raer') as AuthUserId;
//     const start = 1;
//     const Messagesreturn = dmMessagesV2(randomUser.token, testDM.dmId, start);
//     expect(Messagesreturn).toStrictEqual(403);
//   });
// });

// describe('Testing valid parameters', () => {
//   test('Between 0 and 50 messages (includes 0)', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const start = 1;
//     // create 25 messages
//     for (let i = 0; i < 25; i++) {
//       messageSenddmV2(user1.token, testDM.dmId, 'Hello');
//     }
//     const Messagesreturn = dmMessagesV2(mainUser.token, testDM.dmId, start);
//     expect(Messagesreturn).toStrictEqual({
//       messages: expect.arrayContaining([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number)
//         }),
//       ]),
//       start: expect.any(Number),
//       end: -1
//     });
//   });
//   test('More than 50 messages', () => {
//     const testDM = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId]);
//     const start = 0;

//     // create 60 messages
//     for (let i = 0; i < 60; i++) {
//       messageSenddmV2(user2.token, testDM.dmId, 'Hello');
//     }
//     const Messagesreturn = dmMessagesV2(mainUser.token, testDM.dmId, start);
//     expect(Messagesreturn).toStrictEqual({
//       messages: expect.arrayContaining([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number)
//         }),
//       ]),
//       start: expect.any(Number),
//       end: 50
//     });
//   });
// });
