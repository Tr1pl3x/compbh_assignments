
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import type { AuthUserId, ChannelId } from './interface';
// import { authRegisterV3, channelsCreateV3, clearV2, channelMessagesV3, messageSendV2 } from './testHelpers';

// let user1: AuthUserId;
// let user2: AuthUserId;
// let channel1: ChannelId;
// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
//   channel1 = channelsCreateV3(user1.token, 'New7Channel', true) as ChannelId;
// });
// describe('channelMessagesV3 Edge Tests', () => {
//   test('Error: invalid token', () => {
//     expect(channelMessagesV3(user1.token + 1, channel1.channelId, 0)).toStrictEqual(403);
//   });
//   test('Error: invalid channelId', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId + 1, 0)).toStrictEqual(400);
//   });
//   test('Error: authId does not exist in channel, but channelId valid', () => {
//     const channel2 = channelsCreateV3(user2.token, 'New Channel2', true) as ChannelId;
//     expect(channelMessagesV3(user1.token, channel2.channelId, 0)).toStrictEqual(403);
//   });
//   test('Error: Start is negative', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId, -1)).toStrictEqual(400);
//   });
//   test('Error: Start greater than end', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId, 51)).toStrictEqual(400);
//   });
//   test('Error: Start equal to end', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId, 50)).toStrictEqual(400);
//   });
//   test('Valid: New channel, empty message', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining(
//         {
//           messages: [],
//           start: 0,
//           end: -1,
//         }
//       ));
//   });
// });
// describe('channelMessagesV3 Messages Tests', () => {
//   test('Valid: 1 message', () => {
//     messageSendV2(user1.token, channel1.channelId, 'Hello World');
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: expect.any(Number),
//             message: 'Hello World',
//             timeSent: expect.any(Number)
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       }
//       ));
//   });
//   test('Valid: 2 messages', () => {
//     messageSendV2(user1.token, channel1.channelId, 'Hello World');
//     messageSendV2(user1.token, channel1.channelId, 'Hello another World');
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: expect.any(Number),
//             message: 'Hello World',
//             timeSent: expect.any(Number)
//           }),
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: expect.any(Number),
//             message: 'Hello another World',
//             timeSent: expect.any(Number)
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       }
//       ));
//   });
// });

// describe('25 Messages', () => {
//   beforeEach(() => {
//     for (let i = 0; i < 25; i++) {
//       messageSendV2(user1.token, channel1.channelId, 'Hello World');
//     }
//   });
//   test('Valid: 25 messages', () => {
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: expect.any(Number),
//             message: expect.any(String),
//             timeSent: expect.any(Number)
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       }
//       ));
//   });
//   describe('50 Messages', () => {
//     beforeEach(() => {
//       // Add 25 more messages, total: 50 messages
//       for (let i = 0; i < 25; i++) {
//         messageSendV2(user1.token, channel1.channelId, 'Hello World');
//       }
//     });
//     test('Valid: 50 messages (end = -1)', () => {
//       expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//         expect.objectContaining({
//           messages: expect.arrayContaining([
//             expect.objectContaining({
//               messageId: expect.any(Number),
//               uId: expect.any(Number),
//               message: expect.any(String),
//               timeSent: expect.any(Number)
//             }),
//           ]),
//           start: 0,
//           end: -1,
//         }
//         ));
//     });
//     describe('75 Messages', () => {
//       beforeEach(() => {
//         // Add 25 more messages, total: 75 messages
//         for (let i = 0; i < 25; i++) {
//           messageSendV2(user1.token, channel1.channelId, 'Hello World');
//         }
//       });
//       test('Valid: 75 messages (end = 50)', () => {
//         expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//           expect.objectContaining({
//             messages: expect.arrayContaining([
//               expect.objectContaining({
//                 messageId: expect.any(Number),
//                 uId: expect.any(Number),
//                 message: expect.any(String),
//                 timeSent: expect.any(Number)
//               }),
//             ]),
//             start: 0,
//             end: 50,
//           }
//           ));
//       });
//       test('Valid: 75 messages (start = 50) (end = -1)', () => {
//         expect(channelMessagesV3(user1.token, channel1.channelId, 50)).toStrictEqual(
//           expect.objectContaining({
//             messages: expect.arrayContaining([
//               expect.objectContaining({
//                 messageId: expect.any(Number),
//                 uId: expect.any(Number),
//                 message: expect.any(String),
//                 timeSent: expect.any(Number)
//               }),
//             ]),
//             start: 50,
//             end: -1,
//           }
//           ));
//       });
//       describe('110 Messages', () => {
//         beforeEach(() => {
//           // Add 35 more messages, total: 110 messages
//           for (let i = 0; i < 35; i++) {
//             messageSendV2(user1.token, channel1.channelId, 'Hello World');
//           }
//         });
//         test('Valid: 110 messages (start = 50) (end = 100)', () => {
//           expect(channelMessagesV3(user1.token, channel1.channelId, 50)).toStrictEqual(
//             expect.objectContaining({
//               messages: expect.arrayContaining([
//                 expect.objectContaining({
//                   messageId: expect.any(Number),
//                   uId: expect.any(Number),
//                   message: expect.any(String),
//                   timeSent: expect.any(Number)
//                 }),
//               ]),
//               start: 50,
//               end: 100,
//             }
//             ));
//         });
//       });
//     });
//   });
// });
