
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, clearV2 } from './testHelpers';
// import type { AuthUserId, DmID } from './interface';
// import { messageSenddmV2, dmCreateV2, dmMessagesV2 } from './testHelpers';

// let dmcreator: AuthUserId;
// let user1: AuthUserId;
// let user2: AuthUserId;
// let dm1: DmID;
// beforeEach(() => {
//   clearV2();
//   dmcreator = authRegisterV3('creator@gmail.com', 'Password', 'Tynan', 'Sylvester') as AuthUserId;
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
//   dm1 = dmCreateV2(dmcreator.token, [user1.authUserId, user2.authUserId]) as DmID;
// });
// describe('messageSenddmV2 Tests', () => {
//   test('Error: empty token', () => {
//     expect(messageSenddmV2('', dm1.dmId + 1, 'inputmessage')).toStrictEqual(403);
//   });
//   test('Error: invalid dmId', () => {
//     expect(messageSenddmV2(user1.token, dm1.dmId + 1, 'inputmessage')).toStrictEqual(400);
//   });
//   test('Error: invalid token', () => {
//     expect(messageSenddmV2(user1.token + 1, dm1.dmId, 'inputmessage')).toStrictEqual(403);
//   });
//   test('Message length > 1000', () => {
//     expect(messageSenddmV2(user1.token, dm1.dmId, 'a'.repeat(1001))).toStrictEqual(400);
//   });
//   test('Error: authId does not exist in dm, but dmId valid', () => {
//     const user3 = authRegisterV3('test3@gmail.com', '1234256', 'Hayd3en', 'Sm1ith') as AuthUserId;
//     const dm2 = dmCreateV2(dmcreator.token, [user1.authUserId, user2.authUserId]) as DmID;
//     expect(messageSenddmV2(user3.token, dm2.dmId, 'inputmessage')).toStrictEqual(403);
//   });
//   test('Error: Message length < 1', () => {
//     expect(messageSenddmV2(user1.token, dm1.dmId, '')).toStrictEqual(400);
//   });
//   test('Valid: New channel, empty message', () => {
//     expect(dmMessagesV2(dmcreator.token, dm1.dmId, 0)).toStrictEqual(
//       expect.objectContaining(
//         {
//           messages: [],
//           start: 0,
//           end: -1,
//         }
//       ));
//   });
//   test('Valid: New channel, Send Message', () => {
//     expect(messageSenddmV2(user1.token, dm1.dmId, 'Hello World')).toStrictEqual(
//       expect.objectContaining({
//         messageId: expect.any(Number),
//       })
//     );
//     expect(dmMessagesV2(dmcreator.token, dm1.dmId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Hello World',
//             timeSent: expect.any(Number),
//           })
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
//   test('Valid: Send 2 Message', () => {
//     expect(messageSenddmV2(user1.token, dm1.dmId, 'Hello World')).toStrictEqual(
//       expect.objectContaining({
//         messageId: expect.any(Number),
//       })
//     );
//     expect(messageSenddmV2(user2.token, dm1.dmId, 'Good Mythical Morning')).toStrictEqual(
//       expect.objectContaining({
//         messageId: expect.any(Number),
//       })
//     );
//     expect(dmMessagesV2(dmcreator.token, dm1.dmId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user2.authUserId,
//             message: 'Good Mythical Morning',
//             timeSent: expect.any(Number),
//           }),
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Hello World',
//             timeSent: expect.any(Number),
//           })
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
// });
