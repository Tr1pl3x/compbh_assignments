/* user/stats/v1

# Passing Parameters:( token: string)

# Return type if no error: { userStats }

# (OUTPUT)
    UserStats:{
        channelsJoined : array<{numChannelsJoined,timestamp}>,
        dmsJoined: array<{numDmsJoined,timestamp}>
        messagesSent: array<{numMessagesSent, timestamp}>,
        involvementRate;
    }

# involvementRate =
(
    sum(numChanelsJoined, numDmsJoined, numMsgSent)
    /
    sum(numChannels, numDms, numMsgs)
);

# Cases to be considered:
    -Error Scenarios
        // 403 ERROR:   Invalid token]
    -Return Correct Type (x2)
        - successful stats return

///////////////////////////////////////////////////// */

// import functons
import {
  authRegisterV3,
  channelsCreateV3,
  channelInviteV3,
  channelLeaveV2,
  dmCreateV2,
  dmLeaveV2,
  dmRemoveV2,
  messageSendV2,
  messageSenddmV2,
  userStatsV1,
  clearV2,
} from './testHelpers';

// import interface
import {
  AuthUserId,
  ChannelId,
  DmID,
  MessageReturn,
} from './interface';

let mainUser: AuthUserId;

beforeEach(() => {
  clearV2();
  mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
});

describe('Error Scenarios', () => {
  test('Invalid Token', () => {
    const testVar = userStatsV1(mainUser.token + 'abg');
    expect(testVar).toStrictEqual(403);
  });
});

describe('Successful Cases', () => {
  test('Correct return type when a new user registered.', () => {
    const testVar = userStatsV1(mainUser.token);
    expect(testVar).toStrictEqual({
      userStats: {
        channelsJoined: [
          {
            numChannelsJoined: 0,
            timeStamp: expect.any(Number)
          }
        ],
        dmsJoined: [
          {
            numDmsJoined: 0,
            timeStamp: expect.any(Number)
          }
        ],
        messagesSent: [
          {
            numMessagesSent: 0,
            timeStamp: expect.any(Number)
          }
        ],
        involvementRate: 0
      }

    });
  });
  test('created one channel, one dm, one msg in channel, one in dm', () => {
    /* eslint-disable */
    const channel = channelsCreateV3(mainUser.token, 'MyChannel',) as ChannelId;
    const dm = dmCreateV2(mainUser.token,[]) as DmID;
    const msg1 = messageSendV2(mainUser.token, channel.channelId, 'Hello') as MessageReturn;
    const msg2 = messageSenddmV2(mainUser.token, dm.dmId, 'World') as MessageReturn
    /* eslint-enable */

    const testVar = userStatsV1(mainUser.token);
    expect(testVar).toStrictEqual({
      userStats: {
        channelsJoined: expect.arrayContaining(
          [expect.objectContaining(
            {
              numChannelsJoined: expect.any(Number),
              timeStamp: expect.any(Number),
            }
          )]
        ),
        dmsJoined: expect.arrayContaining(
          [
            {
              numDmsJoined: expect.any(Number),
              timeStamp: expect.any(Number),
            }
          ]
        ),
        messagesSent: expect.arrayContaining(
          [expect.objectContaining(
            {
              numMessagesSent: expect.any(Number),
              timeStamp: expect.any(Number),
            }
          )]
        ),
        involvementRate: 1,
      }
    });
  });
  test('Testing Involvement Rate', () => {
    /* eslint-disable */
    // Outside of Main User
    const sideUser = authRegisterV3('vncr@gmail.com', 'passcode', 'Dummy', 'SideUser') as AuthUserId;
    const sideChannel = channelsCreateV3(sideUser.token, 'SideChannel') as ChannelId;
    const sideDm = dmCreateV2(sideUser.token, []) as DmID;
    const sideMsg1 = messageSendV2(sideUser.token, sideChannel.channelId, 'Hello') as MessageReturn;
    const sideMsg2 = messageSenddmV2(sideUser.token, sideDm.dmId, 'World');

    // Main User ONLY
    const channel = channelsCreateV3(mainUser.token, 'MyChannel') as ChannelId;
    const dm = dmCreateV2(mainUser.token, []) as DmID;
    const msg1 = messageSendV2(mainUser.token, channel.channelId, 'Hello') as MessageReturn;
    const msg2 = messageSenddmV2(mainUser.token, dm.dmId, 'World') as MessageReturn;

    /* eslint-enable */
    // testing user stats
    const testVar = userStatsV1(mainUser.token);
    expect(testVar.userStats.involvementRate).toStrictEqual(0.5);
  });
  test('Testing decrementing channels joiend incrementing and decrementing', () => {
    /* eslint-disable */
    const jodie = authRegisterV3('jodie@gmail.com', 'passcode', 'Jodie', 'Chan') as AuthUserId;
    const channel = channelsCreateV3(mainUser.token, 'MyChannel',) as ChannelId;
    const channel1 = channelsCreateV3(jodie.token, 'J_Channel',) as ChannelId;
    const channel2 = channelsCreateV3(jodie.token, 'k_Channel',) as ChannelId;
    const channel4 = channelsCreateV3(mainUser.token, 'OtherChannel',) as ChannelId;
    channelInviteV3(mainUser.token,channel.channelId, jodie.authUserId);
    channelLeaveV2(jodie.token, channel1.channelId);
    /* eslint-disable */
    const testVar = userStatsV1(jodie.token);
    expect(testVar.userStats.involvementRate).toStrictEqual(0.5);
  });
  test('Testing decrementing dms joiend incrementing and decrementing', () => {
    /* eslint-disable */
    const jodie = authRegisterV3('jodie@gmail.com', 'passcode', 'Jodie', 'Chan') as AuthUserId;
    const dm1 = dmCreateV2(mainUser.token, [jodie.authUserId]);
    const dm2 = dmCreateV2(mainUser.token, []);
    dmLeaveV2(mainUser.token,dm1.dmId);

    /* eslint-enable */
    const testVar1 = userStatsV1(jodie.token);
    expect(testVar1.userStats.involvementRate).toStrictEqual(0.5);

    /*eslint-disable */
    const andrew = authRegisterV3('andrew@gmail.com', 'passcode', 'Andrew','Tiono');
    const dm3 = dmCreateV2(andrew.token, [mainUser.authUserId, jodie.authUserId]);
    const dm4 = dmCreateV2(andrew.token, [mainUser.authUserId]);
    const dm5 = dmCreateV2(andrew.token, []);
    /* eslint-enable */

    const testVar2 = userStatsV1(mainUser.token);
    expect(testVar2.userStats.involvementRate).toStrictEqual(0.6);
    dmRemoveV2(andrew.token, dm3.dmId);

    const testVar3 = userStatsV1(jodie.token);
    expect(testVar3.userStats.involvementRate).toStrictEqual(0.25);

    const testVar4 = userStatsV1(andrew.token);
    expect(testVar4.userStats.involvementRate).toStrictEqual(0.5);

    const elvina = authRegisterV3('elvina@gmail.com', 'passcode', 'Elvina', 'Ritenhia');
    const testVar5 = userStatsV1(elvina.token);
    expect(testVar5.userStats.involvementRate).toStrictEqual(0);
  });
});
