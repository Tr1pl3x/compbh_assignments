import type { messageResponse, MessageInfo, Channels, aUser, DM } from './interface';
import HTTPError from 'http-errors';
import { getuId, isValidToken } from './universalFunctions';
import { getData } from './dataStore';

export function searchV1(token: string, queryStr: string): messageResponse {
  if (queryStr.length > 1000 || queryStr.length < 1) {
    throw HTTPError(400, 'Error: query string too long/short');
  } else if (!isValidToken(token)) {
    throw HTTPError(403, 'Error: Invalid token');
  }

  const data = getData();
  const userId = getuId(token);
  const queryMessages: MessageInfo[] = [];

  // finding user messages in channels with query string
  data.channels.forEach((channel: Channels) => {
    const isMember = channel.allMembers.some((member: aUser) => member.uId === userId);
    if (isMember) {
      channel.allMessages.forEach((m: MessageInfo) => {
        if (m.message.includes(queryStr)) {
          queryMessages.push(m);
        }
      });
    }
  });

  // finding user messages in DMs with query string
  data.dms.forEach((dm: DM) => {
    const isMember = dm.allMembers.some((member: aUser) => member.uId === userId);
    if (isMember) {
      dm.allMessages.forEach((d: MessageInfo) => {
        if (d.message.includes(queryStr)) {
          queryMessages.push(d);
        }
      });
    }
  });
  return { messages: queryMessages };
}
