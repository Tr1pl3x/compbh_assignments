
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// /* //////////////// standupActiveV1 ////////////////////

// # Passing Parameters:( token: string, channelId: number)

// # Return type if no error: { isActive: boolean, timeFinish: number }

// # Cases to be considered:
//     -Error Scenarios
//         // 403 ERROR:   Invalid token
//         // 400 ERROR:   Invalid channel
//         // 403 ERROR:   Unauthorised Access [ user is not a member ]
//     -Return Correct Type (x2)
//         - one successful active status check
//         - one successful inactive status check
//         - one successful check for finished standup

// // /////////////////////////////////////////////////// */

// // import functions
// import {
//   authRegisterV3,
//   channelsCreateV3,
//   standupStartV1,
//   standupActiveV1,
//   clearV2,
// } from './testHelpers';

// // import interface
// import {
//   AuthUserId,
//   ChannelId,
//   Time
// } from './interface';

// let mainUser:AuthUserId;
// let thread: ChannelId;
// // eslint-disable-next-line
// let start: Time;

// beforeEach(() => {
//   clearV2();
//   mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   thread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;
//   // eslint-disable-next-line
//   start = standupStartV1(mainUser.token, thread.channelId, 10) as Time;
// });

// describe('Error Casses', () => {
//   test('Invalid Token', () => {
//     const testVar = standupActiveV1(mainUser.token + 'abg', thread.channelId);
//     expect(testVar).toStrictEqual(403);
//   });

//   test('Invalid Channel', () => {
//     const testVar = standupActiveV1(mainUser.token, thread.channelId + 999);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Unauthorised Access [ user is not a member of the channel]', () => {
//     const user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
//     const testVar = standupActiveV1(user1.token, thread.channelId);
//     expect(testVar).toStrictEqual(403);
//   });
// });

// describe('Returns Correct Type', () => {
//   test('one successful active status check', () => {
//     const testVar = standupActiveV1(mainUser.token, thread.channelId);
//     expect(testVar.isActive).toStrictEqual(true);
//   });
//   // test('one successful inactive status check', () => {
//   //   const tempThread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;
//   //   const testVar = standupActiveV1(mainUser.token, tempThread.channelId);
//   //   expect(testVar.timeFinish).toStrictEqual(null);
//   //   expect(testVar.timeFinish).toStrictEqual(null);
//   // });
//   // test('one successful check for finished standup', () => {
//   //   const tempThread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;
//   //   // eslint-disable-next-line
//   //   let tempStart = standupStartV1(mainUser.token, tempThread.channelId, 0) as Time;
//   //   const testVar = standupActiveV1(mainUser.token, tempThread.channelId);
//   //   expect(testVar.isActive).toStrictEqual(false);
//   //   expect(testVar.timeFinish).toStrictEqual(null);
//   // });
// });
