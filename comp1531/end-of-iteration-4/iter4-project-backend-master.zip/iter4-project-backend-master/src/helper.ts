// import functions
import { getData, setData } from './dataStore';
import { getHashOf } from './universalFunctions';

import type { Stats, User } from './interface';
const data = getData();

/*******************************************************
 *                    User's stats                     *
 ******************************************************/

/**
 *  initialiseStatsV1
 *
 *  Creates new object with starting stats for the new user,
 *  and push it the data store.
 *  This function would be triggered by  auth/register/v3.
 *
 *  @param {string} token       - token of a valid user
*/
export function initialiseStatsV1(token : string) {
  const user: User = fetchUser(token);
  const stamp :number = Math.floor(Date.now() / 1000);

  // initialise new object stats for the new user
  const newStats : Stats = {
    uId: user.uId,
    channelsJoined: [{ numChannelsJoined: 0, timeStamp: stamp }],
    dmsJoined: [{ numDmsJoined: 0, timeStamp: stamp }],
    messagesSent: [{ numMessagesSent: 0, timeStamp: stamp }],
  };
  data.stats.push(newStats);
  setData(data);
}

/* ----------------------- numChannelJoined --------------------------------------- */

/**
 *  joinChannelV1
 *
 *  Update the stats of the user if a user join a channel
 *  This function is triggered by:
 *          # /channels/create/v3
 *          # /channel/join/v3
 *
 *  @param {string} token       - token of a valid user
*/
export function joinChannelV1(token: string) {
  const user: User = fetchUser(token);
  const userIndex = fetchPosition(user.uId);

  // retrieve the last updated info user's stats
  const lastData = data.stats[userIndex].channelsJoined.length;
  const joinedChannels = data.stats[userIndex].channelsJoined[lastData - 1].numChannelsJoined;

  // update the data base
  const update = {
    numChannelsJoined: joinedChannels + 1,
    timeStamp: Math.floor(Date.now() / 1000),
  };
  data.stats[userIndex].channelsJoined.push(update);
  setData(data);
}

/**
 *  joinInviteV1
 *
 *  Update the stats of the user if a user join a channel by an successful INVITE
 *  This function is triggered by:
 *          # /channels/invite/v3
 *
 *  @param {string} token       - token of a valid user
*/
export function joinInviteV1(uId: number) {
  // const user = data.users.find(user => user.uId === uId);
  const userIndex = data.stats.findIndex(user => user.uId === uId);

  // retrieve the last updated info user's stats
  const lastData = data.stats[userIndex].channelsJoined.length;
  const joinedChannels = data.stats[userIndex].channelsJoined[lastData - 1].numChannelsJoined;

  // update the data base
  const update = {
    numChannelsJoined: joinedChannels + 1,
    timeStamp: Math.floor(Date.now() / 1000),
  };
  data.stats[userIndex].channelsJoined.push(update);
  setData(data);
}

export function leaveChannelV1(token: string) {
  const user: User = fetchUser(token);
  const userIndex = fetchPosition(user.uId);

  // retrieve the last updated info user's stats
  const lastData = data.stats[userIndex].channelsJoined.length;
  const joinedChannels = data.stats[userIndex].channelsJoined[lastData - 1].numChannelsJoined;

  // update the data base
  const update = {
    numChannelsJoined: joinedChannels - 1,
    timeStamp: Math.floor(Date.now() / 1000),
  };
  data.stats[userIndex].channelsJoined.push(update);
  setData(data);
}

/* --------------------------- numDmsJoined -------------------------------------- */

/**
 *  joinDmV1
 *
 *  Update the stats of the user if a user join a dm
 *
 *  @param {string} token       - token of a valid user
*/
export function joinDmV1(uId: number) {
  const userIndex = fetchPosition(uId);

  // retrieve the last updated info user's stats
  const lastData = data.stats[userIndex].dmsJoined.length;
  const joinedDms = data.stats[userIndex].dmsJoined[lastData - 1].numDmsJoined;

  // update the database
  const update = {
    numDmsJoined: joinedDms + 1,
    timeStamp: Math.floor(Date.now() / 1000),
  };
  data.stats[userIndex].dmsJoined.push(update);
  setData(data);
}

/**
 *  joinMembersDmV1
 *
 * Update the stats of joining members by processing all members
 * array of the given dm.
 * This function is triggered by dm/create/v2
 *
 * @param {number} dmId
 */
export function joinMembersDmV1(dmId: number) {
  const index = data.dms.findIndex(dm => dm.dmId === dmId);
  for (const i of data.dms[index].allMembers) joinDmV1(i.uId);
}

/**
 *  leaveDmV1
 *
 *  Update the stats of the user if a user join a dm
 *  This function is triggered by:dm/leave/v2
 *
 *  @param {number} uId      - token of a valid user
*/
export function leaveDmV1(uId: number) {
  const userIndex = fetchPosition(uId);

  // retrieve the last updated info user's stats
  const lastData = data.stats[userIndex].dmsJoined.length;
  const joinedDms = data.stats[userIndex].dmsJoined[lastData - 1].numDmsJoined;

  // update the database
  const update = {
    numDmsJoined: joinedDms - 1,
    timeStamp: Math.floor(Date.now() / 1000),
  };
  data.stats[userIndex].dmsJoined.push(update);
  setData(data);
}

/**
 *  membersLeaveDmV1
 *
 * Update the database by processing all members in the given Dm.
 * This function is triggered by dm/remove/v2.
 *
 * @param {number} dmId
 */
export function membersLeaveDmV1 (dmId: number) {
  const index = data.dms.findIndex(dm => dm.dmId === dmId);
  for (const i of data.dms[index].allMembers) leaveDmV1(i.uId);
}

/**
 * msgSentV1
 *
 * Update the stats of the user if a user join a dm
 * This function is triggered by:
 *          # message/send/v2
 *
 * @param {string} token - token of a valid user
 */
export function msgSentV1(token:string) {
  const user: User = fetchUser(token);
  const userIndex = fetchPosition(user.uId);
  const lastData = data.stats[userIndex].messagesSent.length;
  const sentMsgs = data.stats[userIndex].messagesSent[lastData - 1].numMessagesSent;
  const update = {
    numMessagesSent: sentMsgs + 1,
    timeStamp: Math.floor(Date.now() / 1000),
  };
  data.stats[userIndex].messagesSent.push(update);
  setData(data);
}

/**
 *  dataStatsV1
 *
 * This functions calculates sum of number of channels, dms and
 * messages that exist in the database. The sum is actually of
 * the denominator that will be used to calculate user's involvement rate.
 *
 */
export function dataStatsV1(): number {
  let count = 0;

  // count messages in the whole database, both dm and channel
  for (const thread of data.channels) {
    count += thread.allMessages.length;
  }
  for (const currDm of data.dms) {
    count += currDm.allMessages.length;
  }

  // count number of channels in the dataStore
  count += data.channels.length;

  // count number of dms in the dataStore
  count += data.dms.length;
  return count;
}

/*******************************************************
 *                    WorkSpace's stats                *
 ******************************************************/

export function initialiseWorkspaceV1() {
  // initialise new object stats for the new user
  const stamp = Math.floor(Date.now() / 1000);
  const newWorkspace = {
    channelsExist: [{ numChannelsExist: 0, timeStamp: stamp }],
    dmsExist: [{ numDmsExist: 0, timeStamp: stamp }],
    messagesExist: [{ numMessagesExist: 0, timeStamp: stamp }],
  };
  data.workspace.push(newWorkspace);
  setData(data);
}

export function updateWorkspaceV1(mode:string) {
  const stamp = Math.floor(Date.now() / 1000);
  switch (mode) {
    case 'channels':{
      const numChannels = data.channels.length;
      const objChannels = { numChannelsExist: numChannels, timeStamp: stamp };
      data.workspace[0].channelsExist.push(objChannels);
      break;
    }
    case 'dms':{
      const numDms = data.dms.length;
      const objDms = { numDmsExist: numDms, timeStamp: stamp };
      data.workspace[0].dmsExist.push(objDms);
      break;
    }
    case 'messages':{
      let numMsgs = 0;
      // count messages in the whole database, both dm and channel
      for (const thread of data.channels) {
        numMsgs += thread.allMessages.length;
      }
      for (const currDm of data.dms) {
        numMsgs += currDm.allMessages.length;
      }
      const objMsgs = { numMessagesExist: numMsgs, timeStamp: stamp };
      data.workspace[0].messagesExist.push(objMsgs);
      break;
    }
  }
  setData(data);
}

export function activeUsersV1(): number {
  let activeCount = 0;
  for (const curr of data.stats) {
    const channelIndex: number = curr.channelsJoined.length - 1;
    const dmIndex: number = curr.dmsJoined.length - 1;
    const factor : number = curr.channelsJoined[channelIndex].numChannelsJoined + curr.dmsJoined[dmIndex].numDmsJoined;
    if (factor > 0) activeCount++;
  }
  return activeCount;
}

/** ----------------------- HELPER FUNCTIONS --------------------------- */

/**
 *  Given token is used to fetch token owners' details from dataStore
 *  @param {string} token       - token of a valid user
 */
function fetchUser(token:string) {
  const hashedToken: string = getHashOf(token);
  const user = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  return user;
}

/**
 *  Given user's id is used to locate the index of the user's stats.
 *  @param {number} uId       - id of a valid user
*/
function fetchPosition(uId:number): number {
  const index: number = data.stats.findIndex(user => user.uId === uId);
  return index;
}
