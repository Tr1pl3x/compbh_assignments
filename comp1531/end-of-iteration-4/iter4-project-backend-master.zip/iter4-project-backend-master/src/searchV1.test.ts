
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { channelsCreateV3, clearV2, authRegisterV3, searchV1, messageSendV2, dmCreateV2, messageSenddmV2 } from './testHelpers';
// import type { AuthUserId, ChannelId, DmID, Reacts } from './interface';

// let newPerson: AuthUserId;
// let dmCreator: AuthUserId;
// let newPerson2: AuthUserId;
// let channel1: ChannelId;
// let dm1: DmID;

// beforeEach(() => {
//   clearV2();
//   newPerson = authRegisterV3('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
// });

// describe('Testing different parameters that covers every line of code', () => {
//   test('query string is too long', () => {
//     expect(searchV1(newPerson.token, 'a'.repeat(1001))).toStrictEqual(400);
//   });
//   test('query string is empty', () => {
//     expect(searchV1(newPerson.token, '')).toStrictEqual(400);
//   });
//   test('invalid token', () => {
//     expect(searchV1('a', 'test message!')).toStrictEqual(403);
//   });
//   test('valid parameters, 1 message in channel', () => {
//     channel1 = channelsCreateV3(newPerson.token, 'New Channel', true);
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello world');
//     expect(searchV1(newPerson.token, 'Hello world')).toStrictEqual({
//       messages: expect.arrayContaining([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//       ]),
//     });
//   });
//   test('valid parameters, 1 message in DM', () => {
//     dmCreator = authRegisterV3('sammyjjj@gmail.com', 'pppassword', 'David', 'Peter') as AuthUserId;
//     newPerson2 = authRegisterV3('schweppes@gmail.com', 'bubbles', 'Sprite', 'Waters') as AuthUserId;
//     dm1 = dmCreateV2(dmCreator.token, [newPerson.authUserId, newPerson2.authUserId]);
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     expect(searchV1(newPerson.token, 'Hello world')).toStrictEqual({
//       messages: expect.arrayContaining([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//       ]),
//     });
//   });
//   test('valid parameters, many messages in DM', () => {
//     dmCreator = authRegisterV3('sammyjjj@gmail.com', 'pppassword', 'David', 'Peter') as AuthUserId;
//     newPerson2 = authRegisterV3('schweppes@gmail.com', 'bubbles', 'Sprite', 'Waters') as AuthUserId;
//     dm1 = dmCreateV2(dmCreator.token, [newPerson.authUserId, newPerson2.authUserId]);
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     expect(searchV1(newPerson.token, 'Hello world')).toStrictEqual({
//       messages: ([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//       ]),
//     });
//   });
//   test('valid parameters, many message in channel', () => {
//     channel1 = channelsCreateV3(newPerson.token, 'New Channel', true);
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello world');
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello world');
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello world');
//     expect(searchV1(newPerson.token, 'Hello world')).toStrictEqual({
//       messages: expect.arrayContaining([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//       ]),
//     });
//   });
//   test('valid parameters, many message in channel and DM', () => {
//     channel1 = channelsCreateV3(newPerson.token, 'New Channel', true);
//     dmCreator = authRegisterV3('sammyjjj@gmail.com', 'pppassword', 'David', 'Peter') as AuthUserId;
//     newPerson2 = authRegisterV3('schweppes@gmail.com', 'bubbles', 'Sprite', 'Waters') as AuthUserId;
//     dm1 = dmCreateV2(dmCreator.token, [newPerson.authUserId, newPerson2.authUserId]);
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello world');
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello world');
//     messageSendV2(newPerson.token, channel1.channelId, 'Hello wold');
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hello world');
//     messageSenddmV2(newPerson.token, dm1.dmId, 'Hel wor');
//     expect(searchV1(newPerson.token, 'Hello world')).toStrictEqual({
//       messages: expect.arrayContaining([
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//         expect.objectContaining({
//           messageId: expect.any(Number),
//           uId: expect.any(Number),
//           message: expect.any(String),
//           timeSent: expect.any(Number),
//           reacts: expect.any(Array<Reacts>),
//           isPinned: expect.any(Boolean)
//         }),
//       ]),
//     });
//   });
// });
