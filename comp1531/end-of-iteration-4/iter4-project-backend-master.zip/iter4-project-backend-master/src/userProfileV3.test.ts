
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, userProfileV3, clearV2 } from './testHelpers';
// import type { AuthUserId, UserProfile } from './interface';

// let user1: AuthUserId; // authUserId
// let user2: AuthUserId; // uId
// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
// });

// describe('userProfileV3 error scenario', () => {
//   test('invalid token', () => {
//     expect(userProfileV3(user1.token + 3, user2.authUserId)).toStrictEqual(403);
//   });
//   test('invalid uId', () => {
//     expect(userProfileV3(user1.token, user2.authUserId + 3)).toStrictEqual(400);
//   });
//   test('invalid token and uId', () => {
//     expect(userProfileV3(user1.token + 3, user2.authUserId + 3)).toStrictEqual(403);
//   });
//   test('empty token', () => {
//     expect(userProfileV3('', user2.authUserId)).toStrictEqual(403);
//   });
// });

// describe('userProfileV3 display valid user data', () => {
//   test('check uId data', () => {
//     const userprofile = userProfileV3(user1.token, user2.authUserId) as UserProfile;
//     expect(userprofile).toStrictEqual({
//       user: {
//         uId: user2.authUserId,
//         nameFirst: userprofile.user.nameFirst,
//         nameLast: userprofile.user.nameLast,
//         email: userprofile.user.email,
//         handleStr: userprofile.user.handleStr,
//       }
//     });
//   });
//   test('check authId data', () => {
//     const userprofile = userProfileV3(user1.token, user1.authUserId) as UserProfile;
//     expect(userprofile).toStrictEqual({
//       user: {
//         uId: user1.authUserId,
//         nameFirst: userprofile.user.nameFirst,
//         nameLast: userprofile.user.nameLast,
//         email: userprofile.user.email,
//         handleStr: userprofile.user.handleStr,
//       }
//     });
//   });
// });
