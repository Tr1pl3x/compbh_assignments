
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, channelsCreateV3, clearV2, channelInviteV3 } from './testHelpers';
// import type { AuthUserId, ChannelId, Messages, DmID, MessageReturn } from './interface';
// import { channelMessagesV3, messageSendV2, messagePinV1, messageUnpinV1, messageSenddmV2, dmCreateV2, dmMessagesV2 } from './testHelpers';

// let dmcreator: AuthUserId;
// let user1: AuthUserId;
// let user2: AuthUserId;
// let channel1: ChannelId;
// let dm1: DmID;
// let sendMessage1: MessageReturn;
// let sendMessageDM1: MessageReturn;
// beforeEach(() => {
//   clearV2();
//   dmcreator = authRegisterV3('creator@gmail.com', 'Password', 'Tynan', 'Sylvester') as AuthUserId;
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
//   channel1 = channelsCreateV3(user1.token, 'New Channel', true) as ChannelId;
//   dm1 = dmCreateV2(dmcreator.token, [user1.authUserId, user2.authUserId]) as DmID;
//   sendMessage1 = messageSendV2(user1.token, channel1.channelId, 'testmessage') as MessageReturn;
//   sendMessageDM1 = messageSenddmV2(user1.token, dm1.dmId, 'DMtestmessage') as MessageReturn;
// });
// describe('messageUnpinV1 Tests', () => {
//   test('Error: empty token', () => {
//     expect(messageUnpinV1('', sendMessage1.messageId)).toStrictEqual(403);
//   });
//   test('Error: invalid token', () => {
//     expect(messageUnpinV1(user1.token + 1, sendMessage1.messageId)).toStrictEqual(403);
//   });
//   test('Error: invalid messageId', () => {
//     expect(messageUnpinV1(user1.token, sendMessage1.messageId + 999)).toStrictEqual(400);
//   });
//   test('Error: member attempts to unpin another user message', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     messagePinV1(user1.token, sendMessage1.messageId);
//     expect(messageUnpinV1(user2.token, sendMessage1.messageId)).toStrictEqual(403);
//   });
//   test('Error: member attempts to unpin their message(no owner permission)', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     const sendMessage2 = messageSendV2(user2.token, channel1.channelId, 'from user 2') as MessageReturn;
//     messagePinV1(user1.token, sendMessage2.messageId);
//     expect(messageUnpinV1(user2.token, sendMessage1.messageId)).toStrictEqual(403);
//   });
//   test('Error: owner attempts to unpin an unpinned message', () => {
//     expect(messageUnpinV1(user1.token, sendMessage1.messageId)).toStrictEqual(400);
//   });
//   test('Error: DM invalid messageId', () => {
//     expect(messageUnpinV1(user1.token, sendMessageDM1.messageId + 999)).toStrictEqual(400);
//   });
//   test('Error: DM member attempts to unpin another user message', () => {
//     messagePinV1(dmcreator.token, sendMessage1.messageId);
//     expect(messageUnpinV1(user2.token, sendMessageDM1.messageId)).toStrictEqual(403);
//   });
//   test('Error: DM member attempts to unpin their message(no owner permission)', () => {
//     messagePinV1(dmcreator.token, sendMessage1.messageId);
//     expect(messageUnpinV1(user1.token, sendMessageDM1.messageId)).toStrictEqual(403);
//   });
//   test('Error: DM owner attempts to unpin an unpinned message', () => {
//     expect(messageUnpinV1(dmcreator.token, sendMessageDM1.messageId)).toStrictEqual(400);
//   });
//   test('Valid: channel owner unpins their message', () => {
//     messagePinV1(user1.token, sendMessage1.messageId);
//     messageUnpinV1(user1.token, sendMessage1.messageId);
//     const newMessage = channelMessagesV3(user1.token, channel1.channelId, 0) as Messages;
//     expect(newMessage).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             isPinned: false,
//           })
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
//   test('Valid: channel owner unpins member message', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     const sendMessage2 = messageSendV2(user2.token, channel1.channelId, 'Hi im from user 2') as MessageReturn;
//     messagePinV1(user1.token, sendMessage2.messageId);
//     messageUnpinV1(user1.token, sendMessage2.messageId);
//     const newMessage = channelMessagesV3(user1.token, channel1.channelId, 0) as Messages;
//     expect(newMessage).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             isPinned: false
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
//   test('Valid: DM owner unpins their message', () => {
//     messagePinV1(dmcreator.token, sendMessageDM1.messageId);
//     messageUnpinV1(dmcreator.token, sendMessageDM1.messageId);
//     const newMessage = dmMessagesV2(user1.token, dm1.dmId, 0) as Messages;
//     expect(newMessage).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             isPinned: false
//           })
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
//   test('Valid: DM owner unpins member message', () => {
//     const sendMessageDM2 = messageSenddmV2(user2.token, dm1.dmId, 'Hi im from user 2') as MessageReturn;
//     messagePinV1(dmcreator.token, sendMessageDM2.messageId);
//     messageUnpinV1(dmcreator.token, sendMessageDM2.messageId);
//     const newMessage = dmMessagesV2(user1.token, dm1.dmId, 0) as Messages;
//     expect(newMessage).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             isPinned: false
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
// });
