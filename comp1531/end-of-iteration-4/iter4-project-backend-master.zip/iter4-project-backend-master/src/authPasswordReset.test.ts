
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authPasswordResetV1 } from './testHelpers';
// import { clearV2 } from './testHelpers';

// // const ERROR = { error: expect.any(String) };
// // const resetCode = Math.floor(Math.random() * 1000000000).toString();

// describe('auth/passwordreset/request/v1', () => {
//   beforeEach(() => {
//     clearV2();
//   });

//   // Tests for valid email
//   describe('testng for 400 error', () => {
//     test('Invalid resetCode', () => {
//       // Register user
//       // const user1 = authRegisterV3('evan@gmail.com', 'passcode123', 'John', 'Smith');
//       // Request password reset
//       // console.log(user1)
//       const result = authPasswordResetV1('', 'newpasscode');
//       console.log(result);
//       expect(result).toStrictEqual(400);
//     });

//     test('Invalid password', () => {
//       // Register user
//       // const user1 = authRegisterV3('evan@gmail.com', 'passcode123', 'John', 'Smith');
//       // Request password reset
//       const result = authPasswordResetV1('123456', 'newp');
//       expect(result).toStrictEqual(400);
//     });

//     // test('Requesting password reset for unregistered user', () => {
//     //   const result = authPasswordRequestV1(email);
//     //   expect(result).toStrictEqual({ message: 'Password reset code sent to your email.' });

//     //   // TODO: Retrieve password reset code from email and store it for later use

//     //   // TODO: Check that user is not logged out of any sessions (as they are not registered)
//     // });
//   });

//   //   // Tests for email already in use
//   //   describe('Testing for email already in use', () => {
//   //     const email = 'jonny@gmail.com';
//   //     test('Requesting password reset for registered user with already existing email', () => {
//   //       authRegisterV3(email, 'Pass1234', 'John', 'Smith');

//   //       // Attempt to register user with same email
//   //       expect(authRegisterV3(email, 'Password', 'Johnny', 'Sins')).toStrictEqual({ error: 'Email already in use' });

// //       // Attempt to register user with same email again (should still fail)
// //       authRegisterV3(email, 'Pass1234', 'John', 'Smith');
// //       const newUser = authRegisterV3(email, 'Password', 'Johnny', 'Sins');
// //       expect(newUser).toStrictEqual({ error: 'Email already in use' });
// //     });
// //   });
// });
