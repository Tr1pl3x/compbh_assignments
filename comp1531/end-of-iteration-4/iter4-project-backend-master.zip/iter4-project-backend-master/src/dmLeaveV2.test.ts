
/**
 * For iteration 4, this test file is commented.
*/

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});
/* //////////////// dmLeaveV2 ////////////////////

// # Passing Parameters:{ token: string, dmId: number }

// # Return type if no error: {}

// # Cases to be considered:
//     -Error Scenarios
//         // 403 ERROR:  invalid token
//         // 400 ERROR:  invalid dmId
//         // 403 ERROR:  unauthorised access to remove
//     -Return Correct Type
// /////////////////////////////////////////////////// */

// // import functions
// import {
//   authRegisterV3,
//   dmCreateV2,
//   dmLeaveV2,
//   clearV2,
// } from './testHelpers';

// // import interface
// import {
//   AuthUserId,
//   DmID,
// } from './interface';

// let mainUser: AuthUserId;
// let user1: AuthUserId;
// let user2: AuthUserId;
// let dm: DmID;

// beforeEach(() => {
//   clearV2();
//   mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
//   user2 = authRegisterV3('blue@gmail.com', 'psascode', 'Blue', 'Ranger') as AuthUserId;
//   dm = dmCreateV2(mainUser.token, [user1.authUserId, user2.authUserId])as DmID;
// });

// describe('Error Casses', () => {
//   test('Invalid token', () => {
//     const testVar = dmLeaveV2(mainUser.token + 'abg', dm.dmId);
//     expect(testVar).toStrictEqual(403);
//   });
//   test('Invalid Dm ID', () => {
//     const testVar = dmLeaveV2(mainUser.token, dm.dmId + 999);
//     expect(testVar).toStrictEqual(400);
//   });
//   test('Unauthorised access to a valid dm', () => {
//     const newUser = authRegisterV3('jj@gmail.com', 'passcoed', 'eblu', 'bad') as AuthUserId;
//     const testVar = dmLeaveV2(newUser.token, dm.dmId);
//     expect(testVar).toStrictEqual(403);
//   });
// });

// describe('Returns Correct Type', () => {
//   test('successful remove', () => {
//     const testVar = dmLeaveV2(user2.token, dm.dmId);
//     expect(testVar).toStrictEqual({});
//   });
//   test('successful remove by owner', () => {
//     const testVar = dmLeaveV2(mainUser.token, dm.dmId);
//     expect(testVar).toStrictEqual({});
//   });
// });
