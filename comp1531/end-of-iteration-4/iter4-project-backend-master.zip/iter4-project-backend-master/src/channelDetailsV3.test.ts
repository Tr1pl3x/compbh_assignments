
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

/// ///////////// channelDetailsV3 ////////////////////

// Parameters:( token: string , channelId: number )

// Return type if no error: {
//     name: string,
//     isPublic: boolean,
//     ownerMembers: Users[],
//     allMembers: Users[],
// }

// Cases to be considered:
//     -Error Scenarios
//         // 403 ERROR: Invalid token
//         // 400 ERROR: Invalid channelId
//         // 403 ERROR: Valid channelId + authUserId have no access
//     -Return Correct Type
/// /////////////////////////////////////////////////////

// import {
//   authRegisterV3,
//   channelsCreateV3,
//   channelDetailsV3,
//   clearV2
// } from './testHelpers';

// import {
//   AuthUserId,
//   Channels
// } from './interface';

// let user: AuthUserId;
// let newUser: AuthUserId;
// let thread: Channels;

// beforeEach(() => {
//   clearV2();
//   user = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   thread = channelsCreateV3(user.token, 'myChannel', true) as Channels;
// });

// describe('Error Casses', () => {
//   test('invalid token', () => {
//     const testVar = channelDetailsV3(user.token + 'ABG', thread.channelId);
//     expect(testVar).toStrictEqual(403);
//   });

//   test('invalid channelID', () => {
//     const testVar = channelDetailsV3(user.token, thread.channelId * 999);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Test: unauthorized access ', () => {
//     newUser = authRegisterV3('hellloQT@gmail.com', 'waasup', 'Shaw', 'Tea') as AuthUserId;
//     const testVar = channelDetailsV3(newUser.token, thread.channelId);
//     expect(testVar).toStrictEqual(403);
//   });
// });

// describe('Returns Correct Type', () => {
//   test('correct data', () => {
//     const testVar = channelDetailsV3(user.token, thread.channelId);
//     expect(testVar).toStrictEqual(
//       expect.objectContaining({
//         name: 'myChannel',
//         isPublic: true,
//         ownerMembers: expect.arrayContaining([
//           expect.objectContaining({
//             uId: expect.any(Number),
//             email: expect.any(String),
//             nameFirst: expect.any(String),
//             nameLast: expect.any(String),
//             handleStr: expect.any(String),
//           })
//         ]),
//         allMembers: expect.arrayContaining([
//           expect.objectContaining({
//             uId: expect.any(Number),
//             email: expect.any(String),
//             nameFirst: expect.any(String),
//             nameLast: expect.any(String),
//             handleStr: expect.any(String),
//           })
//         ]),
//       })
//     );
//   });
// });
