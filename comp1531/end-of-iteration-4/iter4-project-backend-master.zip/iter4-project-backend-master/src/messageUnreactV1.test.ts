
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import {
//   channelsCreateV3,
//   clearV2,
//   authRegisterV3,
//   messageSendV2,
//   messageReact,
//   dmCreateV2,
//   messageSenddmV2,
//   messageUnreact
// } from './testHelpers';

// import type {
//   AuthUserId,
//   ChannelId,
//   MessageReturn,
//   DmID
// } from './interface';

// let newPerson: AuthUserId;
// let newPerson2: AuthUserId;
// let channelId: ChannelId;
// let dm1: DmID;
// let messageId: MessageReturn;
// let messageId2: MessageReturn;

// beforeEach(() => {
//   clearV2();
//   newPerson = authRegisterV3('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
//   newPerson2 = authRegisterV3('sammyg@gmail.com', 'pppassword', 'Samuel', 'Grog') as AuthUserId;
//   channelId = channelsCreateV3(newPerson.token, 'New Channel', false);
//   messageId = messageSendV2(newPerson.token, channelId.channelId, 'this is a message');
// });

// describe('Testing different parameters for channel messages', () => {
//   test('reactId is not a valid ID', () => {
//     messageReact(newPerson.token, messageId.messageId, 1);
//     expect(messageUnreact(newPerson.token, messageId.messageId, 4)).toStrictEqual(400);
//   });
//   test('message does not contain a react with ID', () => {
//     expect(messageUnreact(newPerson.token, messageId.messageId, 1)).toStrictEqual(400);
//   });
//   test('messageId is not valid', () => {
//     expect(messageUnreact(newPerson.token, -1, 1)).toStrictEqual(400);
//   });
//   test('invalid token not valid', () => {
//     expect(messageUnreact('abc', messageId.messageId, 1)).toStrictEqual(403);
//   });
//   test('valid parameters', () => {
//     messageReact(newPerson.token, messageId.messageId, 1);
//     expect(messageUnreact(newPerson.token, messageId.messageId, 1)).toStrictEqual({});
//   });
//   test('User has not reacted', () => {
//     messageReact(newPerson.token, messageId.messageId, 1);
//     expect(messageUnreact(newPerson2.token, messageId.messageId, 1)).toStrictEqual(400);
//   });
//   test('DM message does not contain a react with ID', () => {
//     dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
//     messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
//     expect(messageUnreact(newPerson.token, messageId2.messageId, 1)).toStrictEqual(400);
//   });
//   test('Valid DM parameters', () => {
//     dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
//     messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
//     messageReact(newPerson.token, messageId2.messageId, 1);
//     expect(messageUnreact(newPerson.token, messageId2.messageId, 1)).toStrictEqual({});
//   });
//   test('DM user has not reacted', () => {
//     dm1 = dmCreateV2(newPerson.token, [newPerson.authUserId, newPerson2.authUserId]);
//     messageId2 = messageSenddmV2(newPerson.token, dm1.dmId, 'this is a message');
//     messageReact(newPerson.token, messageId2.messageId, 1);
//     expect(messageUnreact(newPerson2.token, messageId2.messageId, 1)).toStrictEqual(400);
//   });
// });
