
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// /* //////////////// standupStartV1 ////////////////////

// #Passing Parameters:( token: string, channelId: number, length: number )

// # Return type if no error: { isActive: boolean, timeFinish: number }

// # Cases to be considered:
//     -Error Scenarios
//         // 403 ERROR:   Invalid token
//         // 400 ERROR:   Invalid channel
//         // 400 ERROR:   Negative Length
//         // 400 ERROR:   Active standup already exists
//         // 403 ERROR:   Unauthorised Access [ user is not a member ]
//     -Return Correct Type (x2)
//         - one successful standup start
//         - two successive standup starts from a channel
//         - mulitple successful standup starts

// // /////////////////////////////////////////////////// */

// // import functions
// import {
//   authRegisterV3,
//   channelsCreateV3,
//   standupStartV1,
//   clearV2,
// } from './testHelpers';

// // import interface
// import {
//   AuthUserId,
//   ChannelId,
//   Time
// } from './interface';

// let mainUser:AuthUserId;
// let thread: ChannelId;

// beforeEach(() => {
//   clearV2();
//   mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   // eslint-disable-next-line
//   thread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;
// });

// describe('Error Casses', () => {
//   test('Invalid Token', () => {
//     const testVar = standupStartV1(mainUser.token + 'abg', thread.channelId, 13);
//     expect(testVar).toStrictEqual(403);
//   });

//   test('Invalid Channel', () => {
//     const testVar = standupStartV1(mainUser.token, thread.channelId + 999, 13);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Negative Length', () => {
//     const testVar = standupStartV1(mainUser.token, thread.channelId, -13);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Active Standup already exists', () => {
//     // eslint-disable-next-line
//     const dummy = standupStartV1(mainUser.token, thread.channelId, 10) as Time;
//     const testVar = standupStartV1(mainUser.token, thread.channelId, 20);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Unauthorised Access [ user is not a member of the channel]', () => {
//     const user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
//     const testVar = standupStartV1(user1.token, thread.channelId, 20);
//     expect(testVar).toStrictEqual(403);
//   });
// });

// describe('Returns Correct Type', () => {
//   test('one successful standup start ', () => {
//     const testVar = standupStartV1(mainUser.token, thread.channelId, 10);
//     const expectation : number = 10 + Date.now() / 1000;
//     expect(Math.abs(expectation - testVar.timeFinish)).toBeLessThanOrEqual(5);
//   });
//   // test('two successive standup starts from a channel', () => {
//   //   // eslint-disable-next-line
//   //   const tempStart = standupStartV1(mainUser.token, thread.channelId, 0);
//   //   const testVar = standupStartV1(mainUser.token, thread.channelId, 10);
//   //   const expectation : number = 10 + Date.now() / 1000;
//   //   expect(Math.abs(expectation - testVar.timeFinish)).toBeLessThanOrEqual(5);
//   // });
//   // test('mulitple successful standup start ', () => {
//   //   const thread1 = channelsCreateV3(mainUser.token, 'myChannel1', true) as ChannelId;
//   //   const thread2 = channelsCreateV3(mainUser.token, 'myChannel2', true) as ChannelId;

//   //   const testVar1 = standupStartV1(mainUser.token, thread.channelId, 10);
//   //   let expectation : number = 10 + Date.now() / 1000;
//   //   expect(Math.abs(expectation - testVar1.timeFinish)).toBeLessThanOrEqual(5);

//   //   const testVar2 = standupStartV1(mainUser.token, thread1.channelId, 10);
//   //   expectation = 10 + Date.now() / 1000;
//   //   expect(Math.abs(expectation - testVar2.timeFinish)).toBeLessThanOrEqual(5);

//   //   const testVar3 = standupStartV1(mainUser.token, thread2.channelId, 10);
//   //   expectation = 10 + Date.now() / 1000;
//   //   expect(Math.abs(expectation - testVar3.timeFinish)).toBeLessThanOrEqual(5);
//   // });
// });
