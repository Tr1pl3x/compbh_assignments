
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, channelsCreateV3, clearV2, channelInviteV3, channelDetailsV3 } from './testHelpers';
// import type { AuthUserId, ChannelId } from './interface';

// let user1: AuthUserId;
// let user2: AuthUserId;
// let user3: AuthUserId;
// let channel1: ChannelId;
// let channel2: ChannelId;
// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '12345pas', 'Hayden', 'Smith') as AuthUserId;
//   user3 = authRegisterV3('test3@gmail.com', '1231231234', 'Dean', 'Wunder') as AuthUserId;
//   channel1 = channelsCreateV3(user1.token, 'New Channel', true) as ChannelId;
//   channel2 = channelsCreateV3(user2.token, 'New channel2lId', true) as ChannelId;
// });
// afterEach(() => {
//   clearV2();
// });

// describe('channelInviteV3 Tests', () => {
//   test('Error: empty token', () => {
//     expect(channelInviteV3('', channel1.channelId + 3, user2.authUserId)).toEqual(403);
//   });
//   test('Error: invalid channelId ', () => {
//     expect(channelInviteV3(user1.token, channel1.channelId + 3, user2.authUserId)).toEqual(400);
//   });
//   test('Error: invalid uId ', () => {
//     expect(channelInviteV3(user1.token, channel1.channelId, user2.authUserId + 3)).toEqual(400);
//   });
//   test('Error: invalid token ', () => {
//     expect(channelInviteV3(user1.token + 3, channel1.channelId, user2.authUserId)).toEqual(403);
//   });
//   test('Error: authId and uId identical', () => {
//     expect(channelInviteV3(user1.token, channel1.channelId, user1.authUserId)).toEqual(400);
//   });
//   test('Error: uId exists in the channel', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     expect(channelInviteV3(user1.token, channel1.channelId, user2.authUserId)).toEqual(400);
//   });
//   test('Error: authId does not exist in channel, but channelId valid', () => {
//     expect(channelInviteV3(user1.token, channel2.channelId, user3.authUserId)).toEqual(403);
//   });
//   test('Valid: Valid return value', () => {
//     expect(channelInviteV3(user1.token, channel1.channelId, user2.authUserId)).toEqual({});
//   });
//   test('Valid: User invited then exists in the channel', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     const channelDetails = channelDetailsV3(user1.token, channel1.channelId);
//     expect(channelDetails.allMembers).toStrictEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         )
//       ])
//     );
//   });
//   test('Two users invited then exists in the channel', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     channelInviteV3(user1.token, channel1.channelId, user3.authUserId);
//     const channelDetails = channelDetailsV3(user1.token, channel1.channelId);
//     expect(channelDetails.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         ),
//         expect.objectContaining(
//           {
//             uId: user3.authUserId
//           }
//         )
//       ])
//     );
//   });
//   test('Two users invited, the second user invites a third user', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     channelInviteV3(user2.token, channel1.channelId, user3.authUserId);
//     const channelDetails = channelDetailsV3(user1.token, channel1.channelId);
//     expect(channelDetails.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         ),
//         expect.objectContaining(
//           {
//             uId: user3.authUserId
//           }
//         )
//       ])
//     );
//   }); test('Valid return value', () => {
//     expect(channelInviteV3(user1.token, channel1.channelId, user2.authUserId)).toStrictEqual({});
//   });
//   test('User invited then exists in the channel', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     const channelDetails = channelDetailsV3(user1.token, channel1.channelId);
//     expect(channelDetails.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         )
//       ])
//     );
//   });
//   test('Two users invited then exists in the channel', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     channelInviteV3(user1.token, channel1.channelId, user3.authUserId);
//     const channelDetails = channelDetailsV3(user1.token, channel1.channelId);
//     expect(channelDetails.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         ),
//         expect.objectContaining(
//           {
//             uId: user3.authUserId
//           }
//         )
//       ])
//     );
//   });
//   test('Two users invited, the second user invites a third user', () => {
//     channelInviteV3(user1.token, channel1.channelId, user2.authUserId);
//     channelInviteV3(user2.token, channel1.channelId, user3.authUserId);
//     const channelDetails = channelDetailsV3(user1.token, channel1.channelId);
//     expect(channelDetails.allMembers).toEqual(
//       expect.arrayContaining([
//         expect.objectContaining(
//           {
//             uId: user2.authUserId
//           }
//         ),
//         expect.objectContaining(
//           {
//             uId: user3.authUserId
//           }
//         )
//       ])
//     );
//   });
// });
// // test('valid test', () => {
// //   expect(2 + 2).toStrictEqual(4);
// // });
