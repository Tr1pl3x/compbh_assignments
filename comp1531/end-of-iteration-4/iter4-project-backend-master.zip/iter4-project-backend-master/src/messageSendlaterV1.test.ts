
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { authRegisterV3, channelsCreateV3, clearV2 } from './testHelpers';
// import type { AuthUserId, ChannelId } from './interface';
// import { channelMessagesV3, messageSendlaterV1 } from './testHelpers';

// let user1: AuthUserId;
// let user2: AuthUserId;
// let channel1: ChannelId;
// let timeSent: number;
// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
//   channel1 = channelsCreateV3(user1.token, 'New Channel', true) as ChannelId;
//   timeSent = Math.floor(Date.now() / 1000) + 5;
// });
// describe('messageSendlaterV1 Tests', () => {
//   test('Error: invalid token', () => {
//     expect(messageSendlaterV1(user1.token + 1, channel1.channelId, 'inputmessage', timeSent)).toStrictEqual(403);
//   });
//   test('Error: empty token', () => {
//     expect(messageSendlaterV1('', channel1.channelId + 1, 'inputmessage', timeSent)).toStrictEqual(403);
//   });
//   test('Error: invalid channelId', () => {
//     expect(messageSendlaterV1(user1.token, channel1.channelId + 1, 'inputmessage', timeSent)).toStrictEqual(400);
//   });
//   test('Message length > 1000', () => {
//     expect(messageSendlaterV1(user1.token, channel1.channelId, 'a'.repeat(1001), timeSent)).toStrictEqual(400);
//   });
//   test('Error: authId does not exist in channel, but channelId valid', () => {
//     const channel2 = channelsCreateV3(user2.token, 'New Channel2', true) as ChannelId;
//     expect(messageSendlaterV1(user1.token, channel2.channelId, 'inputmessage', timeSent)).toStrictEqual(403);
//   });
//   test('Error: Message length < 1', () => {
//     expect(messageSendlaterV1(user1.token, channel1.channelId, '', timeSent)).toStrictEqual(400);
//   });

//   test('Error: timeSent is a time in the past', () => {
//     timeSent = Math.floor(Date.now() / 1000) - 2;
//     expect(messageSendlaterV1(user1.token, channel1.channelId, 'inputmessage', timeSent)).toStrictEqual(400);
//   });

//   test('Valid: send message after 5 seconds', () => {
//     const timeSent = Math.floor(Date.now() / 1000) + 5;
//     messageSendlaterV1(user1.token, channel1.channelId, 'Hello World', timeSent);
//     // Check that the message is not yet in the channel
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: [],
//         start: 0,
//         end: -1,
//       })
//     );
//     const delay = timeSent * 1000 - Date.now();
//     // Blocking delay using while loop
//     const start = Date.now();
//     while (Date.now() - start < delay) {
//       // Do nothing; blocking the execution
//     }
//     expect(channelMessagesV3(user1.token, channel1.channelId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Hello World',
//             timeSent: expect.any(Number),
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
// });
