
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});// import { authRegisterV3, clearV2 } from './testHelpers';

// import type { AuthUserId, DmID } from './interface';
// import { messageSendLaterDmV1, dmCreateV2, dmMessagesV2 } from './testHelpers';

// let user1: AuthUserId;
// let user2: AuthUserId;
// let user3: AuthUserId;
// let timeSent: number;
// let dmCreator: AuthUserId;
// let dm1: DmID;

// beforeEach(() => {
//   clearV2();
//   user1 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//   user2 = authRegisterV3('test2@gmail.com', '123456', 'Hayden', 'Smith') as AuthUserId;
//   dmCreator = authRegisterV3('creator@gmail.com', 'Password', 'Tynan', 'Sylvester') as AuthUserId;
//   dm1 = dmCreateV2(dmCreator.token, [user1.authUserId, user2.authUserId]) as DmID;
//   timeSent = Math.floor(Date.now() / 1000) + 5;
// });
// describe('messageSendlaterV1 Tests', () => {
//   test('Error: invalid token', () => {
//     expect(messageSendLaterDmV1(user1.token + 1, dm1.dmId, 'inputmessage', timeSent)).toStrictEqual(403);
//   });
//   test('Error: empty token', () => {
//     expect(messageSendLaterDmV1('', dm1.dmId + 1, 'inputmessage', timeSent)).toStrictEqual(403);
//   });
//   test('Error: invalid dmId', () => {
//     expect(messageSendLaterDmV1(user1.token, dm1.dmId + 1, 'inputmessage', timeSent)).toStrictEqual(400);
//   });
//   test('Message length > 1000', () => {
//     expect(messageSendLaterDmV1(user1.token, dm1.dmId, 'a'.repeat(1001), timeSent)).toStrictEqual(400);
//   });
//   test('Error: authId does not exist in DM, but channelId valid', () => {
//     user3 = authRegisterV3('test@gmail.com', 'password', 'Rani', 'Jiang') as AuthUserId;
//     expect(messageSendLaterDmV1(user3.token, dm1.dmId, 'inputmessage', timeSent)).toStrictEqual(403);
//   });
//   test('Error: Message length < 1', () => {
//     expect(messageSendLaterDmV1(user1.token, dm1.dmId, '', timeSent)).toStrictEqual(400);
//   });

//   test('Error: timeSent is a time in the past', () => {
//     timeSent = Math.floor(Date.now() / 1000) - 2;
//     expect(messageSendLaterDmV1(user1.token, dm1.dmId, 'inputmessage', timeSent)).toStrictEqual(400);
//   });

//   test('Valid: send message after 5 seconds', () => {
//     const timeSent = Math.floor(Date.now() / 1000) + 5;
//     messageSendLaterDmV1(user1.token, dm1.dmId, 'Hello World', timeSent);
//     // Check that the message is not yet in the channel
//     expect(dmMessagesV2(user1.token, dm1.dmId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: [],
//         start: 0,
//         end: -1,
//       })
//     );
//     const delay = timeSent * 1000 - Date.now();
//     // Blocking delay using while loop
//     const start = Date.now();
//     while (Date.now() - start < delay) {
//       // Do nothing; blocking the execution
//     }
//     expect(dmMessagesV2(user1.token, dm1.dmId, 0)).toStrictEqual(
//       expect.objectContaining({
//         messages: expect.arrayContaining([
//           expect.objectContaining({
//             messageId: expect.any(Number),
//             uId: user1.authUserId,
//             message: 'Hello World',
//             timeSent: expect.any(Number),
//           }),
//         ]),
//         start: 0,
//         end: -1,
//       })
//     );
//   });
// });
