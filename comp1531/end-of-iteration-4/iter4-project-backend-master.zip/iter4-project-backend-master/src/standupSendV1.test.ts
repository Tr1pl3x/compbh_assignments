
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// /* //////////////// standupSendV1 ////////////////////

// #Passing Parameters:(token: string, channelId: number, message: string)

// # Return type if no error: {}

// # Cases to be considered:
//     -Error Scenarios
//         // 403 ERROR:   Invalid token
//         // 400 ERROR:   Invalid channel
//         // 400 ERROR:   Invalid message length
//         // 400 ERROR:   Active standup is not running
//         // 403 ERROR:   Unauthorised Access [ user is not a member ]
//     -Return Correct Type (x2)
//         - one successful msg sent during a standup
//         - successive messages sent during a standup

// // /////////////////////////////////////////////////// */

// // import functions
// import {
//   authRegisterV3,
//   channelsCreateV3,
//   standupStartV1,
//   standupSendV1,
//   clearV2,
// } from './testHelpers';

// // import interface
// import {
//   AuthUserId,
//   ChannelId,
//   Time
// } from './interface';

// let mainUser: AuthUserId;
// let thread: ChannelId;
// // eslint-disable-next-line
// let start: Time;

// beforeEach(() => {
//   clearV2();
//   mainUser = authRegisterV3('pyae@gmail.com', 'passcode', 'Pyae', 'Sone') as AuthUserId;
//   thread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;
//   // eslint-disable-next-line
//   start = standupStartV1(mainUser.token, thread.channelId, 2) as Time;
// });

// describe('Error Casses', () => {
//   test('Invalid Token', () => {
//     const testVar = standupSendV1(mainUser.token + 'abg', thread.channelId, 'HELLO');
//     expect(testVar).toStrictEqual(403);
//   });

//   test('Invalid Channel', () => {
//     const testVar = standupSendV1(mainUser.token, thread.channelId + 999, 'HELP');
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Invalid message length.', () => {
//     const longString : string = 'x'.repeat(1001);
//     const testVar = standupSendV1(mainUser.token, thread.channelId + 999, longString);
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Active standup is not running', () => {
//     const tempThread = channelsCreateV3(mainUser.token, 'myChannel', true) as ChannelId;
//     // eslint-disable-next-line
//         let tempStart = standupStartV1(mainUser.token, thread.channelId, 0) as Time;
//     const end = Date.now() + 1000;
//     while (Date.now() < end) { /* Do nothing; blocking the execution */ }
//     const testVar = standupSendV1(mainUser.token, tempThread.channelId, 'HELP i missed the standup');
//     expect(testVar).toStrictEqual(400);
//   });

//   test('Unauthorised Access [ user is not a member of the channel]', () => {
//     const user1 = authRegisterV3('red@gmail.com', 'psascode', 'Red', 'Ranger') as AuthUserId;
//     const testVar = standupSendV1(user1.token, thread.channelId, 'INTRUDER IS HERE');
//     expect(testVar).toStrictEqual(403);
//   });
// });
// describe('Returns Correct Type', () => {
//   test('one successful msg sent during a standup', () => {
//     // const end = Date.now() + 1000;
//     // while (Date.now() < end) { /* Do nothing; blocking the execution */ }
//     const testVar = standupSendV1(mainUser.token, thread.channelId, 'Incoming Backstreet Boisss');
//     expect(testVar).toStrictEqual({});
//   });
//   //   test('successive messages sent during a standup ', () => {
//   //     const end = Date.now() + 1000;
//   //     while (Date.now() < end) { /* Do nothing; blocking the execution */ }
//   //     start = standupStartV1(mainUser.token, thread.channelId, 10) as Time;
//   //     let testVar = standupSendV1(mainUser.token, thread.channelId, 'Tell me whyyy');
//   //     expect(testVar).toStrictEqual({});

//   //     testVar = standupSendV1(mainUser.token, thread.channelId, 'Aint nothing but a heartache');
//   //     expect(testVar).toStrictEqual({});

//   //     testVar = standupSendV1(mainUser.token, thread.channelId, 'Tell me whyyyy');
//   //     expect(testVar).toStrictEqual({});

// //     testVar = standupSendV1(mainUser.token, thread.channelId, 'Aint nothing but a mistake');
// //     // console.log(testVar);
// //     expect(testVar).toStrictEqual({});
// //   });
// });
