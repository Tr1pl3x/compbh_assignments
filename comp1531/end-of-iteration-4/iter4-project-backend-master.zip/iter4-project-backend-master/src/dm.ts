// import data types
import {
  DmDetails,
  DM,
  DMs,
  DmID,
  DmMessages,
  DMsReturn,
  ErrorMessage,
  MessageInfo,
  Member,
  User,
  aUser
} from './interface';

// import functions
import { getData, setData } from './dataStore';
import HTTPError from 'http-errors';
import { getHashOf } from './universalFunctions';
import {
  joinMembersDmV1,
  leaveDmV1,
  membersLeaveDmV1,
  updateWorkspaceV1,
} from './helper';

/**
 * /dm/create/v2
 * uIds contains the user(s) that this DM is directed to,
 * and will not include the creator. The creator is the
 * owner of the DM. name should be automatically generated
 * based on the users that are in this DM. The name should
 * be an alphabetically-sorted, comma-and-space-separated
 * concatenation of user handles, e.g. 'ahandle1, bhandle2,
 * chandle3'.
 *
 * @param {string} token - token of a user who requests to create
 * @param {number} uId - obtains ids of users, to be added in the new dm.
 * @returns {{error: string}} on error
 * @returns {{dmId}} - returns the dmId if successful.
*/
export function dmCreateV1(token: string, uId:number[]): (DmID | ErrorMessage) {
  const data = getData();

  // Validate the token
  const hashedToken = getHashOf(token);
  const creator = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!creator) throw HTTPError(403, 'Error: Invalid token: user not found');

  // collecting handle strings for the new name of the dm
  const names = [];
  names.push(creator.handleStr);

  // updates the all member array of the new dm
  const tempArr : User[] = [];
  tempArr.push(creator);

  // Validation for uId parameter
  // if empty, the function will proceed to create a new dm
  // if not, the users in the array will be validated.
  // console.log('length of the array=>',  uId.length)
  if (uId.length > 0) {
    // checks for duplicate ids in the given array
    const uniqueIds: Set<number> = new Set(uId);
    if (uniqueIds.size !== uId.length) throw HTTPError(400, 'ERROR: Duplicate IDs');

    for (const curr of uId) {
      const find = data.users.find(users => users.uId === curr);
      if (find) {
        // avoiding creator's name.
        if (find.uId !== creator.uId) {
          tempArr.push(find);
          names.push(find.handleStr);
        }
        // checks if given id from the array is not valid
      } else {
        throw HTTPError(400, 'ERROR: INVALID USER ID');
      }
    }
  }

  // generates an id for the new dm
  const newId:number = Math.floor(Math.random() * 1000000000);
  // generates the new name of the dm
  const newName: string = names.sort().join(',');
  // updates the owner array of the new dm
  const owner : User[] = [];
  owner.push(creator);
  // creates a new DM object to be updated into data store
  const newDm : DM = {
    dmId: newId,
    name: newName,
    ownerMembers: owner,
    allMembers: tempArr,
    allMessages: []
  };
  data.dms.push(newDm);
  setData(data);
  joinMembersDmV1(newId);
  updateWorkspaceV1('dms');
  return { dmId: newId };
}

/**
* /dm/details/v2
* Given a DM with ID dmId that the authorised user is a
* member of, provide basic details about the DM.
*
* @param {string} token - token of a user who requests to create
* @param {number} dmId - obtains id of the dm that is to be viewd.
* @returns {{error: string}} on error
* @returns {{DmDetails}} - returns the detail of the requested dm if successful.
 */
export function dmDetailsV1(token: string, dmId: number): (ErrorMessage|DmDetails) {
  // valid token check
  const data = getData();
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // valid dmId check
  const validDM = data.dms.find(dm => dm.dmId === dmId);
  if (!validDM) throw HTTPError(400, 'ERROR: INVALID DM');

  // authorised access check
  if (!(validDM.allMembers.find((access: aUser) => access.uId === validUser.uId))) {
    throw HTTPError(403, 'Error: Bad Request: Unauthorised access');
  }

  // proceeds to get details
  // remaps into details that follows the spec.
  const tempArr: Member[] = [];
  for (const curr of validDM.allMembers) {
    const tempObj = {
      uId: curr.uId,
      email: curr.email,
      nameFirst: curr.nameFirst,
      nameLast: curr.nameLast,
      handleStr: curr.handleStr,
    };
    tempArr.push(tempObj);
  }
  const theDetails: DmDetails = {
    name: validDM.name,
    members: tempArr,
  };
  return theDetails;
}

/**
* /dm/leave/v2
* Given a DM ID, the user is removed as a member of this DM.
* The creator is allowed to leave and the DM will still exist
* if this happens. This does not update the name of the DM.
*
* @param {string} token - token of a user who requests to create
* @param {number} dmId - obtains id of the dm that is to be viewd.
* @returns {{error: string}} on error
* @returns {} - returns empty object if successful.
 */
export function dmLeaveV1(token: string, dmId: number): (ErrorMessage | Record<string, never>) {
  const data = getData();
  // valid token check
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // valid dmId check
  const dmIndex = data.dms.findIndex(dm => dm.dmId === dmId);
  if (dmIndex === -1) throw HTTPError(400, 'ERROR: INVALID DM');

  // authorised access check: if user is part of dm
  const access = data.dms[dmIndex].allMembers.findIndex((user: aUser) => user.uId === validUser.uId);
  if (access === -1) throw HTTPError(403, 'Access denied');

  // check whether incoming user is an owner
  // if will have to remove from the dm's ownerMembers array.
  const isOwner = data.dms[dmIndex].ownerMembers.findIndex((user: aUser) => user.uId === validUser.uId);
  if (isOwner !== -1) data.dms[dmIndex].ownerMembers.splice(0, 1);

  // removes incoming user from member array.
  for (const index in data.dms[dmIndex].allMembers) {
    if (data.dms[dmIndex].allMembers[index].uId === validUser.uId) {
      data.dms[dmIndex].allMembers.splice(index, 1);
      break;
    }
  }
  setData(data);
  leaveDmV1(validUser.uId);
  return {};
}

/**
 * /dm/list/v2
 * Returns the list of DMs that the user is a member of.
 *
 * @param {string} token - token of a user
 * @returns {{error: string}} on error
 * @returns {DMs} - returns the detail of the requested dm if successful.
 */
export function dmListV1(token:string):(DMsReturn) {
  const data = getData();

  // valid token check
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // check if user is in any of the dms in dataStore
  // if user is a member, the dm is saved into temp array.
  const dms: DMs = [];
  for (const curr of data.dms) {
    if (curr.allMembers.find((user: aUser) => user.uId === validUser.uId)) {
      const tempObj = {
        dmId: curr.dmId,
        name: curr.name,
      };
      dms.push(tempObj);
    }
  }

  return { dms };
}

export function dmRemoveV1(token: string, dmId: number): (ErrorMessage | Record<string, never>) {
  // empty case for the token
  if (token === '') return { error: 'Empty Token' };
  const data = getData();
  // console.log(data.dms)

  // valid dmId check
  const validDM = data.dms.find(dm => dm.dmId === dmId);
  if (!validDM) throw HTTPError(400, 'ERROR: INVALID DM');

  // valid token check
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token: user not found');

  // // authorised access check
  // const access = validDM.allMembers.find(a => a.uId === validUser.uId);
  const access = validDM.allMembers.find((user: aUser) => user.uId === validUser.uId);
  if (!access) return { error: 'U aint my member' };

  // const access = validDM.allMembers.find(a => a.uId === validUser.uId);
  const ownerSearch = validDM.ownerMembers.find((user: aUser) => user.uId === validUser.uId);
  if (!ownerSearch) {
    // error: 'U aint my owner'
    throw HTTPError(403, 'Error: U aint my owner');
  }
  membersLeaveDmV1(dmId);
  // remove all the dm
  for (let i = 0; i < data.dms.length; i++) {
    if (data.dms[i].dmId === dmId) {
      data.dms.splice(i, 1);
      setData(data);
      updateWorkspaceV1('dms');
      updateWorkspaceV1('messages');
    }
  }
  return {};
}

/**
 * /dm/messages/v2
 * Given a DM with ID dmId that the authorised user (token) is a member of, returns up to
 * 50 messages between index start and "start + 50". Message with index 0
 * (i.e. the first element in the returned array of messages)
 * is the most recent message in the DM. This function returns a new index end
 * If there are more messages to return after this function call, end equals "start + 50".
 * If this function has returned the least recent messages in the DM
 * end equals -1 to indicate that there are no more messages to load after this return.
 *
 * @param {string} token - token of a user that will have their messages array returned
 * @param {number} dmId - id of the given dm that user is part of.
 * @param {number} start - start index of the messages array of the user in the specified dm.
 * @returns 400 or 403 HTTPE error on error
 * @returns {{messages: MessageInfo[], Start: number, End: number }} - returns the messages array as well as
 * the start and end index if successful.
*/
export function dmMessagesV1(token: string, dmId: number, start: number): (ErrorMessage | DmMessages) {
  // define type for messages
  const messages: Array<MessageInfo> = [];
  const data = getData();

  // valid dmId check
  const validDM = data.dms.find(dm => dm.dmId === dmId);
  if (!validDM) {
    throw HTTPError(400, 'Error: Invalid dmId');
  }

  // check for empty token
  if (token === '') throw HTTPError(403, 'Error: Invalid token');

  const hashedToken = getHashOf(token);
  // valid token check
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid token');

  // authorised access check
  const access = validDM.allMembers.find((user: aUser) => user.uId === validUser.uId);
  if (!access) {
    throw HTTPError(403, 'Error: Authorised user is not a member of the DM');
  }

  // case where there are 0 messages
  data.start = start;
  let end = start + 50;
  if ((validDM.allMessages).length === 0) {
    if ((start === 0) && ((validDM.allMessages).length === 0)) {
      data.end = -1;
      setData(data);
      end = data.end;
      return {
        messages,
        start,
        end
      };
    }
  }
  // if start is invalid length
  if (start >= (validDM.allMessages).length) {
    throw HTTPError(400, 'Error: Start is greater than the number of messages in the channel');
  }

  // get value of start
  const position = start.valueOf();
  let messageindex = 0;
  // Otherwise loop through dm.AllMessages
  for (const curr of data.dms) {
    if (curr.dmId === dmId) {
      // loop through all messages associated with uId
      for (let i = position; i < (curr.allMessages).length; i++, messageindex++) {
        messages[messageindex] = curr.allMessages[i];
        if (messageindex === 49) {
          break;
        }
      }
      // if there are less than 50 messages
      if (start < (curr.allMessages).length && (curr.allMessages).length <= end) {
        data.end = -1;
        end = data.end;
      }
      setData(data);
      messages.reverse();
      return {
        messages,
        start,
        end
      };
    }
  }
}
