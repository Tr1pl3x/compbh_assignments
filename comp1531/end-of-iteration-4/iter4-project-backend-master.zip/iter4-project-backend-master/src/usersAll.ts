/*
import { authRegisterV1 } from './auth';
import type { ErrorMessage } from './users';
import { userProfileV1 } from './users';
import type { User, users } from './interface';

export function usersAllV1(token: string): ErrorMessage | users {
  // if token is valid (a string) return users
  if (typeof token === 'string') {
    const authUserId = authRegisterV1(email, password, nameFirst, nameLast);
    const user = userProfileV1(authUserId, UiD);
    const users = user[user.length];
    return { users };
  } else {
    return { error: 'Invalid token' };
  }
}
*/
