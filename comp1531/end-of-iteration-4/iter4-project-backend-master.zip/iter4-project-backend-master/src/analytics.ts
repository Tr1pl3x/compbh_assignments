// import functions
import { getData } from './dataStore';
import { getHashOf } from './universalFunctions';
import { dataStatsV1, activeUsersV1 } from './helper';
import HTTPError from 'http-errors';

// import interface
import {
  ErrorMessage,
  returnUserStats,
  Stats,
  ReStats,
  WrkStats,
  WorkspaceStats,
} from './interface';

/**
 *  /user/stats/v1
 *
 *  Fetches the required statistics about this user's use of UNSW Memes.
 *
 *  @param {string} token       - token of a user who requests
 *  @returns {{error: string}}  - if error
 *  @returns {{userStats}}     - returns the dmId if successful.
 */
export function userStatsV1(token: string): (returnUserStats | ErrorMessage) {
  const data = getData();

  // Validates the incoming token
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid access: Unauthorized request');

  // Fetch the validUser's stats from the dataStore.userStats
  const validStats : Stats = data.stats.find(user => user.uId === validUser.uId);

  /* Calculate the involvement rate */
  // calculate the numerator ( channelsJoined + dmsJoined + messagesSent )
  const channels : number = validStats.channelsJoined[validStats.channelsJoined.length - 1].numChannelsJoined;
  const dms : number = validStats.dmsJoined[validStats.dmsJoined.length - 1].numDmsJoined;
  const messages : number = validStats.messagesSent[validStats.messagesSent.length - 1].numMessagesSent;
  const numerator: number = channels + dms + messages;

  // calculate the denominator by calling dataStats
  const denominator:number = dataStatsV1();
  let theRate = 0;
  if (denominator !== 0) theRate = numerator / denominator;

  // check whether rate is greater 1, if so, the rate is capped at 1.
  if (theRate > 1) theRate = 1;

  // remap into the format of the return
  const userStats : ReStats = {
    channelsJoined: validStats.channelsJoined,
    dmsJoined: validStats.dmsJoined,
    messagesSent: validStats.messagesSent,
    involvementRate: theRate,
  };
  return { userStats };
}

/**
 *  /users/stats/v1
 *
 *  Fetches the required statistics about this user's use of UNSW Memes.
 *
 *  @param {string} token       - token of a user who requests
 *  @returns {{error: string}}  - if error
 *  @returns {{workspaceStats}}     - returns the dmId if successful.
 */
export function usersStatsV1(token: string): (WorkspaceStats|ErrorMessage) {
  const data = getData();

  // Validates the incoming token
  const hashedToken = getHashOf(token);
  const validUser = data.users.find(user => user.tokens.find((t: { tokenId: string }) => t.tokenId === hashedToken));
  if (!validUser) throw HTTPError(403, 'Error: Invalid access: Unauthorized request');

  // calculate utilization rate
  const numerator:number = activeUsersV1();
  const denominator:number = data.users.length;

  // Switch Case for numerator to find the utilization rate
  let theRate: number;
  switch (numerator) {
    case 0: theRate = 0; break;
    default: theRate = numerator / denominator; break;
  }
  // remap into the format of the return
  const workspaceStats : WrkStats = {
    channelsExist: data.workspace[0].channelsExist,
    dmsExist: data.workspace[0].dmsExist,
    messagesExist: data.workspace[0].messagesExist,
    utilizationRate: theRate,
  };
  return { workspaceStats };
}
