
/**
 * For iteration 4, this test file is commented.
 */

test('valid test', () => {
  expect(2 + 2).toStrictEqual(4);
});

// import { channelsCreateV3, clearV2, authRegisterV2, channelLeaveV1 } from './testHelpers';
// import type { AuthUserId, ChannelId } from './interface';

// let newPerson: AuthUserId;
// let newPerson2: AuthUserId;
// let channelId1: ChannelId;
// beforeEach(() => {
//   clearV2();
//   newPerson = authRegisterV2('sammyj@gmail.com', 'pppassword', 'Sam', 'John') as AuthUserId;
//   newPerson2 = authRegisterV2('sammyj2@gmail.com', 'pppassword2', 'Sammy', 'Greg') as AuthUserId;
//   channelId1 = channelsCreateV3(newPerson.token, 'ChannelName', false) as ChannelId;
// });

// describe('Testing different parameters that covers every line of code', () => {
//   test('token is invalid', () => {
//     expect(channelLeaveV1('abc', channelId1.channelId)).toStrictEqual({ error: 'invalid token' });
//   });
//   test('Invalid channelId', () => {
//     expect(channelLeaveV1(newPerson.token, -1)).toStrictEqual({ error: 'invalid channelId' });
//   });
//   test('channelId is valid, user is not a member', () => {
//     expect(channelLeaveV1(newPerson2.token, channelId1.channelId)).toStrictEqual({ error: 'user is not a member!' });
//   });
//   test('valid parameters', () => {
//     expect(channelLeaveV1(newPerson.token, channelId1.channelId)).toStrictEqual({});
//   });
// });
