zID: z5271704   
Chosen bonus feature(s): Dark Mode to frontend
Explanation (~100 words):
Dark Mode elevates the styling of the website and easier on the eyes, especially when compsci students and staffs use it alot at late night so our eyes don't get burned from the white background.

front end repo: https://gitlab.cse.unsw.EDU.AU/z5271704/iter-4-project-frontend.git

Link to Flipgrid video: https://flip.com/s/vNR5adYKzBVm ( please kindly advise if video is not readable. Flipgrid compression is very bad. I will upload the video on google drive if needed).

