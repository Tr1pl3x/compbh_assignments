```javascript
let data = {
	channels: [
		{
			channelId: 1, 
			name: 'My Channel',
			allMembers: [{UId: 1}]
		}
	],
	users: [
		{
			uId: 1,
			nameFirst: 'Rani',
			nameLast: 'Jiang',
			email: 'ranivorous@gmail.com',
			handleStr: 'ranivorous',
		}
	],
	messages: [
    {
      messageId: 1,
      uId: 1,
      message: 'Hello world',
      timeSent: 1582426789,
    }
  ],
  start: 0,
  end: 50,
};

```

[Optional] short description: 