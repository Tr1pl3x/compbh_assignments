
// We check if the email is valid
import validator from 'validator';

validator.isEmail('foo@bar.com');
